package com.coode.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.util.ArrayList;

/** Coode Android: uygulama arayuzu (assets/index.html) bir WebView icinde calisir. */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_SPEECH = 42;
    private WebView web;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xFF080810);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // sohbetler, anahtar, ayarlar (localStorage)
        s.setDatabaseEnabled(true);
        s.setSupportMultipleWindows(false); // target=_blank linkleri asagida yakalanir
        s.setAllowFileAccess(false);

        // Dosyalari https://appassets.androidplatform.net/assets/ adresinden sun
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return loader.shouldInterceptRequest(req.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (HOST.equals(u.getHost())) return false;
                // YouTube / Google / harita linklerini kendi uygulamasinda ac
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "CoodeAndroid");

        if (state != null) {
            web.restoreState(state);
        } else {
            web.loadUrl("https://" + HOST + "/assets/index.html");
        }
    }

    /** JavaScript'ten cagrilan yerel ozellikler. */
    private class Bridge {
        @JavascriptInterface
        public void listen() {
            runOnUiThread(() -> {
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Konus, Coode dinliyor...");
                try {
                    startActivityForResult(i, REQ_SPEECH);
                } catch (Exception e) {
                    web.evaluateJavascript("toast('Bu telefonda ses tanima bulunamadi.')", null);
                }
            });
        }

        @JavascriptInterface
        public String version() {
            return "3.7.2";
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SPEECH && res == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                String text = JSONObject.quote(r.get(0));
                web.evaluateJavascript("window.onNativeSpeech && window.onNativeSpeech(" + text + ")", null);
            }
        }
    }

    @Override
    public void onBackPressed() {
        // Once acik menu/ayarlar kapansin, yoksa uygulamadan cik
        web.evaluateJavascript("window.coodeBack ? window.coodeBack() : false", value -> {
            if (!"true".equals(value)) {
                MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }
}
