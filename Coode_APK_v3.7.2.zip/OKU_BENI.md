# Coode APK — GitHub senin icin derler (bilgisayar gerekmez, telefondan da olur)

## 1. Depo ac
github.com → sag ustte **+** → **New repository** → adi `coode-apk` → **Public** → **Create repository**

## 2. Dosyalari yukle
Acilan sayfada **uploading an existing file** linkine tikla.
Bu klasorun ICINDEKI her seyi (app, .github, build.gradle, settings.gradle,
gradle.properties) secip surukle → **Commit changes**.
`.github` klasoru mutlaka yuklensin — derleme talimati onun icinde.

## 3. Bekle (~5 dakika)
Depoda **Actions** sekmesinde "Coode APK" calisir. Yesil tik olunca bitti.

## 4. APK'yi indir
Depo ana sayfasinda sagda **Releases** → en ustteki surum → **Coode-3.7.2.apk**.
Telefonda bu sayfayi acip dosyaya dokun → indir → ac → **Yukle**.
("Bilinmeyen kaynaklardan yukleme" izni sorarsa Chrome'a izin ver.)

## Guncelleme
Yeni `index.html` gelince `app/src/main/assets/index.html` dosyasini degistir →
GitHub yeni APK'yi kendisi derler. Yeni APK eskisinin uzerine kurulur, sohbetler silinmez.

Kirmizi carpi cikarsa: Actions → kirmizi calisma → hata satirinin ekran goruntusunu gonder.
