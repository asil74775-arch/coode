package com.coode.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.ContactsContract;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Coode Android: arayuz (assets/index.html) bir WebView icinde calisir.
 * Telefona ozel yetenekler "CoodeAndroid" JavaScript koprusuyle verilir:
 * ses tanima, sesli okuma, alarm/zamanlayici, takvim, rehber, arama/WhatsApp/SMS,
 * fener ve uygulama acma.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_SPEECH = 42;
    private static final int REQ_CONTACTS = 43;
    private static final Locale TR = new Locale("tr", "TR");

    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String lastUtterance = "";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xFF080810);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return loader.shouldInterceptRequest(req.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openExternal(u);
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "CoodeAndroid");

        initTts();

        if (state != null) {
            web.restoreState(state);
        } else {
            web.loadUrl("https://" + HOST + "/assets/index.html");
        }
    }

    // ── Sesli okuma ──────────────────────────────────────────────────────────
    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(TR);
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) {
                        if (id.equals(lastUtterance)) js("window.onSpeakDone && window.onSpeakDone()");
                    }
                    @Override public void onError(String id) {
                        if (id.equals(lastUtterance)) js("window.onSpeakDone && window.onSpeakDone()");
                    }
                });
            }
        });
    }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private boolean openExternal(Uri u) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, u);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String start(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return "ok";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    private boolean hasContacts() {
        return checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
    }

    /** JavaScript'ten cagrilan yerel ozellikler. */
    private class Bridge {

        @JavascriptInterface
        public String version() { return BuildConfigHolder.VERSION; }

        // Ses tanima (Google'in ses ekrani)
        @JavascriptInterface
        public void listen() {
            runOnUiThread(() -> {
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Konus, Coode dinliyor...");
                try {
                    startActivityForResult(i, REQ_SPEECH);
                } catch (Exception e) {
                    js("toast('Bu telefonda ses tanima bulunamadi.'); window.onNativeSpeechCancel && window.onNativeSpeechCancel()");
                }
            });
        }

        // Sesli okuma
        @JavascriptInterface
        public boolean canSpeak() { return ttsReady; }

        @JavascriptInterface
        public void speak(String text) {
            if (tts == null || !ttsReady || text == null) {
                js("window.onSpeakDone && window.onSpeakDone()");
                return;
            }
            tts.stop();
            int max = Math.min(3500, TextToSpeech.getMaxSpeechInputLength() - 100);
            List<String> parts = new ArrayList<>();
            String rest = text.trim();
            while (rest.length() > max) {
                int cut = Math.max(rest.lastIndexOf(". ", max), rest.lastIndexOf("\n", max));
                if (cut < max / 2) cut = max;
                parts.add(rest.substring(0, cut + 1));
                rest = rest.substring(cut + 1).trim();
            }
            if (!rest.isEmpty()) parts.add(rest);
            if (parts.isEmpty()) {
                js("window.onSpeakDone && window.onSpeakDone()");
                return;
            }
            long stamp = System.currentTimeMillis();
            for (int k = 0; k < parts.size(); k++) {
                String id = "coode-" + stamp + "-" + k;
                if (k == parts.size() - 1) lastUtterance = id;
                tts.speak(parts.get(k), k == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, id);
            }
        }

        @JavascriptInterface
        public void stopSpeaking() {
            if (tts != null) tts.stop();
        }

        // Alarm (saat uygulamasina kurar)
        @JavascriptInterface
        public String setAlarm(int hour, int minute, String label) {
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
            i.putExtra(AlarmClock.EXTRA_HOUR, hour);
            i.putExtra(AlarmClock.EXTRA_MINUTES, minute);
            if (label != null && !label.isEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            return start(i);
        }

        // Geri sayim (zamanlayici)
        @JavascriptInterface
        public String setTimer(int seconds, String label) {
            Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
            i.putExtra(AlarmClock.EXTRA_LENGTH, Math.max(1, seconds));
            if (label != null && !label.isEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            return start(i);
        }

        // Takvime hatirlatici (takvim ekrani dolu acilir, kullanici Kaydet'e basar)
        @JavascriptInterface
        public String addReminder(String title, double beginMillis, int minutes) {
            long begin = (long) beginMillis;
            Intent i = new Intent(Intent.ACTION_INSERT);
            i.setData(CalendarContract.Events.CONTENT_URI);
            i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin);
            i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + Math.max(5, minutes) * 60000L);
            i.putExtra(CalendarContract.Events.TITLE, title);
            i.putExtra(CalendarContract.Events.HAS_ALARM, 1);
            return start(i);
        }

        // Rehber
        @JavascriptInterface
        public boolean hasContactsPermission() { return hasContacts(); }

        @JavascriptInterface
        public void requestContacts() {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS));
        }

        @JavascriptInterface
        public String findContacts(String name) {
            JSONArray out = new JSONArray();
            if (!hasContacts() || name == null || name.trim().isEmpty()) return out.toString();
            String[] proj = {
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
            };
            String sel = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?";
            try (Cursor c = getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, sel,
                    new String[]{"%" + name.trim() + "%"},
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
                if (c != null) {
                    while (c.moveToNext() && out.length() < 8) {
                        JSONObject o = new JSONObject();
                        o.put("name", c.getString(0));
                        o.put("number", c.getString(1));
                        out.put(o);
                    }
                }
            } catch (Exception ignored) { }
            return out.toString();
        }

        // Arama ekranini numarayla acar (aramayi kullanici baslatir)
        @JavascriptInterface
        public String dial(String number) {
            return start(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))));
        }

        // SMS ekranini mesajla acar (gondermeyi kullanici yapar)
        @JavascriptInterface
        public String sms(String number, String text) {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number == null ? "" : number)));
            i.putExtra("sms_body", text);
            return start(i);
        }

        // Herhangi bir adresi ac (WhatsApp, YouTube, harita...)
        @JavascriptInterface
        public String openUrl(String url) {
            return openExternal(Uri.parse(url)) ? "ok" : "error: acilamadi";
        }

        // Fener
        @JavascriptInterface
        public String flashlight(boolean on) {
            try {
                CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
                for (String id : cm.getCameraIdList()) {
                    Boolean has = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (has != null && has) {
                        cm.setTorchMode(id, on);
                        return "ok";
                    }
                }
                return "error: fener yok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        // Yuklu uygulamayi adina gore ac
        @JavascriptInterface
        public String openApp(String name) {
            if (name == null || name.trim().isEmpty()) return "error: isim bos";
            String q = name.trim().toLowerCase(TR);
            PackageManager pm = getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
            ResolveInfo best = null;
            for (ResolveInfo r : apps) {
                String label = String.valueOf(r.loadLabel(pm)).toLowerCase(TR);
                if (label.equals(q)) { best = r; break; }
                if (best == null && (label.startsWith(q) || label.contains(q))) best = r;
            }
            if (best == null) return "error: '" + name + "' adinda uygulama bulunamadi";
            Intent launch = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
            if (launch == null) return "error: acilamadi";
            String res = start(launch);
            return res.equals("ok") ? "ok: " + best.loadLabel(pm) : res;
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == REQ_CONTACTS) {
            boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            js("window.onContactsPermission && window.onContactsPermission(" + ok + ")");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_SPEECH) return;
        if (res == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                String text = JSONObject.quote(r.get(0));
                web.evaluateJavascript("window.onNativeSpeech && window.onNativeSpeech(" + text + ")", null);
                return;
            }
        }
        web.evaluateJavascript("window.onNativeSpeechCancel && window.onNativeSpeechCancel()", null);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.coodeBack ? window.coodeBack() : false", value -> {
            if (!"true".equals(value)) {
                MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    /** Surum bilgisi (BuildConfig'e bagimli olmadan). */
    static final class BuildConfigHolder {
        static final String VERSION = "3.8.0";
    }
}
