# file_reader.py — Dosya okuma ve analiz paneli
# Claude'daki dosya yükleme + analiz özelliğinin Coode versiyonu.
# PDF, DOCX, TXT, CSV, JSON, resim okur; Coode'a özetletir.

import os
from PySide6.QtCore    import QThread, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFileDialog, QTextEdit, QFrame,
    QListWidget, QListWidgetItem,
)
import theme as th


def _read_file(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()

    if ext == ".txt":
        with open(path, encoding="utf-8", errors="ignore") as f:
            return f.read(50_000)

    if ext == ".json":
        import json
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return json.dumps(data, ensure_ascii=False, indent=2)[:20_000]

    if ext == ".csv":
        import csv
        rows = []
        with open(path, encoding="utf-8", errors="ignore") as f:
            for i, row in enumerate(csv.reader(f)):
                rows.append(", ".join(row))
                if i >= 200:
                    break
        return "\n".join(rows)

    if ext == ".pdf":
        try:
            import fitz  # PyMuPDF
            doc  = fitz.open(path)
            text = "\n".join(page.get_text() for page in doc)
            return text[:30_000]
        except ImportError:
            return "[PDF okumak için: pip install pymupdf]"

    if ext in (".docx",):
        try:
            from docx import Document
            doc  = Document(path)
            return "\n".join(p.text for p in doc.paragraphs)[:30_000]
        except ImportError:
            return "[DOCX okumak için: pip install python-docx]"

    if ext in (".png", ".jpg", ".jpeg", ".webp", ".bmp"):
        return f"[Görsel dosya: {os.path.basename(path)}]\nBoyut analizi için Coode'a sor."

    return f"[Desteklenmeyen format: {ext}]"


class AnalyzeWorker(QThread):
    done  = Signal(str)
    error = Signal(str)

    def __init__(self, text: str, question: str):
        super().__init__()
        self._text     = text
        self._question = question

    def run(self):
        try:
            from llm import _ollama_stream
            prompt = (
                f"Aşağıdaki dosya içeriğini analiz et ve şu soruyu yanıtla:\n"
                f"Soru: {self._question}\n\n"
                f"İçerik:\n{self._text[:8000]}"
            )
            msgs = [{"role": "user", "content": prompt}]
            self.done.emit("".join(_ollama_stream(msgs)))
        except Exception as e:
            self.error.emit(str(e))


class FileReaderPanel(QWidget):
    artifact_ready = Signal(str, str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._files: dict[str, str] = {}  # path → content
        self._build_ui()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # Başlık
        header = QFrame()
        header.setFixedHeight(52)
        header.setStyleSheet(
            f"background:{th.get('surface')}; border-bottom:1px solid {th.get('border')};"
        )
        hlay = QHBoxLayout(header)
        hlay.setContentsMargins(16, 0, 16, 0)
        title = QLabel("Dosya Analizi")
        title.setStyleSheet(f"color:{th.get('text')}; font-size:15px; font-weight:bold;")
        hlay.addWidget(title)
        hlay.addStretch()
        btn_add = QPushButton("+ Dosya Ekle")
        btn_add.setObjectName("primary")
        btn_add.clicked.connect(self._add_file)
        hlay.addWidget(btn_add)
        lay.addWidget(header)

        from PySide6.QtCore import Qt
        from PySide6.QtWidgets import QSplitter
        splitter = QSplitter(Qt.Horizontal)

        # Dosya listesi
        self._file_list = QListWidget()
        self._file_list.setMaximumWidth(200)
        self._file_list.setStyleSheet(
            f"QListWidget{{background:{th.get('surface')}; border:none; border-right:1px solid {th.get('border')};}}"
            f"QListWidget::item{{padding:8px 10px; color:{th.get('text_dim')}; font-size:11px;}}"
            f"QListWidget::item:selected{{background:{th.get('border')}; color:{th.get('accent')};}}"
        )
        self._file_list.currentItemChanged.connect(self._on_file_select)
        splitter.addWidget(self._file_list)

        # Sağ: içerik + soru
        right = QWidget()
        rlay  = QVBoxLayout(right)
        rlay.setContentsMargins(12, 12, 12, 12)
        rlay.setSpacing(8)

        self._content_view = QTextEdit()
        self._content_view.setReadOnly(True)
        self._content_view.setPlaceholderText("Dosya içeriği burada görünür…")
        self._content_view.setStyleSheet(
            f"background:{th.get('surface2')}; color:{th.get('text_dim')}; "
            f"font-family:Consolas; font-size:11px; border-radius:8px;"
        )
        rlay.addWidget(self._content_view, stretch=2)

        # Soru satırı
        q_row = QHBoxLayout()
        self._question = QTextEdit()
        self._question.setPlaceholderText("Bu dosya hakkında Coode'a sor… (örn: özetle, hataları bul)")
        self._question.setFixedHeight(60)
        self._question.setStyleSheet(
            f"background:{th.get('surface2')}; color:{th.get('text')}; border-radius:8px;"
        )
        q_row.addWidget(self._question)
        btn_ask = QPushButton("Sor →")
        btn_ask.setObjectName("primary")
        btn_ask.setFixedSize(80, 60)
        btn_ask.clicked.connect(self._ask)
        q_row.addWidget(btn_ask)
        rlay.addLayout(q_row)

        self._answer = QTextEdit()
        self._answer.setReadOnly(True)
        self._answer.setPlaceholderText("Coode'un cevabı burada görünür…")
        self._answer.setStyleSheet(
            f"background:{th.get('surface')}; color:{th.get('text')}; border-radius:8px;"
        )
        rlay.addWidget(self._answer, stretch=3)

        splitter.addWidget(right)
        splitter.setSizes([200, 600])
        lay.addWidget(splitter)

    def _add_file(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Dosya Seç", "",
            "Tüm Desteklenen (*.txt *.pdf *.docx *.csv *.json *.png *.jpg *.jpeg)"
        )
        for path in paths:
            content = _read_file(path)
            self._files[path] = content
            name = os.path.basename(path)
            item = QListWidgetItem(name)
            item.setData(32, path)
            self._file_list.addItem(item)

    def _on_file_select(self, item):
        if item is None:
            return
        path    = item.data(32)
        content = self._files.get(path, "")
        self._content_view.setPlainText(content[:5000])

    def _ask(self):
        item = self._file_list.currentItem()
        if not item:
            return
        path    = item.data(32)
        content = self._files.get(path, "")
        q       = self._question.toPlainText().strip()
        if not q:
            q = "Bu dosyayı özetle."

        self._answer.setPlainText("Coode düşünüyor…")
        self._worker = AnalyzeWorker(content, q)
        self._worker.done.connect(self._answer.setPlainText)
        self._worker.error.connect(lambda e: self._answer.setPlainText(f"Hata: {e}"))
        self._worker.start()
