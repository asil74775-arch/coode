# artifact_panel.py — Artifact / Canvas paneli
# Coode'un ürettiği HTML/kod/markdown çıktıları burada canlı görüntülenir.
# Claude'daki Artifacts özelliğinin Coode versiyonu.

import os, json, tempfile
from PySide6.QtCore    import Qt, Signal, QUrl
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QFileDialog, QSplitter,
    QTextEdit, QListWidget, QListWidgetItem, QFrame,
)
from PySide6.QtWebEngineWidgets import QWebEngineView
import theme as th
from config import OUTPUTS_DIR


class ArtifactPanel(QWidget):
    """Coode'un ürettiği artifact'leri listeler ve canlı render eder."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._artifacts: list[dict] = []   # {name, type, content}
        self._current_idx = -1
        self._build_ui()
        self._load_saved()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # Başlık
        header = QFrame()
        header.setFixedHeight(52)
        header.setStyleSheet(
            f"background:{th.get('surface')}; border-bottom:1px solid {th.get('border')};"
        )
        hlay = QHBoxLayout(header)
        hlay.setContentsMargins(16, 0, 16, 0)
        title = QLabel("Artifact")
        title.setStyleSheet(f"color:{th.get('text')}; font-size:15px; font-weight:bold;")
        hlay.addWidget(title)
        hlay.addStretch()

        btn_new = QPushButton("+ Yeni")
        btn_new.clicked.connect(self._new_artifact)
        btn_save = QPushButton("Kaydet")
        btn_save.clicked.connect(self._save_artifact)
        hlay.addWidget(btn_new)
        hlay.addWidget(btn_save)
        lay.addWidget(header)

        # Sol liste + sağ önizleme
        splitter = QSplitter(Qt.Horizontal)

        # Artifact listesi
        self._list = QListWidget()
        self._list.setMaximumWidth(180)
        self._list.setStyleSheet(
            f"QListWidget{{background:{th.get('surface')}; border:none; border-right:1px solid {th.get('border')};}}"
            f"QListWidget::item{{padding:8px 10px; color:{th.get('text_dim')}; font-size:11px;}}"
            f"QListWidget::item:selected{{background:{th.get('border')}; color:{th.get('accent')};}}"
        )
        self._list.currentRowChanged.connect(self._on_select)
        splitter.addWidget(self._list)

        # Sağ taraf: editör + preview
        right = QWidget()
        rlay  = QVBoxLayout(right)
        rlay.setContentsMargins(0, 0, 0, 0)
        rlay.setSpacing(0)

        # Tür seçici
        type_row = QWidget()
        type_row.setStyleSheet(f"background:{th.get('surface2')}; border-bottom:1px solid {th.get('border')};")
        tlay = QHBoxLayout(type_row)
        tlay.setContentsMargins(12, 6, 12, 6)
        tlay.addWidget(QLabel("Tür:"))
        self._type_combo = QComboBox()
        self._type_combo.addItems(["html", "python", "markdown", "json", "text"])
        self._type_combo.currentTextChanged.connect(self._on_type_change)
        self._type_combo.setStyleSheet(
            f"background:{th.get('surface')}; color:{th.get('text')}; "
            f"border:1px solid {th.get('border')}; border-radius:6px; padding:4px 8px;"
        )
        tlay.addWidget(self._type_combo)
        tlay.addStretch()
        btn_run = QPushButton("Çalıştır")
        btn_run.setObjectName("primary")
        btn_run.clicked.connect(self._render)
        tlay.addWidget(btn_run)
        rlay.addWidget(type_row)

        # Editör + WebView splitter
        vsplit = QSplitter(Qt.Vertical)

        self._editor = QTextEdit()
        self._editor.setPlaceholderText("Coode'un ürettiği kod veya içerik burada görünür…")
        self._editor.setStyleSheet(
            f"background:{th.get('surface2')}; color:{th.get('text')}; "
            f"font-family:Consolas; font-size:12px; border:none;"
        )
        vsplit.addWidget(self._editor)

        self._preview = QWebEngineView()
        self._preview.setStyleSheet("background:#ffffff;")
        vsplit.addWidget(self._preview)
        vsplit.setSizes([300, 300])

        rlay.addWidget(vsplit)
        splitter.addWidget(right)
        splitter.setSizes([180, 600])
        lay.addWidget(splitter)

    # ── Artifact yönetimi ──────────────────────────────────────────────────────
    def add_artifact(self, name: str, type_: str, content: str):
        """Dışarıdan (sohbet paneli) artifact ekle."""
        self._artifacts.append({"name": name, "type": type_, "content": content})
        self._list.addItem(QListWidgetItem(name))
        self._list.setCurrentRow(len(self._artifacts) - 1)
        self._save_all()

    def _new_artifact(self):
        name = f"artifact_{len(self._artifacts)+1}"
        self.add_artifact(name, "html", "<!-- Buraya HTML yaz -->")

    def _on_select(self, row: int):
        if row < 0 or row >= len(self._artifacts):
            return
        # Önceki içeriği kaydet
        if self._current_idx >= 0 and self._current_idx < len(self._artifacts):
            self._artifacts[self._current_idx]["content"] = self._editor.toPlainText()

        self._current_idx = row
        a = self._artifacts[row]

        # Editörü güncellerken imleç konumunu sıfırlamamak için blockSignals
        self._editor.blockSignals(True)
        self._editor.setPlainText(a["content"])
        self._editor.moveCursor(self._editor.textCursor().Start)
        self._editor.blockSignals(False)

        # Tip combo — değiştiğinde _on_type_change tetiklenmesin diye blockSignals
        self._type_combo.blockSignals(True)
        idx = self._type_combo.findText(a["type"])
        if idx >= 0:
            self._type_combo.setCurrentIndex(idx)
        self._type_combo.blockSignals(False)

        # Önizlemeyi otomatik göster
        self._render()

    def _on_type_change(self, t: str):
        if self._current_idx >= 0:
            self._artifacts[self._current_idx]["type"] = t

    def _render(self):
        if self._current_idx < 0:
            return
        content = self._editor.toPlainText()
        self._artifacts[self._current_idx]["content"] = content
        t = self._artifacts[self._current_idx]["type"]

        if t == "html":
            self._preview.setHtml(content)
        elif t == "python":
            from sandbox import run_code
            r = run_code(content)
            self._preview.setHtml(
                f"<pre style='font-family:Consolas;padding:12px;background:#111;color:#0f0;'>"
                f"{r.output or r.error}</pre>"
            )
        elif t == "markdown":
            try:
                import markdown
                html = markdown.markdown(content)
            except Exception:
                html = f"<pre>{content}</pre>"
            self._preview.setHtml(
                f"<style>body{{font-family:sans-serif;padding:16px;line-height:1.6;}}</style>{html}"
            )
        else:
            self._preview.setHtml(f"<pre style='padding:12px;'>{content}</pre>")

        self._save_all()

    def _save_artifact(self):
        if self._current_idx < 0:
            return
        a = self._artifacts[self._current_idx]
        ext = {"html": ".html", "python": ".py", "markdown": ".md"}.get(a["type"], ".txt")
        path, _ = QFileDialog.getSaveFileName(self, "Kaydet", a["name"] + ext)
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(a["content"])

    # ── Kalıcılık ─────────────────────────────────────────────────────────────
    def _save_all(self):
        path = os.path.join(OUTPUTS_DIR, "artifacts.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self._artifacts, f, ensure_ascii=False, indent=2)

    def _load_saved(self):
        path = os.path.join(OUTPUTS_DIR, "artifacts.json")
        if not os.path.isfile(path):
            return
        try:
            with open(path, encoding="utf-8") as f:
                self._artifacts = json.load(f)
            for a in self._artifacts:
                self._list.addItem(QListWidgetItem(a["name"]))
        except Exception:
            pass
