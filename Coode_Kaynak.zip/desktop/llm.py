# llm.py — Model yükleme ve üretim
#
# Öncelik sırası:
#   1. Yerel fine-tune model (config.FINETUNED_MODEL_PATH dolu ise)
#   2. Groq API          (API key girildiyse)
#   3. Hugging Face API  (config.HF_API_URL dolu ise)
#   4. Ollama API        (fallback)
#
# GenerateWorker arayüzü her üç durumda da aynıdır:
#   token    Signal(str)   — her yeni token'da tetiklenir
#   finished Signal(str)   — cevap tamamlandığında
#   error    Signal(str)   — hata durumunda

import json
import threading
import requests
from PySide6.QtCore import QThread, Signal
import memory as mem
from config import (
    SYSTEM_PROMPT, FINETUNED_MODEL_PATH,
    OLLAMA_HOST, OLLAMA_MODEL, OLLAMA_TIMEOUT,
    HF_API_URL, HF_API_KEY, HF_TIMEOUT,
    GROQ_API_KEY, GROQ_MODEL,
)

# ── Yerel model (opsiyonel) ───────────────────────────────────────────────────
_tokenizer = None
_model     = None


def load_local():
    global _tokenizer, _model
    if not FINETUNED_MODEL_PATH:
        return False
    try:
        from transformers import AutoTokenizer, AutoModelForCausalLM
        import torch
        _tokenizer = AutoTokenizer.from_pretrained(FINETUNED_MODEL_PATH)
        _model     = AutoModelForCausalLM.from_pretrained(
            FINETUNED_MODEL_PATH,
            torch_dtype=torch.float16,
            device_map="auto",
        )
        _model.eval()
        print("[llm] Yerel model yüklendi.")
        return True
    except Exception as e:
        print(f"[llm] Yerel model yüklenemedi: {e}")
        return False


def unload_local():
    global _tokenizer, _model
    import torch, gc
    _tokenizer = None
    _model     = None
    gc.collect()
    torch.cuda.empty_cache()


# ── Aktif backend tespiti ─────────────────────────────────────────────────────
def _get_backend() -> str:
    """
    Kullanılacak backend'i döndürür:
    'local' | 'groq' | 'hf' | 'ollama'
    Öncelik: yerel model > Groq > HF > Ollama
    """
    if _model is not None:
        return "local"
    groq_key = mem.get_pref("groq_api_key") or GROQ_API_KEY
    if groq_key and groq_key.strip():
        return "groq"
    hf_url = mem.get_pref("hf_api_url") or HF_API_URL
    if hf_url and hf_url.strip():
        return "hf"
    return "ollama"


# ── Mesaj zinciri ─────────────────────────────────────────────────────────────
def build_messages(history: list[dict], user_msg: str) -> list[dict]:
    user_name = (mem.get_pref("user_name") or "Ahmet Selim").strip(" ,.;:")
    prompt = SYSTEM_PROMPT.replace("{user_name}", user_name)
    from datetime import datetime
    _now = datetime.now()
    prompt += f"\n\nSu an: {_now.strftime('%d.%m.%Y %H:%M')} (ISO: {_now.strftime('%Y-%m-%dT%H:%M')}, gun: {['Pazartesi','Sali','Carsamba','Persembe','Cuma','Cumartesi','Pazar'][_now.weekday()]})."
    facts = mem.get_pref("contacts", {}) or {}
    if facts:
        prompt += "\nKayitli kisiler: " + ", ".join(facts.keys())
    msgs = [{"role": "system", "content": prompt}]
    msgs.extend(history[-20:])          # son 20 tur
    msgs.append({"role": "user", "content": user_msg})
    return msgs


# ── Ollama stream ─────────────────────────────────────────────────────────────
def _ollama_stream(messages: list[dict]):
    """Ollama /api/chat endpoint'ine streaming POST atar; token token yield eder."""
    host  = mem.get_pref("ollama_host")  or OLLAMA_HOST
    model = mem.get_pref("ollama_model") or OLLAMA_MODEL
    url   = f"{host}/api/chat"
    payload = {
        "model":    model,
        "messages": messages,
        "stream":   True,
        "options":  {"temperature": 0.7, "top_p": 0.9},
    }
    with requests.post(url, json=payload, stream=True, timeout=OLLAMA_TIMEOUT) as r:
        r.raise_for_status()
        for line in r.iter_lines():
            if not line:
                continue
            data  = json.loads(line)
            token = data.get("message", {}).get("content", "")
            if token:
                yield token
            if data.get("done"):
                break


# ── HF API stream ─────────────────────────────────────────────────────────────
def _hf_stream(messages: list[dict]):
    """
    HF Spaces'te çalışan Coode API sunucusuna streaming POST atar.
    Sunucu SSE (Server-Sent Events) formatında token gönderir:
        data: {"token": "merhaba"}
        data: [DONE]
    """
    hf_url = (mem.get_pref("hf_api_url") or HF_API_URL).rstrip("/")
    hf_key = mem.get_pref("hf_api_key")  or HF_API_KEY

    url     = f"{hf_url}/chat"
    headers = {"Content-Type": "application/json"}
    if hf_key:
        headers["Authorization"] = f"Bearer {hf_key}"

    payload = {
        "messages":    messages,
        "temperature": 0.7,
        "top_p":       0.9,
        "max_tokens":  512,
    }

    with requests.post(url, json=payload, headers=headers,
                       stream=True, timeout=HF_TIMEOUT) as r:
        r.raise_for_status()
        for line in r.iter_lines():
            if not line:
                continue
            # SSE satırı: "data: {...}" veya "data: [DONE]"
            text = line.decode("utf-8") if isinstance(line, bytes) else line
            if not text.startswith("data:"):
                continue
            raw = text[5:].strip()
            if raw == "[DONE]":
                break
            try:
                data  = json.loads(raw)
                token = data.get("token", "")
                if token:
                    yield token
            except json.JSONDecodeError:
                continue


# ── QThread Worker ────────────────────────────────────────────────────────────
class GenerateWorker(QThread):
    token    = Signal(str)
    finished = Signal(str)
    error    = Signal(str)

    def __init__(self, messages: list[dict]):
        super().__init__()
        self._messages = messages
        self._full     = ""

    def run(self):
        try:
            backend = _get_backend()
            if backend == "local":
                self._run_local()
            elif backend == "groq":
                self._run_groq()
            elif backend == "hf":
                self._run_hf()
            else:
                self._run_ollama()
        except Exception as e:
            self.error.emit(str(e))

    def _run_groq(self):
        """Groq API — streaming. Hata olursa anlaşılır mesaj verir (Ollama'ya düşmez)."""
        from groq import Groq
        from agent import _friendly_error
        groq_key   = mem.get_pref("groq_api_key") or GROQ_API_KEY
        groq_model = mem.get_pref("groq_model")   or GROQ_MODEL
        try:
            client = Groq(api_key=groq_key, timeout=60)
            kwargs = dict(model=groq_model, messages=self._messages,
                          stream=True, max_tokens=2048, temperature=0.7)
            try:
                stream = client.chat.completions.create(reasoning_format="hidden", **kwargs)
            except Exception as e:
                if "reasoning" not in str(e).lower():
                    raise
                stream = client.chat.completions.create(**kwargs)
            for chunk in stream:
                if not chunk.choices:
                    continue
                tok = chunk.choices[0].delta.content or ""
                if tok:
                    self._full += tok
                    self.token.emit(tok)
            self.finished.emit(self._full)
        except Exception as e:
            self.error.emit(_friendly_error(e))

    def _run_ollama(self):
        try:
            requests.get((mem.get_pref("ollama_host") or OLLAMA_HOST) + "/api/tags", timeout=3)
        except Exception:
            self.error.emit(
                "Hicbir model bagli degil. Ayarlar > Groq API bolumune ucretsiz API anahtarini "
                "yapistirip Kaydet'e bas (console.groq.com)."
            )
            return
        for tok in _ollama_stream(self._messages):
            self._full += tok
            self.token.emit(tok)
        self.finished.emit(self._full)

    def _run_hf(self):
        try:
            for tok in _hf_stream(self._messages):
                self._full += tok
                self.token.emit(tok)
            self.finished.emit(self._full)
        except Exception as e:
            # HF başarısız olursa Ollama'ya düş
            print(f"[llm] HF API başarısız ({e}), Ollama'ya geçiliyor...")
            self._full = ""
            self._run_ollama()

    def _run_local(self):
        import torch
        from transformers import TextIteratorStreamer
        inputs   = _tokenizer.apply_chat_template(
            self._messages, return_tensors="pt", add_generation_prompt=True
        ).to(_model.device)
        streamer = TextIteratorStreamer(_tokenizer, skip_prompt=True, skip_special_tokens=True)
        kwargs   = dict(
            input_ids=inputs,
            max_new_tokens=512,
            do_sample=True,
            temperature=0.7,
            streamer=streamer,
        )
        t = threading.Thread(target=_model.generate, kwargs=kwargs, daemon=True)
        t.start()
        for tok in streamer:
            self._full += tok
            self.token.emit(tok)
        self.finished.emit(self._full)
