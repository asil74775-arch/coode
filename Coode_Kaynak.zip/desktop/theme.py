# theme.py — Coode profesyonel tema sistemi v3.7.2
# Premium dark/light tasarım — Inter font, hassas spacing, micro animasyonlar

import json
from config import THEME_PATH

_raw:  dict = {}
_data: dict = {}


def load() -> dict:
    global _raw, _data
    try:
        with open(THEME_PATH, encoding="utf-8") as f:
            _raw = json.load(f)
    except Exception:
        _raw = _defaults_raw()
    mode  = _raw.get("mode", "dark")
    if mode not in ("dark", "light"):
        mode = "dark"
    # Varsayılanların üzerine kullanıcı değerleri — eksik anahtar asla hata vermez
    _data = dict(_defaults_raw()[mode])
    _data.update(_raw.get(mode, {}) or {})
    _data["font_family"] = _raw.get("font_family", "Inter, Segoe UI, system-ui")
    _data["font_size"]   = _raw.get("font_size", 13)
    _data["radius"]      = _raw.get("radius", 12)
    _data["mode"]        = mode
    return _data


def reload() -> dict:
    return load()


def set_mode(mode: str):
    _raw["mode"] = mode
    try:
        with open(THEME_PATH, "w", encoding="utf-8") as f:
            json.dump(_raw, f, indent=2, ensure_ascii=False)
    except Exception:
        pass
    load()


def toggle_mode():
    set_mode("light" if _raw.get("mode") == "dark" else "dark")


def get(key: str, default="") -> str:
    return str(_data.get(key, default))


def logo_path() -> str:
    import os
    from config import RES_DIR
    name = _data.get("logo", "logo_dark.png")
    return os.path.join(RES_DIR, name)


def _defaults_raw() -> dict:
    return {
        "mode": "dark",
        "dark": {
            # Temel renkler
            "background":  "#080810",    # derin lacivert-siyah
            "surface":     "#0f0f1a",    # panel arka planı
            "surface2":    "#161625",    # kart / input
            "surface3":    "#1c1c30",    # hover, vurgu yüzeyi
            "border":      "#1e1e35",    # ince ayırıcı
            "border2":     "#2a2a45",    # belirgin çerçeve

            # Yeşil aksent — Coode imzası
            "accent":      "#00c97a",    # canlı yeşil
            "accent_dim":  "#009960",    # koyu yeşil
            "accent_glow": "#00c97a22",  # parlama efekti (rgba)
            "accent_text": "#080810",    # aksent üzerindeki metin

            # Metin
            "text":        "#eeeef5",    # ana metin
            "text_dim":    "#8888aa",    # yardımcı metin
            "text_muted":  "#44445a",    # soluk

            # Kısayol renkleri (uyumlu isimler)
            "muted":       "#44445a",
            "info":        "#60a5fa",
            "success":     "#00c97a",
            "warning":     "#fbbf24",
            "error":       "#f87171",

            "logo": "logo_dark.png",
        },
        "light": {
            "background":  "#f0f0f8",
            "surface":     "#ffffff",
            "surface2":    "#f5f5fc",
            "surface3":    "#eaeaf4",
            "border":      "#e0e0ee",
            "border2":     "#c8c8e0",

            "accent":      "#00a060",
            "accent_dim":  "#007a4a",
            "accent_glow": "#00a06022",
            "accent_text": "#ffffff",

            "text":        "#111120",
            "text_dim":    "#555570",
            "text_muted":  "#aaaacc",

            "muted":       "#aaaacc",
            "info":        "#2563eb",
            "success":     "#00a060",
            "warning":     "#d97706",
            "error":       "#dc2626",

            "logo": "logo_light.png",
        },
        "font_family": "Inter, Segoe UI, system-ui",
        "font_size": 13,
        "radius": 12,
    }


def build_qss() -> str:
    if not _data:
        load()
    defaults = _defaults_raw()["dark"]
    d = {**defaults, **_data} if _data else defaults
    ff = d.get("font_family", "Inter, Segoe UI, system-ui")
    fs = int(d.get("font_size", 13))
    r  = int(d.get("radius", 12))
    is_dark = d.get("mode", "dark") == "dark"

    return f"""
/* ── Temel ── */
* {{
    font-family: "{ff}";
    font-size: {fs}px;
    color: {d['text']};
    outline: none;
}}
QMainWindow, QWidget#main_root {{
    background: {d['background']};
}}
QWidget {{
    background: transparent;
}}

/* ── Scrollbar — ince ve zarif ── */
QScrollBar:vertical {{
    background: transparent;
    width: 5px;
    margin: 0;
    border: none;
}}
QScrollBar::handle:vertical {{
    background: {d['border2']};
    border-radius: 3px;
    min-height: 24px;
}}
QScrollBar::handle:vertical:hover {{
    background: {d['text_muted']};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
    background: transparent;
    height: 0;
}}
QScrollBar:horizontal {{
    height: 5px;
    background: transparent;
    border: none;
}}
QScrollBar::handle:horizontal {{
    background: {d['border2']};
    border-radius: 3px;
}}
QScrollArea {{
    background: transparent;
    border: none;
}}

/* ── Input alanları ── */
QLineEdit, QPlainTextEdit {{
    background: {d['surface2']};
    border: 1px solid {d['border2']};
    border-radius: {r}px;
    padding: 8px 14px;
    color: {d['text']};
    selection-background-color: {d['accent_dim']};
}}
QLineEdit:focus, QPlainTextEdit:focus {{
    border: 1px solid {d['accent']};
    background: {d['surface3']};
}}
QLineEdit:hover, QPlainTextEdit:hover {{
    border-color: {d['border2']};
}}
QTextEdit {{
    background: {d['surface2']};
    border: 1px solid {d['border']};
    border-radius: {r}px;
    padding: 8px 12px;
    color: {d['text']};
}}

/* ── Butonlar ── */
QPushButton {{
    background: {d['surface2']};
    border: 1px solid {d['border2']};
    border-radius: {r}px;
    padding: 7px 18px;
    color: {d['text_dim']};
    font-weight: 500;
}}
QPushButton:hover {{
    background: {d['surface3']};
    color: {d['text']};
    border-color: {d['text_muted']};
}}
QPushButton:pressed {{
    background: {d['border2']};
}}
QPushButton:disabled {{
    color: {d['text_muted']};
    background: {d['surface']};
    border-color: {d['border']};
}}
QPushButton#primary {{
    background: {d['accent']};
    color: {d['accent_text']};
    border: none;
    font-weight: 700;
    letter-spacing: 0.3px;
}}
QPushButton#primary:hover {{
    background: {d['accent_dim']};
}}
QPushButton#primary:pressed {{
    background: {d['accent_dim']};
}}
QPushButton#danger {{
    background: transparent;
    border: 1px solid {d['error']};
    color: {d['error']};
}}
QPushButton#danger:hover {{
    background: {d['error']};
    color: white;
}}

/* ── Tab widget ── */
QTabWidget::pane {{
    border: 1px solid {d['border']};
    background: {d['surface']};
    border-radius: {r}px;
    top: -1px;
}}
QTabBar {{
    background: transparent;
}}
QTabBar::tab {{
    background: transparent;
    color: {d['text_muted']};
    border: none;
    border-bottom: 2px solid transparent;
    padding: 7px 18px;
    margin-right: 2px;
    font-size: 12px;
    font-weight: 500;
}}
QTabBar::tab:selected {{
    color: {d['accent']};
    border-bottom: 2px solid {d['accent']};
}}
QTabBar::tab:hover:!selected {{
    color: {d['text_dim']};
}}
QTabBar::close-button {{
    image: none;
    subcontrol-position: right;
    padding: 2px;
}}

/* ── Liste widget ── */
QListWidget {{
    background: transparent;
    border: none;
    outline: none;
}}
QListWidget::item {{
    padding: 7px 10px;
    border-radius: 8px;
    color: {d['text_dim']};
    font-size: 12px;
    margin: 1px 0;
}}
QListWidget::item:hover {{
    background: {d['surface3']};
    color: {d['text']};
}}
QListWidget::item:selected {{
    background: {d['surface3']};
    color: {d['accent']};
}}

/* ── Progress bar ── */
QProgressBar {{
    background: {d['border']};
    border: none;
    border-radius: 3px;
    height: 4px;
}}
QProgressBar::chunk {{
    background: {d['accent']};
    border-radius: 3px;
}}

/* ── Combobox ── */
QComboBox {{
    background: {d['surface2']};
    border: 1px solid {d['border2']};
    border-radius: {r}px;
    padding: 6px 12px;
    color: {d['text']};
}}
QComboBox:hover {{
    border-color: {d['text_muted']};
}}
QComboBox::drop-down {{
    border: none;
    width: 24px;
}}
QComboBox QAbstractItemView {{
    background: {d['surface2']};
    border: 1px solid {d['border2']};
    border-radius: {r}px;
    color: {d['text']};
    selection-background-color: {d['surface3']};
    outline: none;
}}

/* ── Menu ── */
QMenu {{
    background: {d['surface2']};
    border: 1px solid {d['border2']};
    border-radius: {r}px;
    padding: 6px 4px;
    color: {d['text']};
}}
QMenu::item {{
    padding: 8px 20px 8px 14px;
    border-radius: 8px;
    margin: 1px 4px;
    font-size: 12px;
}}
QMenu::item:selected {{
    background: {d['surface3']};
    color: {d['text']};
}}
QMenu::separator {{
    height: 1px;
    background: {d['border']};
    margin: 4px 8px;
}}

/* ── Frame / Kart ── */
QFrame[frameShape="4"], QFrame[frameShape="5"] {{
    background: transparent;
    border: none;
    border-top: 1px solid {d['border']};
}}

/* ── Tooltip ── */
QToolTip {{
    background: {d['surface3']};
    color: {d['text']};
    border: 1px solid {d['border2']};
    border-radius: 8px;
    padding: 6px 10px;
    font-size: 11px;
}}

/* ── Splitter ── */
QSplitter::handle {{
    background: {d['border']};
}}
QSplitter::handle:horizontal {{
    width: 1px;
}}
QSplitter::handle:vertical {{
    height: 1px;
}}
"""
