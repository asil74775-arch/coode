# radar.py — Yakındaki uçak radarı
# OpenSky Network API + IP-tabanlı konum tespiti.
# RadarMap: paintEvent ile uçakları çizen QWidget.

import math
import requests
from PySide6.QtCore    import QThread, Signal, Qt, QPointF
from PySide6.QtGui     import QPainter, QColor, QPen, QBrush, QPolygonF, QFont
from PySide6.QtWidgets import (
    QWidget, QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QSizePolicy,
)
from PySide6.QtCore import QEvent
from config import OPENSKY_RADIUS_DEG

# İl düzeyinde yaklaşık yarıçap (~30 km → 0.27 derece)
CITY_RADIUS_DEG = 0.27


# ── Konum tespiti ─────────────────────────────────────────────────────────────
def get_location() -> tuple[float, float]:
    try:
        r = requests.get("https://ipapi.co/json/", timeout=5)
        d = r.json()
        return float(d["latitude"]), float(d["longitude"])
    except Exception:
        return 41.0, 28.9  # İstanbul fallback


# ── OpenSky API ───────────────────────────────────────────────────────────────
def fetch_flights(lat: float, lon: float) -> list[dict]:
    r = OPENSKY_RADIUS_DEG
    url = (
        f"https://opensky-network.org/api/states/all"
        f"?lamin={lat-r}&lomin={lon-r}&lamax={lat+r}&lomax={lon+r}"
    )
    try:
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        data   = resp.json()
        states = data.get("states") or []
    except Exception:
        return []

    flights = []
    for s in states:
        if s[5] is None or s[6] is None:
            continue
        flights.append({
            "icao":      s[0] or "",
            "callsign":  (s[1] or "").strip(),
            "origin":    s[2] or "?",
            "longitude": s[5],
            "latitude":  s[6],
            "altitude":  int(s[7] or 0),
            "speed":     int((s[9] or 0) * 3.6),  # m/s → km/h
            "heading":   s[10] or 0,
            "on_ground": bool(s[8]),
        })
    return flights


# ── QThread Worker ────────────────────────────────────────────────────────────
class RadarWorker(QThread):
    done  = Signal(float, float, list)
    error = Signal(str)

    def run(self):
        try:
            lat, lon = get_location()
            flights  = fetch_flights(lat, lon)
            self.done.emit(lat, lon, flights)
        except Exception as e:
            self.error.emit(str(e))


# ── Harita Widget ─────────────────────────────────────────────────────────────
class RadarMap(QWidget):
    flight_clicked = Signal(dict)

    # zoom sınırları (derece cinsinden yarıçap)
    _ZOOM_MIN = 0.08   # ~8 km — çok yakın
    _ZOOM_MAX = 3.0    # ~330 km — geniş

    def __init__(self, parent=None):
        super().__init__(parent)
        self._flights:  list[dict] = []
        self._center_lat = 41.0
        self._center_lon = 28.9
        self._radius     = CITY_RADIUS_DEG   # başlangıç: il düzeyi
        self._pinch_base = None              # pinch başlangıç mesafesi
        self.setMinimumSize(200, 200)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setCursor(Qt.PointingHandCursor)
        self.setAttribute(Qt.WA_AcceptTouchEvents, True)
        self.grabGesture(Qt.PinchGesture)

    def update_data(self, lat: float, lon: float, flights: list[dict]):
        self._center_lat = lat
        self._center_lon = lon
        # Sadece il yarıçapı içindeki uçakları filtrele
        self._flights = [
            f for f in flights
            if abs(f["latitude"] - lat) <= self._radius * 1.5
            and abs(f["longitude"] - lon) <= self._radius * 1.5
        ]
        self.update()

    def _to_px(self, lat: float, lon: float) -> QPointF:
        w, h = self.width(), self.height()
        r    = self._radius
        x = (lon - (self._center_lon - r)) / (2 * r) * w
        y = ((self._center_lat + r) - lat) / (2 * r) * h
        return QPointF(x, y)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#0d0d0d"))

        # Izgara
        pen = QPen(QColor("#1e1e1e"))
        pen.setWidth(1)
        p.setPen(pen)
        for i in range(1, 4):
            p.drawLine(self.width() * i // 4, 0, self.width() * i // 4, self.height())
            p.drawLine(0, self.height() * i // 4, self.width(), self.height() * i // 4)

        # Merkez (sen)
        cx, cy = self.width() // 2, self.height() // 2
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(QColor("#e8e8e8")))
        p.drawEllipse(cx - 3, cy - 3, 6, 6)

        # Zoom seviyesi yazısı
        p.setPen(QPen(QColor("#333333")))
        p.setFont(QFont("Consolas", 7))
        km = int(self._radius * 111)
        p.drawText(4, self.height() - 4, f"r≈{km}km")

        # Uçaklar
        p.setFont(QFont("Consolas", 7))
        for f in self._flights:
            px = self._to_px(f["latitude"], f["longitude"])
            if not (0 <= px.x() <= self.width() and 0 <= px.y() <= self.height()):
                continue
            color = QColor("#888888") if f["on_ground"] else QColor("#4fc3f7")
            self._draw_plane(p, px, f.get("heading", 0), color)
            p.setPen(QPen(QColor("#555555")))
            p.drawText(int(px.x()) + 7, int(px.y()) - 3, f.get("callsign", ""))

    @staticmethod
    def _draw_plane(painter, pos, heading, color):
        painter.save()
        painter.translate(pos)
        painter.rotate(heading)
        pts = QPolygonF([QPointF(0, -7), QPointF(4, 4), QPointF(0, 1), QPointF(-4, 4)])
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(color))
        painter.drawPolygon(pts)
        painter.restore()

    # ── Zoom: fare tekerleği ──────────────────────────────────────────────────
    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        factor = 0.85 if delta > 0 else 1.18
        self._radius = max(self._ZOOM_MIN, min(self._ZOOM_MAX, self._radius * factor))
        self.update()

    # ── Zoom: iki parmak pinch (touchpad) ────────────────────────────────────
    def event(self, ev):
        if ev.type() == QEvent.Gesture:
            pinch = ev.gesture(Qt.PinchGesture)
            if pinch:
                scale = pinch.scaleFactor()
                if scale and scale != 1.0:
                    self._radius = max(self._ZOOM_MIN, min(self._ZOOM_MAX, self._radius / scale))
                    self.update()
            return True
        return super().event(ev)

    def mousePressEvent(self, event):
        for f in self._flights:
            px = self._to_px(f["latitude"], f["longitude"])
            if math.hypot(event.x() - px.x(), event.y() - px.y()) < 12:
                self.flight_clicked.emit(f)
                return
        super().mousePressEvent(event)


# ── Detay Diyaloğu ─────────────────────────────────────────────────────────────
class FlightDetailDialog(QDialog):
    def __init__(self, flight: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Uçuş Detayı — {flight.get('callsign','?')}")
        self.setStyleSheet("background:#141414; color:#e0e0e0;")
        self.setMinimumWidth(300)

        lay = QVBoxLayout(self)
        lay.setSpacing(8)

        rows = [
            ("ICAO",        flight.get("icao", "?")),
            ("Sefer",       flight.get("callsign", "?")),
            ("Kaynak ülke", flight.get("origin", "?")),
            ("İrtifa",      f"{flight.get('altitude', 0)} m"),
            ("Hız",         f"{flight.get('speed', 0)} km/h"),
            ("Yön",         f"{int(flight.get('heading', 0))}°"),
            ("Yerde mi",    "Evet" if flight.get("on_ground") else "Hayır"),
        ]
        for k, v in rows:
            row = QHBoxLayout()
            lbl_k = QLabel(k)
            lbl_k.setStyleSheet("color:#666; font-size:12px;")
            lbl_k.setFixedWidth(110)
            lbl_v = QLabel(v)
            lbl_v.setStyleSheet("color:#e0e0e0; font-size:12px;")
            row.addWidget(lbl_k)
            row.addWidget(lbl_v)
            lay.addLayout(row)

        btn = QPushButton("✈  FlightRadar24'te Göster")
        btn.setStyleSheet(
            "background:#1565c0; color:#fff; border:none; "
            "border-radius:8px; padding:10px; font-size:13px;"
        )
        callsign = flight.get("callsign", "").replace(" ", "")
        btn.clicked.connect(
            lambda: self._open_fr24(callsign)
        )
        lay.addWidget(btn)

    @staticmethod
    def _open_fr24(callsign: str):
        import webbrowser
        webbrowser.open(f"https://www.flightradar24.com/{callsign}")


# ── Büyük Radar Diyaloğu ──────────────────────────────────────────────────────
class RadarFullDialog(QDialog):
    """Tam ekran radar görünümü — sol paneldeki 'büyüt' butonuyla açılır."""

    def __init__(self, lat: float, lon: float, flights: list, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Radar — Yakın Uçaklar")
        self.resize(800, 700)
        self.setStyleSheet("background:#0d0d0d;")

        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)

        # Üst çubuk
        bar = QHBoxLayout()
        count_lbl = QLabel(f"{len(flights)} uçak görünüyor")
        count_lbl.setStyleSheet("color:#666; font-size:11px;")
        bar.addWidget(count_lbl)
        bar.addStretch()
        close_btn = QPushButton("Kapat")
        close_btn.setStyleSheet(
            "background:#1a1a1a; color:#aaa; border:1px solid #333; "
            "border-radius:6px; padding:4px 14px;"
        )
        close_btn.clicked.connect(self.close)
        bar.addWidget(close_btn)
        lay.addLayout(bar)

        # Büyük harita
        self._map = RadarMap()
        self._map.update_data(lat, lon, flights)
        self._map.flight_clicked.connect(lambda f: FlightDetailDialog(f, self).exec())
        lay.addWidget(self._map, stretch=1)
