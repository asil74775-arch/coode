# splash.py — Coode açılış ekranı v3.7.2
# Premium animasyon: fade-in → 1s bekle → fade-out → finished

import os
from PySide6.QtCore    import Qt, QTimer, QPropertyAnimation, QEasingCurve, Signal
from PySide6.QtGui     import QPixmap, QPainter, QColor, QPainterPath, QLinearGradient, QRadialGradient
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QGraphicsOpacityEffect, QApplication
from config import RES_DIR as BASE_DIR, APP_VERSION
import theme as th


class SplashScreen(QWidget):
    finished = Signal()

    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(380, 380)

        screen = QApplication.primaryScreen().geometry()
        self.move(screen.center().x() - 190, screen.center().y() - 190)

        self._eff = QGraphicsOpacityEffect(self)
        self._eff.setOpacity(0.0)
        self.setGraphicsEffect(self._eff)

        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignCenter)
        lay.setSpacing(0)
        lay.setContentsMargins(0, 0, 0, 0)

        # ── Merkez daire kart ─────────────────────────────────────────────────
        card = _SplashCard()
        card.setFixedSize(280, 280)

        # Logo içinde
        inner = QVBoxLayout(card)
        inner.setAlignment(Qt.AlignCenter)
        inner.setSpacing(6)

        logo_path = os.path.join(BASE_DIR,
                                 "logo_light.png" if th.get("mode") == "light" else "logo_dark.png")
        self._logo_lbl = QLabel()
        if os.path.isfile(logo_path):
            pix = QPixmap(logo_path).scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self._logo_lbl.setPixmap(pix)
        else:
            self._logo_lbl.setText("C")
            self._logo_lbl.setStyleSheet(
                f"color:{th.get('accent')}; font-size:72px; font-weight:900; background:transparent;"
            )
        self._logo_lbl.setAlignment(Qt.AlignCenter)
        inner.addWidget(self._logo_lbl)

        name_lbl = QLabel("COODE")
        name_lbl.setAlignment(Qt.AlignCenter)
        name_lbl.setStyleSheet(
            f"color:{th.get('text')}; font-size:22px; font-weight:900; "
            f"letter-spacing:8px; background:transparent;"
        )
        inner.addWidget(name_lbl)

        tagline = QLabel("Kisisel Yapay Zeka")
        tagline.setAlignment(Qt.AlignCenter)
        tagline.setStyleSheet(
            f"color:{th.get('text_muted')}; font-size:11px; "
            f"letter-spacing:1px; background:transparent;"
        )
        inner.addWidget(tagline)

        lay.addWidget(card)
        lay.addSpacing(16)

        # Versiyon etiketi (kartın dışında)
        ver_lbl = QLabel(f"v{APP_VERSION}")
        ver_lbl.setAlignment(Qt.AlignCenter)
        ver_lbl.setStyleSheet(
            f"color:{th.get('text_muted')}; font-size:10px; background:transparent;"
        )
        lay.addWidget(ver_lbl)

        self._start()

    def _start(self):
        anim = QPropertyAnimation(self._eff, b"opacity", self)
        anim.setDuration(600)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.finished.connect(lambda: QTimer.singleShot(1000, self._fade_out))
        anim.start()
        self._anim_in = anim

    def _fade_out(self):
        anim = QPropertyAnimation(self._eff, b"opacity", self)
        anim.setDuration(500)
        anim.setStartValue(1.0)
        anim.setEndValue(0.0)
        anim.setEasingCurve(QEasingCurve.InCubic)
        anim.finished.connect(self._done)
        anim.start()
        self._anim_out = anim

    def _done(self):
        self.close()
        self.finished.emit()


class _SplashCard(QWidget):
    """Özel çizimli yuvarlak kart — arka plan gradyan + ince çerçeve."""

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        w, h = self.width(), self.height()
        r    = 32

        # Gradyan arka plan
        grad = QRadialGradient(w / 2, h / 2, w * 0.6)
        grad.setColorAt(0.0, QColor(th.get("surface2") or "#161625"))
        grad.setColorAt(1.0, QColor(th.get("surface")  or "#0f0f1a"))

        path = QPainterPath()
        path.addRoundedRect(0, 0, w, h, r, r)
        p.fillPath(path, grad)

        # Accent glow — üst kenarda
        glow = QLinearGradient(0, 0, w, 0)
        accent = th.get("accent") or "#00c97a"
        glow.setColorAt(0.0,  QColor(0, 0, 0, 0))
        glow.setColorAt(0.35, QColor(accent))
        glow.setColorAt(0.65, QColor(accent))
        glow.setColorAt(1.0,  QColor(0, 0, 0, 0))

        from PySide6.QtGui import QPen
        pen = QPen(glow, 1.5)
        p.setPen(pen)
        p.drawLine(int(w * 0.15), 0, int(w * 0.85), 0)

        # Çerçeve
        border_pen = QPen(QColor(th.get("border2") or "#2a2a45"), 1)
        p.setPen(border_pen)
        p.drawPath(path)
