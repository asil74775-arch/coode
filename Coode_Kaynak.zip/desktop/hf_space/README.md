---
title: Coode API
emoji: 🤖
colorFrom: green
colorTo: green
sdk: docker
pinned: false
---

# Coode API v3.7.2

Coode yapay zeka asistanının HF Spaces üzerindeki API sunucusu.  
GPU'suz sistemlerde Coode masaüstü uygulamasını bu API üzerinden kullanabilirsiniz.

## Kullanım

Coode masaüstü uygulamasında:  
**Ayarlar → Hugging Face API → API URL** alanına bu Space'in URL'sini girin:

```
https://KULLANICI_ADI-coode-api.hf.space
```

## Endpoint'ler

| Endpoint | Method | Açıklama |
|----------|--------|----------|
| `/health` | GET | Sunucu durumu |
| `/chat`   | POST | Streaming sohbet (SSE) |

## Environment Variables (HF Secrets)

| Değişken | Açıklama |
|----------|----------|
| `MODEL_ID` | HF model repo adı (örn: `kullanici/coode-ft`) |
| `HF_TOKEN` | Private model için HF token |
| `API_KEY`  | İsteğe bağlı API koruması |
