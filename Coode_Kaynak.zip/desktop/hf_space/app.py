# hf_space/app.py — Coode API Sunucusu (HF Spaces)
#
# Bu dosya Hugging Face Spaces'te çalışır.
# Fine-tune edilmiş Coode modelini yükler ve
# SSE (Server-Sent Events) ile token stream eder.
#
# Deployment:
#   1. Bu klasörü HF'e yükle (hf_space/ içeriğini)
#   2. HF Spaces -> New Space -> SDK: Docker veya Gradio
#   3. MODEL_ID'yi kendi HF repo adınla güncelle

import json
import os
import threading
from typing import Generator

from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

# ── Ayarlar ───────────────────────────────────────────────────────────────────
MODEL_ID  = os.getenv("MODEL_ID", "your-username/coode-ft")   # HF repo adı
HF_TOKEN  = os.getenv("HF_TOKEN", "")                         # private model için
API_KEY   = os.getenv("API_KEY",  "")                         # isteğe bağlı koruma

# ── FastAPI ───────────────────────────────────────────────────────────────────
app = FastAPI(title="Coode API", version="3.7.2")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Model yükleme ─────────────────────────────────────────────────────────────
print(f"[coode-api] Model yükleniyor: {MODEL_ID}")
_tokenizer = None
_model     = None

try:
    from transformers import AutoTokenizer, AutoModelForCausalLM, TextIteratorStreamer
    import torch

    _tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID,
        token=HF_TOKEN or None,
    )
    _model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID,
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        device_map="auto",
        token=HF_TOKEN or None,
    )
    _model.eval()
    print(f"[coode-api] Model hazir. Device: {next(_model.parameters()).device}")
except Exception as e:
    print(f"[coode-api] HATA — model yuklenemedi: {e}")


# ── Request / Response modelleri ──────────────────────────────────────────────
class ChatRequest(BaseModel):
    messages:    list[dict]
    temperature: float = 0.7
    top_p:       float = 0.9
    max_tokens:  int   = 512


# ── Yetkilendirme ─────────────────────────────────────────────────────────────
def _check_auth(authorization: str | None):
    if not API_KEY:
        return   # API_KEY boşsa herkes kullanabilir
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Yetkisiz")
    token = authorization[7:]
    if token != API_KEY:
        raise HTTPException(status_code=403, detail="Gecersiz token")


# ── SSE üreteci ───────────────────────────────────────────────────────────────
def _stream_response(request: ChatRequest) -> Generator[str, None, None]:
    if _model is None or _tokenizer is None:
        yield 'data: {"token": "Model yuklenemedi. Lutfen HF Space loglarini kontrol edin."}\n\n'
        yield "data: [DONE]\n\n"
        return

    import torch
    inputs   = _tokenizer.apply_chat_template(
        request.messages,
        return_tensors="pt",
        add_generation_prompt=True,
    ).to(_model.device)

    streamer = TextIteratorStreamer(
        _tokenizer, skip_prompt=True, skip_special_tokens=True
    )
    gen_kwargs = dict(
        input_ids=inputs,
        max_new_tokens=request.max_tokens,
        do_sample=True,
        temperature=request.temperature,
        top_p=request.top_p,
        streamer=streamer,
    )

    t = threading.Thread(target=_model.generate, kwargs=gen_kwargs, daemon=True)
    t.start()

    for token in streamer:
        payload = json.dumps({"token": token}, ensure_ascii=False)
        yield f"data: {payload}\n\n"

    yield "data: [DONE]\n\n"


# ── Endpoint'ler ──────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {
        "status":  "ok",
        "model":   MODEL_ID,
        "loaded":  _model is not None,
        "version": "3.7.2",
    }


@app.post("/chat")
def chat(
    request: ChatRequest,
    authorization: str | None = Header(default=None),
):
    _check_auth(authorization)
    return StreamingResponse(
        _stream_response(request),
        media_type="text/event-stream",
        headers={
            "Cache-Control":     "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ── Yerel test ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=7860)
