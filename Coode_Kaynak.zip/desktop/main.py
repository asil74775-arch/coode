# main.py — Coode masaüstü uygulaması v3
# Sekmeler: Sohbet · Artifact · Araştırma · Dosya · App Lab · gloWeb · Ayarlar

import sys
import argparse
import threading
from PySide6.QtCore    import Qt, QSize, QTimer
from PySide6.QtGui     import QPixmap, QFont
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QStackedWidget,
    QHBoxLayout, QVBoxLayout, QLabel, QLineEdit,
    QPushButton, QListWidget, QListWidgetItem,
    QTabWidget, QTextEdit, QSplitter, QFrame,
    QScrollArea, QMenu, QInputDialog, QMessageBox,
)

import theme as th
import memory as mem
from config   import APP_NAME, APP_VERSION, BASE_DIR
from widgets  import TelemetryBar, ChatView, ChatBubble, AppLabCard, ApprovalDialog
from onboarding     import OnboardingScreen
from tour           import TourOverlay
from radar          import RadarMap, RadarWorker, FlightDetailDialog, RadarFullDialog
from telemetry      import TelemetryWorker
from llm            import build_messages, GenerateWorker, load_local
from sandbox        import run_code, run_app, list_apps
from artifact_panel import ArtifactPanel
from file_reader    import FileReaderPanel
from settings_panel import SettingsPanel


def _parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--no-model", action="store_true")
    return p.parse_args()


# ── Sol Panel ──────────────────────────────────────────────────────────────────
class LeftPanel(QWidget):
    def __init__(self, user_name: str, main_win, parent=None):
        super().__init__(parent)
        self.setObjectName("left_panel")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setFixedWidth(232)
        self._main = main_win
        self._apply_style()

        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 18, 14, 14)
        lay.setSpacing(0)

        # ── Logo + başlık ─────────────────────────────────────────────────────
        logo_row = QHBoxLayout()
        logo_row.setSpacing(10)
        import os
        self._logo_lbl = QLabel()
        self._update_logo()
        self._logo_lbl.setFixedSize(30, 30)
        self._logo_lbl.setStyleSheet("background:transparent; border:none;")
        logo_row.addWidget(self._logo_lbl)

        title_col = QVBoxLayout()
        title_col.setSpacing(0)
        title_lbl = QLabel("COODE")
        title_lbl.setStyleSheet(
            f"color:{th.get('text')}; font-size:14px; font-weight:800; "
            f"letter-spacing:3px; background:transparent;"
        )
        ver_lbl = QLabel(f"v{APP_VERSION}")
        ver_lbl.setStyleSheet(
            f"color:{th.get('text_muted')}; font-size:9px; "
            f"letter-spacing:1px; background:transparent;"
        )
        title_col.addWidget(title_lbl)
        title_col.addWidget(ver_lbl)
        logo_row.addLayout(title_col)
        logo_row.addStretch()
        lay.addLayout(logo_row)
        lay.addSpacing(20)

        # ── Navigasyon butonları ──────────────────────────────────────────────
        def _nav_btn(label, icon_txt, slot):
            btn = QPushButton(f"  {icon_txt}  {label}")
            btn.setStyleSheet(
                f"QPushButton{{background:transparent; color:{th.get('text_dim')}; "
                f"border:none; border-radius:10px; padding:9px 12px; "
                f"font-size:12px; font-weight:500; text-align:left;}}"
                f"QPushButton:hover{{background:{th.get('surface3')}; color:{th.get('text')};}}"
            )
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(slot)
            return btn

        lay.addWidget(_nav_btn("Artifact",  "◈", lambda: main_win._show_panel("artifact")))
        lay.addWidget(_nav_btn("Dosyalar",  "◉", lambda: main_win._show_panel("files")))
        lay.addWidget(_nav_btn("Sohbet",    "◇", lambda: main_win._show_panel("chat")))
        lay.addWidget(_nav_btn("Ayarlar",   "◎", lambda: main_win._show_panel("settings")))
        lay.addSpacing(16)

        # ── Ayırıcı ──────────────────────────────────────────────────────────
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setFixedHeight(1)
        sep.setStyleSheet(f"background:{th.get('border')}; border:none;")
        lay.addWidget(sep)
        lay.addSpacing(12)

        # ── Yeni sohbet ───────────────────────────────────────────────────────
        new_btn = QPushButton("+  Yeni Sohbet")
        new_btn.setFixedHeight(38)
        new_btn.setStyleSheet(
            f"QPushButton{{background:{th.get('accent')}; color:{th.get('accent_text')}; "
            f"border:none; border-radius:12px; font-size:12px; font-weight:700;}}"
            f"QPushButton:hover{{background:{th.get('accent_dim')};}}"
        )
        new_btn.setCursor(Qt.PointingHandCursor)
        new_btn.clicked.connect(main_win._new_session)
        lay.addWidget(new_btn)
        lay.addSpacing(16)

        # ── Oturum listesi ────────────────────────────────────────────────────
        sec_lbl = QLabel("SOHBETLER")
        sec_lbl.setStyleSheet(
            f"color:{th.get('text_muted')}; font-size:9px; font-weight:700; "
            f"letter-spacing:1.5px; background:transparent;"
        )
        lay.addWidget(sec_lbl)
        lay.addSpacing(4)

        self._session_list = QListWidget()
        self._session_list.setStyleSheet(
            f"QListWidget{{background:transparent; border:none; outline:none;}}"
            f"QListWidget::item{{color:{th.get('text_dim')}; padding:8px 10px; "
            f"border-radius:10px; margin:1px 0;}}"
            f"QListWidget::item:hover{{background:{th.get('surface3')}; color:{th.get('text')};}}"
            f"QListWidget::item:selected{{background:{th.get('surface3')}; color:{th.get('accent')};}}"
        )
        self._session_list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._session_list.itemClicked.connect(self._on_session_click)
        self._session_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self._session_list.customContextMenuRequested.connect(self._session_ctx_menu)
        lay.addWidget(self._session_list, stretch=1)
        lay.addSpacing(10)

        # ── Radar ─────────────────────────────────────────────────────────────
        radar_hdr = QHBoxLayout()
        radar_hdr.setContentsMargins(0, 0, 0, 0)
        sec_radar = QLabel("YAKIN UCAKLAR")
        sec_radar.setStyleSheet(
            f"color:{th.get('text_muted')}; font-size:9px; font-weight:700; "
            f"letter-spacing:1.5px; background:transparent;"
        )
        radar_hdr.addWidget(sec_radar)
        radar_hdr.addStretch()
        exp_btn = QPushButton("⤢")
        exp_btn.setFixedSize(20, 20)
        exp_btn.setToolTip("Buyut")
        exp_btn.setStyleSheet(
            f"background:transparent; color:{th.get('text_muted')}; "
            f"border:none; font-size:12px;"
        )
        exp_btn.clicked.connect(self._expand_radar)
        radar_hdr.addWidget(exp_btn)
        lay.addLayout(radar_hdr)
        lay.addSpacing(4)

        self.radar_map = RadarMap()
        self.radar_map.setFixedHeight(110)
        self.radar_map.flight_clicked.connect(self._on_flight_click)
        lay.addWidget(self.radar_map)
        lay.addSpacing(12)

        self._radar_lat  = 41.0
        self._radar_lon  = 28.9
        self._radar_data = []

        # ── Telemetri ─────────────────────────────────────────────────────────
        sec_tel = QLabel("SISTEM")
        sec_tel.setStyleSheet(
            f"color:{th.get('text_muted')}; font-size:9px; font-weight:700; "
            f"letter-spacing:1.5px; background:transparent;"
        )
        lay.addWidget(sec_tel)
        lay.addSpacing(4)
        self.telemetry_bar = TelemetryBar()
        lay.addWidget(self.telemetry_bar)
        lay.addSpacing(10)

        # ── Kullanıcı adı ─────────────────────────────────────────────────────
        uname_row = QHBoxLayout()
        dot = QLabel("●")
        dot.setStyleSheet(f"color:{th.get('accent')}; font-size:8px; background:transparent;")
        uname_lbl = QLabel(user_name)
        uname_lbl.setStyleSheet(
            f"color:{th.get('text_dim')}; font-size:11px; font-weight:500; background:transparent;"
        )
        uname_row.addWidget(dot)
        uname_row.addWidget(uname_lbl)
        uname_row.addStretch()
        lay.addLayout(uname_row)

        self.refresh_sessions()

    def _apply_style(self):
        # Seçicili stil: sadece panelin kendisine uygulanır, çocuklara çerçeve basmaz
        self.setStyleSheet(
            f"QWidget#left_panel{{background:{th.get('surface')}; "
            f"border:1px solid {th.get('border')}; border-radius:18px;}}"
            f"QLabel{{background:transparent; border:none;}}"
        )

    def _update_logo(self):
        import os
        path = th.logo_path()
        if os.path.isfile(path):
            pix = QPixmap(path).scaled(30, 30, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self._logo_lbl.setPixmap(pix)

    def refresh_theme(self):
        self._apply_style()
        self._update_logo()

    def refresh_sessions(self):
        self._session_list.clear()
        for s in mem.list_sessions():
            custom  = mem.get_session_name(s["session"])
            name    = custom if custom != s["session"] else (s.get("preview") or "Sohbet")
            name    = name.replace("\n", " ")
            item    = QListWidgetItem(name[:26] + ("…" if len(name) > 26 else ""))
            item.setToolTip(name)
            item.setData(Qt.UserRole, s["session"])
            self._session_list.addItem(item)

    def _on_session_click(self, item):
        self._main._load_session(item.data(Qt.UserRole))

    def _session_ctx_menu(self, pos):
        item = self._session_list.itemAt(pos)
        if not item:
            return
        sid = item.data(Qt.UserRole)
        menu = QMenu(self)
        menu.setStyleSheet(
            f"QMenu{{background:{th.get('surface')}; color:{th.get('text')}; "
            f"border:1px solid {th.get('border')}; border-radius:8px; padding:4px;}}"
            f"QMenu::item{{padding:6px 20px; border-radius:4px;}}"
            f"QMenu::item:selected{{background:{th.get('border')};}}"
        )
        act_rename = menu.addAction("Yeniden Adlandır")
        act_delete = menu.addAction("Sil")
        act = menu.exec(self._session_list.mapToGlobal(pos))
        if act == act_rename:
            self._rename_session(item, sid)
        elif act == act_delete:
            self._delete_session(item, sid)

    def _rename_session(self, item, sid):
        name, ok = QInputDialog.getText(self, "Yeniden Adlandır",
                                        "Yeni isim:", text=item.text())
        if ok and name.strip():
            mem.rename_session(sid, name.strip())
            self.refresh_sessions()

    def _delete_session(self, item, sid):
        r = QMessageBox.question(self, "Sil",
                                 f"Bu sohbet silinsin mi?",
                                 QMessageBox.Yes | QMessageBox.No)
        if r == QMessageBox.Yes:
            mem.delete_session(sid)
            self.refresh_sessions()

    def _on_flight_click(self, flight):
        FlightDetailDialog(flight, self).exec()

    def _expand_radar(self):
        dlg = RadarFullDialog(self._radar_lat, self._radar_lon, self._radar_data, self)
        dlg.exec()


# ── Sohbet Paneli ─────────────────────────────────────────────────────────────
class ChatPanel(QWidget):
    def __init__(self, user_name: str, main_win, parent=None):
        super().__init__(parent)
        self._main    = main_win
        self._user    = user_name
        self._session = ""
        self._worker  = None
        self._stream_buf = ""

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self._chat_view = ChatView()
        lay.addWidget(self._chat_view, stretch=1)

        self._stream_bubble_widget = None

        # ── Girdi alanı ───────────────────────────────────────────────────────
        input_wrapper = QWidget()
        input_wrapper.setStyleSheet("background:transparent;")
        ilay = QVBoxLayout(input_wrapper)
        ilay.setContentsMargins(24, 8, 24, 10)
        ilay.setSpacing(8)

        # Input satırı
        input_row = QHBoxLayout()
        input_row.setSpacing(8)

        self._input = QLineEdit()
        self._input.setPlaceholderText("Coode'a bir sey yaz...")
        self._input.setFixedHeight(48)
        self._input.setStyleSheet(
            f"QLineEdit{{background:{th.get('surface2')}; color:{th.get('text')}; "
            f"border:1px solid {th.get('border2')}; border-radius:24px; "
            f"padding:0px 22px; font-size:13px;}}"
            f"QLineEdit:focus{{border:1px solid {th.get('accent')};}}"
        )
        self._input.returnPressed.connect(self._send)
        input_row.addWidget(self._input)

        from widgets import mic_icon, send_icon
        self._voice_btn = QPushButton()
        self._voice_btn.setFixedSize(QSize(48, 48))
        self._voice_btn.setToolTip("Sesle yaz (Windows dikte)")
        self._voice_btn.setCursor(Qt.PointingHandCursor)
        self._voice_btn.setIcon(mic_icon(th.get("text_dim")))
        self._voice_btn.setIconSize(QSize(22, 22))
        self._voice_btn.setStyleSheet(
            f"QPushButton{{background:{th.get('surface2')}; border:1px solid {th.get('border2')}; "
            f"border-radius:24px;}}"
            f"QPushButton:hover{{border-color:{th.get('accent')};}}"
        )
        self._voice_btn.clicked.connect(self._toggle_voice)
        input_row.addWidget(self._voice_btn)

        from widgets import speaker_icon
        self._speak_btn = QPushButton()
        self._speak_btn.setFixedSize(QSize(48, 48))
        self._speak_btn.setCursor(Qt.PointingHandCursor)
        self._speak_btn.setIconSize(QSize(22, 22))
        self._speak_btn.clicked.connect(self._toggle_speak)
        self._paint_speak()
        input_row.addWidget(self._speak_btn)

        self._send_btn = QPushButton()
        self._send_btn.setFixedSize(QSize(48, 48))
        self._send_btn.setToolTip("Gonder (Enter)")
        self._send_btn.setCursor(Qt.PointingHandCursor)
        self._send_btn.setIcon(send_icon(th.logo_path(), th.get("accent_text")))
        self._send_btn.setIconSize(QSize(46, 46))
        self._send_btn.setStyleSheet(
            f"QPushButton{{background:transparent; border:1px solid {th.get('border2')}; border-radius:24px;}}"
            f"QPushButton:hover{{border:1px solid {th.get('accent')};}}"
            f"QPushButton:disabled{{border:1px dashed {th.get('text_muted')};}}"
        )
        self._send_btn.clicked.connect(self._send)
        input_row.addWidget(self._send_btn)

        ilay.addLayout(input_row)

        disclaimer = QLabel("Coode bir yapay zekadır. Hatali olabilir.")
        disclaimer.setAlignment(Qt.AlignCenter)
        disclaimer.setStyleSheet(
            f"color:{th.get('text_muted')}; font-size:10px; background:transparent;"
        )
        ilay.addWidget(disclaimer)
        lay.addWidget(input_wrapper)

    def set_session(self, session_id: str):
        self._session = session_id

    def load_history(self):
        self._chat_view.clear()
        for msg in mem.get_history(self._session):
            self._chat_view.add_bubble(msg["role"], msg["content"])

    def insert_message(self, text: str):
        self._input.setText(text)
        self._send()

    def _send(self):
        text = self._input.text().strip()
        if not text or self._worker:
            return
        self._input.clear()
        self._chat_view.add_bubble("user", text)
        mem.save_message(self._session, "user", text)

        self._stream_buf = ""
        self._agent_steps = []
        self._send_btn.setEnabled(False)
        self._chat_view.add_streaming_bubble()

        history  = mem.get_history(self._session, limit=20)[:-1]
        messages = build_messages(history, text)

        # Agent mı sohbet mi? — otomatik karar
        from agent import should_use_agent, CodeAgentWorker
        from llm import _get_backend
        backend = _get_backend()
        use_agent = (
            should_use_agent(text)
            and backend == "groq"   # agent sadece Groq'ta (tool-use destekli)
        )

        if use_agent:
            from config import GROQ_API_KEY, GROQ_MODEL
            groq_key   = mem.get_pref("groq_api_key") or GROQ_API_KEY
            groq_model = mem.get_pref("groq_model") or GROQ_MODEL
            self._worker = CodeAgentWorker(messages, groq_key, groq_model)
            self._worker.step.connect(self._on_agent_step)
        else:
            self._worker = GenerateWorker(messages)

        self._worker.token.connect(self._on_token)
        self._worker.finished.connect(self._on_done)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_agent_step(self, step_desc: str):
        """CodeAgent bir araç çalıştırıyor — kullanıcıya adım bilgisi göster."""
        self._agent_steps.append(step_desc)
        steps = "\n".join(f"- `{x}`" for x in self._agent_steps[-6:])
        self._chat_view.update_streaming_bubble(f"**CodeAgent calisiyor**\n\n{steps}")

    def _on_token(self, tok):
        self._stream_buf += tok
        self._chat_view.update_streaming_bubble(self._stream_buf)

    def _on_done(self, full):
        from widgets import clean_ai_text
        full = clean_ai_text(full)
        shown = full
        if getattr(self, "_agent_steps", None):
            used = ", ".join(sorted(set(x.split("(")[0] for x in self._agent_steps)))
            shown = f"*CodeAgent: {used}*\n\n{full}"
        self._stream_buf = ""
        self._chat_view.finalize_streaming_bubble(shown)
        mem.save_message(self._session, "assistant", full)
        self._worker = None
        self._send_btn.setEnabled(True)
        self._main.left.refresh_sessions()
        if mem.get_pref("voice_reply", False):
            import speech
            speech.speak(full)

    def _on_error(self, msg):
        self._chat_view.finalize_streaming_bubble(f"Hata: {msg}")
        self._worker = None
        self._send_btn.setEnabled(True)

    def _paint_speak(self):
        from widgets import speaker_icon
        on = bool(mem.get_pref("voice_reply", False))
        self._speak_btn.setIcon(speaker_icon(th.get("accent") if on else th.get("text_dim"), on))
        self._speak_btn.setToolTip("Sesli cevap: " + ("acik" if on else "kapali"))
        self._speak_btn.setStyleSheet(
            f"QPushButton{{background:{th.get('surface2')}; border:1px solid "
            f"{th.get('accent') if on else th.get('border2')}; border-radius:24px;}}"
            f"QPushButton:hover{{border-color:{th.get('accent')};}}"
        )

    def _toggle_speak(self):
        on = not bool(mem.get_pref("voice_reply", False))
        mem.set_pref("voice_reply", on)
        if not on:
            import speech
            speech.stop()
        self._paint_speak()

    def _toggle_voice(self):
        """Windows'un yerleşik dikte özelliğini (Win+H) açar; konuştuğun metin kutuya yazılır."""
        self._input.setFocus()
        try:
            import pyautogui
            QTimer.singleShot(120, lambda: pyautogui.hotkey("win", "h"))
        except Exception:
            self._chat_view.add_bubble(
                "assistant", "Sesle yazmak icin klavyede **Windows + H** tusuna bas."
            )


# ── App Lab Paneli ────────────────────────────────────────────────────────────
class AppLabPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        header = QFrame()
        header.setFixedHeight(52)
        header.setStyleSheet(
            f"background:{th.get('surface')}; border-bottom:1px solid {th.get('border')};"
        )
        hlay = QHBoxLayout(header)
        hlay.setContentsMargins(16, 0, 16, 0)
        title = QLabel("App Lab")
        title.setStyleSheet(f"color:{th.get('text')}; font-size:15px; font-weight:bold;")
        ref_btn = QPushButton("Yenile")
        ref_btn.clicked.connect(self.refresh)
        hlay.addWidget(title)
        hlay.addStretch()
        hlay.addWidget(ref_btn)
        lay.addWidget(header)

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setStyleSheet("border:none;")
        self._inner     = QWidget()
        self._inner_lay = QVBoxLayout(self._inner)
        self._inner_lay.setAlignment(Qt.AlignTop)
        self._scroll.setWidget(self._inner)
        lay.addWidget(self._scroll)

        self._output = QLabel("")
        self._output.setWordWrap(True)
        self._output.setStyleSheet(
            f"background:{th.get('surface2')}; color:{th.get('text_dim')}; "
            f"border-radius:8px; padding:8px; font-family:Consolas; font-size:11px;"
        )
        self._output.setVisible(False)
        lay.addWidget(self._output)

        self.refresh()

    def refresh(self):
        while self._inner_lay.count():
            item = self._inner_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for app in list_apps():
            card = AppLabCard(app["name"], app["path"], app["description"])
            card.run_requested.connect(self._run)
            self._inner_lay.addWidget(card)

    def _run(self, path):
        result = run_app(path)
        self._output.setText(result.output or result.error or "(çıktı yok)")
        self._output.setVisible(True)


# ── gloWeb Paneli ─────────────────────────────────────────────────────────────
class GloWebPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        header = QFrame()
        header.setFixedHeight(52)
        header.setStyleSheet(
            f"background:{th.get('surface')}; border-bottom:1px solid {th.get('border')};"
        )
        hlay = QHBoxLayout(header)
        hlay.setContentsMargins(16, 0, 16, 0)
        title = QLabel("gloWeb")
        title.setStyleSheet(f"color:{th.get('text')}; font-size:15px; font-weight:bold;")
        hlay.addWidget(title)
        lay.addWidget(header)

        row = QWidget()
        row.setStyleSheet(f"background:{th.get('surface2')}; border-bottom:1px solid {th.get('border')};")
        rlay = QHBoxLayout(row)
        rlay.setContentsMargins(12, 10, 12, 10)
        self._inp = QLineEdit()
        self._inp.setPlaceholderText("URL veya arama…")
        self._inp.returnPressed.connect(self._go)
        btn = QPushButton("Git")
        btn.setObjectName("primary")
        btn.clicked.connect(self._go)
        rlay.addWidget(self._inp)
        rlay.addWidget(btn)
        lay.addWidget(row)

        self._out = QTextEdit()
        self._out.setReadOnly(True)
        self._out.setStyleSheet(
            f"background:{th.get('surface')}; color:{th.get('text_dim')}; "
            f"border:none; padding:12px; font-size:12px;"
        )
        lay.addWidget(self._out)

    def _go(self):
        from glo_web import GloWebWorker
        self._w = GloWebWorker(self._inp.text().strip())
        self._w.result.connect(self._out.setPlainText)
        self._w.error.connect(lambda e: self._out.setPlainText(f"Hata: {e}"))
        self._w.start()


# ── Çok-Sohbet Konteyneri ─────────────────────────────────────────────────────
class ChatTabsContainer(QWidget):
    """Her sohbet ayrı bir sekme — + butonu yeni sohbet açar, X kapatır."""

    def __init__(self, user_name: str, main_win, parent=None):
        super().__init__(parent)
        self._user = user_name
        self._main = main_win

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self._chat_tabs = QTabWidget()
        self._chat_tabs.setTabsClosable(True)
        self._chat_tabs.setMovable(True)
        self._chat_tabs.setDocumentMode(True)
        self._chat_tabs.setStyleSheet("QTabWidget::pane{border:none; background:transparent;}")
        self._chat_tabs.tabCloseRequested.connect(self._close_tab)

        self._chat_tabs.tabBar().hide()
        lay.addWidget(self._chat_tabs)

        # İlk sohbet
        self.new_chat()

    def new_chat(self, session_id: str = "") -> ChatPanel:
        import time
        if session_id:
            for i in range(self._chat_tabs.count()):
                w = self._chat_tabs.widget(i)
                if getattr(w, "_session", None) == session_id:
                    self._chat_tabs.setCurrentIndex(i)
                    return w
        sid   = session_id or str(int(time.time()))[-8:]
        panel = ChatPanel(self._user, self._main)
        panel.set_session(sid)
        if session_id:
            panel.load_history()
            # Önizleme için ilk mesaj
            hist = mem.get_history(sid, limit=1)
            label = (hist[0]["content"][:18] + "…") if hist else sid
        else:
            label = "Yeni Sohbet"
        self._chat_tabs.addTab(panel, label)
        self._chat_tabs.setCurrentWidget(panel)
        return panel

    def current_panel(self) -> "ChatPanel | None":
        return self._chat_tabs.currentWidget()

    def _close_tab(self, idx: int):
        if self._chat_tabs.count() == 1:
            # Son sekme — temizle ama kapatma
            panel = self._chat_tabs.widget(idx)
            panel._chat_view.clear()
            self._chat_tabs.setTabText(idx, "Yeni Sohbet")
            return
        self._chat_tabs.removeTab(idx)

    def rename_current(self, text: str):
        idx = self._chat_tabs.currentIndex()
        if idx >= 0:
            self._chat_tabs.setTabText(idx, text[:20])


# ── Ana Pencere ───────────────────────────────────────────────────────────────
class MainWindow(QMainWindow):
    def __init__(self, user_name: str, no_model: bool = False):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.setMinimumSize(960, 640)
        self.resize(1200, 740)
        self._user = user_name

        th.load()
        QApplication.instance().setStyleSheet(th.build_qss())

        root = QWidget()
        root.setObjectName("main_root")
        self.setCentralWidget(root)
        root_lay = QHBoxLayout(root)
        root_lay.setContentsMargins(10, 10, 10, 10)
        root_lay.setSpacing(10)

        # Sol panel
        self.left = LeftPanel(user_name, self)
        root_lay.addWidget(self.left)

        # Sağ: sekmesiz QStackedWidget
        self._stack = QStackedWidget()
        self._stack.setObjectName("main_stack")
        self._stack.setStyleSheet(
            f"QStackedWidget#main_stack{{background:{th.get('surface')}; "
            f"border:1px solid {th.get('border')}; border-radius:18px;}}"
        )

        self._chat_container = ChatTabsContainer(user_name, self)
        self._stack.addWidget(self._chat_container)   # idx 0

        self._artifact = ArtifactPanel()
        self._stack.addWidget(self._artifact)          # idx 1

        self._files = FileReaderPanel()
        self._stack.addWidget(self._files)             # idx 2

        self._settings = SettingsPanel(user_name)
        self._settings.theme_changed.connect(self._apply_theme)
        self._stack.addWidget(self._settings)          # idx 3

        self._stack.setCurrentIndex(0)
        root_lay.addWidget(self._stack, stretch=1)

        # Tour — sadece ilk açılışta
        if not mem.get_pref("tour_done"):
            self._tour = TourOverlay(root)
            self._tour.resize(root.size())
            self._tour.say_hello.connect(
                lambda: self._chat_container.current_panel().insert_message("Merhaba Coode!")
            )
            self._tour.finished_tour.connect(lambda: mem.set_pref("tour_done", "1"))
            self._tour.show()

        # Telemetri
        self._tel_worker = TelemetryWorker()
        self._tel_worker.stats.connect(self.left.telemetry_bar.update_stats)
        self._tel_worker.start()

        # Radar
        self._start_radar()

        # Groq anahtarı yoksa ilk açılışta sor (Ayarlar'a girmeye gerek kalmasın)
        QTimer.singleShot(900, self._ask_groq_key)

        # Alarm / hatırlatıcılar + sistem tepsisi
        self._really_quit = False
        self._setup_tray()
        from reminders import ReminderService
        self._reminders = ReminderService(self)
        self._reminders.fired.connect(self._on_reminder)

        # Güncelleme kontrolü
        from updater import start_update_check
        self._update_worker = start_update_check(self)

    # ── Sistem tepsisi ──────────────────────────────────────────────────────
    def _setup_tray(self):
        from PySide6.QtWidgets import QSystemTrayIcon, QMenu
        self._tray = None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self._tray = QSystemTrayIcon(QApplication.instance().windowIcon(), self)
        self._tray.setToolTip("Coode")
        menu = QMenu()
        menu.addAction("Coode'u ac", self._show_from_tray)
        menu.addAction("Alarmlar", self._show_alarm_list)
        menu.addSeparator()
        menu.addAction("Cikis", self._quit_app)
        self._tray.setContextMenu(menu)
        self._tray.activated.connect(
            lambda r: self._show_from_tray() if r == QSystemTrayIcon.Trigger else None
        )
        self._tray.show()

    def _show_from_tray(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _quit_app(self):
        self._really_quit = True
        self.close()
        QApplication.instance().quit()

    def _show_alarm_list(self):
        import reminders as rm
        items = rm.list_pending()
        txt = "\n".join(f"{rm.fmt(x['due'])}  —  {x['label']}" for x in items) or "Kurulu alarm yok."
        QMessageBox.information(self, "Coode alarmlari", txt)

    def _on_reminder(self, item: dict):
        title = {"alarm": "Alarm", "timer": "Sure doldu", "reminder": "Hatirlatici"}.get(item.get("kind"), "Coode")
        label = item.get("label", "")
        if self._tray:
            from PySide6.QtWidgets import QSystemTrayIcon
            self._tray.showMessage(f"Coode — {title}", label, QSystemTrayIcon.Information, 15000)
        try:
            import winsound
            for _ in range(3):
                winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
        except Exception:
            QApplication.beep()
        if mem.get_pref("voice_reply", False):
            import speech
            speech.speak(f"{title}. {label}")
        self._show_from_tray()
        box = QMessageBox(self)
        box.setWindowTitle(f"Coode — {title}")
        box.setText(label or title)
        box.setStandardButtons(QMessageBox.Ok)
        box.setWindowModality(Qt.NonModal)
        box.show()

    def _ask_groq_key(self):
        from config import GROQ_API_KEY
        if (mem.get_pref("groq_api_key") or GROQ_API_KEY or "").strip():
            return
        key, ok = QInputDialog.getText(
            self, "Groq API anahtari",
            "console.groq.com > API Keys > Create API Key\n"
            "Olusan anahtari (gsk_ ile baslar) buraya yapistir:",
            QLineEdit.Password,
        )
        key = (key or "").strip()
        if ok and key:
            mem.set_pref("groq_api_key", key)
            if not mem.get_pref("groq_model"):
                from config import GROQ_MODEL
                mem.set_pref("groq_model", GROQ_MODEL)

    def _show_panel(self, name: str):
        idx = {"chat": 0, "artifact": 1, "files": 2, "settings": 3}.get(name, 0)
        self._stack.setCurrentIndex(idx)

    def _apply_theme(self):
        th.load()
        QApplication.instance().setStyleSheet(th.build_qss())
        self.left.refresh_theme()

    def _start_radar(self):
        self._radar_w = RadarWorker()
        self._radar_w.done.connect(self._on_radar_data)
        self._radar_w.start()
        self._radar_timer = QTimer(self)
        self._radar_timer.timeout.connect(self._start_radar)
        self._radar_timer.start(120_000)

    def _on_radar_data(self, lat, lon, flights):
        self.left._radar_lat  = lat
        self.left._radar_lon  = lon
        self.left._radar_data = flights
        self.left.radar_map.update_data(lat, lon, flights)

    def _new_session(self):
        self._stack.setCurrentIndex(0)
        self._chat_container.new_chat()
        self.left.refresh_sessions()

    def _load_session(self, session_id: str):
        self._stack.setCurrentIndex(0)
        self._chat_container.new_chat(session_id)

    def closeEvent(self, event):
        # Kurulu alarm varsa kapatma yerine tepsiye küçül (alarm çalabilsin)
        try:
            import reminders as rm
            if not self._really_quit and self._tray and rm.list_pending():
                event.ignore()
                self.hide()
                self._tray.showMessage(
                    "Coode arka planda", "Kurulu alarmlarin icin calismaya devam ediyorum. "
                    "Tamamen kapatmak icin tepsideki ikona sag tikla > Cikis.", 
                    self._tray.MessageIcon.Information, 6000)
                return
        except Exception:
            pass
        try:
            import speech
            speech.stop()
        except Exception:
            pass
        # Worker'ları durdur, uygulama temiz kapansın
        try:
            self._tel_worker.stop()
        except Exception:
            pass
        try:
            self._radar_timer.stop()
        except Exception:
            pass
        event.accept()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "_tour"):
            self._tour.resize(self.centralWidget().size())


# ── Giriş Noktası ─────────────────────────────────────────────────────────────
def main():
    args = _parse_args()
    mem.init_db()

    # Windows görev çubuğunda Python ikonu yerine Coode ikonu görünsün
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Coode.App")
        except Exception:
            pass

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    import os
    from PySide6.QtGui import QIcon
    from config import RES_DIR
    _ico = os.path.join(RES_DIR, "coode.ico")
    if os.path.isfile(_ico):
        app.setWindowIcon(QIcon(_ico))

    th.load()
    app.setStyleSheet(th.build_qss())

    stacked = QStackedWidget()
    stacked.setWindowTitle(APP_NAME)
    stacked.resize(1200, 740)

    def _on_name(user_name: str):
        mem.set_pref("user_name", user_name)
        if not args.no_model:
            threading.Thread(target=load_local, daemon=True).start()
        win = MainWindow(user_name, no_model=args.no_model)
        stacked.addWidget(win)
        stacked.setCurrentWidget(win)
        stacked.showMaximized()

    def _after_splash():
        """Splash kapandıktan sonra onboarding veya ana pencereyi göster."""
        saved_name = mem.get_pref("user_name")
        if saved_name:
            _on_name(saved_name)
            stacked.show()
        else:
            onboard = OnboardingScreen()
            onboard.done.connect(lambda name: (_on_name(name),))
            stacked.addWidget(onboard)
            stacked.setCurrentWidget(onboard)
            stacked.show()

    # Önce logo splash (1 sn), sonra devam
    from splash import SplashScreen
    splash = SplashScreen()
    splash.finished.connect(_after_splash)
    splash.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
