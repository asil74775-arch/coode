# onboarding.py — İlk kurulum ekranı
# Tam ekran, fade-in animasyonu, isim girişi, "Coode sana bu isimle hitap edecek" yazısı.

from PySide6.QtCore    import Qt, Signal, QPropertyAnimation, QEasingCurve, QRect
from PySide6.QtGui     import QFont, QColor, QPalette
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QGraphicsOpacityEffect,
)
import theme as th


class OnboardingScreen(QWidget):
    done = Signal(str)   # kullanıcı adı

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background:{th.get('background')};")

        self._opacity = QGraphicsOpacityEffect(self)
        self._opacity.setOpacity(0)
        self.setGraphicsEffect(self._opacity)

        # ── Ana düzen ──────────────────────────────────────────────────────
        outer = QVBoxLayout(self)
        outer.setAlignment(Qt.AlignCenter)
        outer.setSpacing(0)

        # Logo / başlık
        import os
        from config import RES_DIR as BASE_DIR
        logo_path = os.path.join(BASE_DIR, "logo_dark.png")
        if th.get("mode", "dark") == "light":
            logo_path = os.path.join(BASE_DIR, "logo_light.png")
        logo = QLabel()
        logo.setAlignment(Qt.AlignCenter)
        if os.path.isfile(logo_path):
            from PySide6.QtGui import QPixmap
            pix = QPixmap(logo_path).scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            logo.setPixmap(pix)
        else:
            logo.setText("C")
            logo.setStyleSheet(
                f"color:{th.get('accent')}; font-size:64px; font-weight:900; background:transparent;"
            )
        outer.addWidget(logo)

        title = QLabel("COODE")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet(
            f"color:{th.get('accent')}; font-size:28px; font-weight:900; "
            f"letter-spacing:12px; background:transparent;"
        )
        outer.addWidget(title)

        outer.addSpacing(48)

        # "Adın ne?" başlığı
        prompt = QLabel("Adın ne?")
        prompt.setAlignment(Qt.AlignCenter)
        prompt.setStyleSheet(
            f"color:{th.get('text_dim')}; font-size:18px; background:transparent;"
        )
        outer.addWidget(prompt)

        outer.addSpacing(16)

        # Input
        self._input = QLineEdit()
        self._input.setPlaceholderText("İsminizi yazın…")
        self._input.setAlignment(Qt.AlignCenter)
        self._input.setFixedWidth(320)
        self._input.setFixedHeight(48)
        self._input.setStyleSheet(
            f"background:{th.get('surface2')}; color:{th.get('text')}; "
            f"border:1px solid {th.get('border')}; border-radius:12px; "
            f"font-size:16px; padding:0 16px;"
        )
        self._input.returnPressed.connect(self._confirm)

        input_row = QHBoxLayout()
        input_row.setAlignment(Qt.AlignCenter)
        input_row.addWidget(self._input)
        outer.addLayout(input_row)

        outer.addSpacing(10)

        # Alt açıklama
        hint = QLabel("Coode sana bu isimle hitap edecek.")
        hint.setAlignment(Qt.AlignCenter)
        hint.setStyleSheet(
            f"color:{th.get('muted')}; font-size:11px; background:transparent;"
        )
        outer.addWidget(hint)

        outer.addSpacing(28)

        # Devam butonu
        self._btn = QPushButton("Devam →")
        self._btn.setFixedSize(200, 44)
        self._btn.setStyleSheet(
            f"background:{th.get('accent')}; color:{th.get('background')}; "
            f"border:none; border-radius:10px; font-size:14px; font-weight:bold;"
        )
        self._btn.clicked.connect(self._confirm)

        btn_row = QHBoxLayout()
        btn_row.setAlignment(Qt.AlignCenter)
        btn_row.addWidget(self._btn)
        outer.addLayout(btn_row)

        # Fade-in başlat
        self._fade_in()

    # ── Animasyon ─────────────────────────────────────────────────────────────
    def _fade_in(self):
        anim = QPropertyAnimation(self._opacity, b"opacity", self)
        anim.setDuration(800)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.start()
        self._anim = anim   # GC'ye takılmasın

    def fade_out(self, callback):
        anim = QPropertyAnimation(self._opacity, b"opacity", self)
        anim.setDuration(500)
        anim.setStartValue(1.0)
        anim.setEndValue(0.0)
        anim.setEasingCurve(QEasingCurve.InCubic)
        anim.finished.connect(callback)
        anim.start()
        self._anim_out = anim

    # ── Onay ─────────────────────────────────────────────────────────────────
    def _confirm(self):
        name = self._input.text().strip()
        if not name:
            self._input.setStyleSheet(
                self._input.styleSheet() + f"border-color:{th.get('error')};"
            )
            return
        self.fade_out(lambda: self.done.emit(name))
