# glo_web.py — Playwright tabanlı web gezgini
# URL/site/arama komutlarını ayrıştırır, Chromium ile çalıştırır.

import re
from PySide6.QtCore import QThread, Signal
from config import GLOWEB_TIMEOUT, GLOWEB_HEADLESS


class GloWebWorker(QThread):
    result  = Signal(str)
    error   = Signal(str)

    def __init__(self, command: str):
        super().__init__()
        self._cmd = command.strip()

    def run(self):
        try:
            out = self._dispatch(self._cmd)
            self.result.emit(out)
        except Exception as e:
            self.error.emit(str(e))

    def _dispatch(self, cmd: str) -> str:
        lower = cmd.lower()

        # Direkt URL
        if re.match(r"https?://", cmd):
            return self._open_url(cmd)

        # Site adı (örn: "youtube.com", "github.com")
        if re.match(r"[\w\-]+\.\w{2,}", cmd) and " " not in cmd:
            return self._open_url(f"https://{cmd}")

        # Google araması
        keywords = ["ara ", "search ", "google "]
        for kw in keywords:
            if lower.startswith(kw):
                return self._google_search(cmd[len(kw):].strip())

        # Varsayılan: Google araması
        return self._google_search(cmd)

    def _google_search(self, query: str) -> str:
        url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
        return self._open_url(url)

    def _open_url(self, url: str) -> str:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=GLOWEB_HEADLESS)
            page    = browser.new_page()
            page.goto(url, timeout=GLOWEB_TIMEOUT * 1000)
            title   = page.title()
            # İlk 2000 karakter içerik
            content = page.inner_text("body")[:2000] if page.locator("body").count() else ""
            browser.close()
        return f"[{title}]\n{url}\n\n{content}"
