# tour.py — Tanıtım turu (5 adım overlay)
# Ana pencere üzerine yarı saydam kart; "Merhaba de" sinyali ile biter.

from PySide6.QtCore    import Qt, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame,
)
import theme as th

STEPS = [
    {
        "title": "Hoş geldin!",
        "body":  "Coode, kişisel yapay zekânın. Sana bu turda ne yapabildiğini göstereceğim.",
    },
    {
        "title": "Sol Panel",
        "body":  "Önceki sohbetlerin burada listelenir. Yenisini başlatmak için + tuşuna bas.",
    },
    {
        "title": "Telemetri",
        "body":  "CPU · RAM · GPU · VRAM kullanımını anlık izleyebilirsin.",
    },
    {
        "title": "Uçak Radarı",
        "body":  "Yakınındaki uçaklar haritada görünür. Tıklayınca FlightRadar24'e gidebilirsin.",
    },
    {
        "title": "App Lab & gloWeb",
        "body":  "Uygulama çalıştır, web'de gezin, kod üret. Şimdi Coode'a merhaba de!",
        "final": True,
    },
]


class TourOverlay(QWidget):
    say_hello    = Signal()
    finished_tour = Signal()   # Tur tamamlandı veya atlandı

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, False)
        self.setStyleSheet(f"background:rgba(0,0,0,160);")
        self._step = 0
        self._build()

    def _build(self):
        # Merkez kart
        self._card = QFrame(self)
        self._card.setFixedWidth(380)
        self._card.setStyleSheet(
            f"QFrame{{background:{th.get('surface')}; border:1px solid {th.get('border')}; "
            f"border-radius:16px; padding:24px;}}"
        )

        lay = QVBoxLayout(self._card)
        lay.setSpacing(14)

        self._title = QLabel()
        self._title.setStyleSheet(
            f"color:{th.get('accent')}; font-size:18px; font-weight:bold; background:transparent;"
        )
        lay.addWidget(self._title)

        self._body = QLabel()
        self._body.setWordWrap(True)
        self._body.setStyleSheet(
            f"color:{th.get('text_dim')}; font-size:13px; line-height:1.6; background:transparent;"
        )
        lay.addWidget(self._body)

        btns = QHBoxLayout()
        self._skip_btn = QPushButton("Atla")
        self._skip_btn.setStyleSheet(
            f"color:{th.get('muted')}; background:transparent; border:none; font-size:12px;"
        )
        self._skip_btn.clicked.connect(self._finish)

        self._next_btn = QPushButton("İleri →")
        self._next_btn.setStyleSheet(
            f"background:{th.get('accent')}; color:{th.get('background')}; "
            f"border:none; border-radius:8px; padding:8px 20px; font-weight:bold;"
        )
        self._next_btn.clicked.connect(self._next)

        btns.addWidget(self._skip_btn)
        btns.addStretch()
        btns.addWidget(self._next_btn)
        lay.addLayout(btns)

        self._refresh_step()

    def _refresh_step(self):
        s = STEPS[self._step]
        self._title.setText(s["title"])
        self._body.setText(s["body"])
        if s.get("final"):
            self._next_btn.setText("Merhaba de!")
            self._skip_btn.hide()
        else:
            self._next_btn.setText("İleri →")
            self._skip_btn.show()

    def _next(self):
        if STEPS[self._step].get("final"):
            self.say_hello.emit()
            self._finish()
            return
        self._step += 1
        if self._step >= len(STEPS):
            self._finish()
        else:
            self._refresh_step()

    def _finish(self):
        self.hide()
        self.finished_tour.emit()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._card.adjustSize()
        # Kartı ortala
        x = (self.width()  - self._card.width())  // 2
        y = (self.height() - self._card.height()) // 2
        self._card.move(x, y)
