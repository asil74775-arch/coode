# updater.py — Otomatik güncelleme (GitHub Releases)
#
# Nasıl çalışır:
#   1. Açılışta GitHub'daki son sürüme bakar:
#        https://api.github.com/repos/<GITHUB_REPO>/releases/latest
#   2. Etiket (ör. v3.8.0) mevcut sürümden yeniyse "Güncellensin mi?" diye sorar.
#   3. Evet → release'e eklenmiş Coode_Setup_*.exe indirilir, sessizce kurulur,
#      Coode kapanır ve yeni sürüm kendiliğinden açılır. Ayarlar / sohbetler korunur.
#
# Yeni sürüm yayınlamak (senin yapacağın):
#   config.py → APP_VERSION ve installer.iss → AppVersion'ı artır → KUR.bat ile
#   Setup.exe üret → GitHub'da Releases → "Draft a new release" → Tag: v3.8.0 →
#   dist\Coode_Setup_3.8.0.exe dosyasını sürükle → Publish.

import json
import os
import sys
import subprocess
import tempfile
import urllib.request

from PySide6.QtCore    import QThread, Signal, QTimer, Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QProgressBar, QApplication,
)
import theme as th
from config import APP_VERSION, GITHUB_REPO

_UA = {"User-Agent": "CoodeApp", "Accept": "application/vnd.github+json"}


def _version_tuple(v: str):
    v = (v or "").strip().lstrip("vV")
    parts = []
    for x in v.split("."):
        digits = "".join(ch for ch in x if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts + [0] * (3 - len(parts)))


# ── Sürüm Kontrol Worker ──────────────────────────────────────────────────────
class UpdateCheckWorker(QThread):
    update_available = Signal(str, str, str, str)  # sürüm, notlar, setup_url, sayfa_url
    no_update        = Signal()
    check_failed     = Signal(str)

    def run(self):
        try:
            url = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"
            req = urllib.request.Request(url, headers=_UA)
            with urllib.request.urlopen(req, timeout=8) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            remote = (data.get("tag_name") or "").lstrip("vV")
            if _version_tuple(remote) <= _version_tuple(APP_VERSION):
                self.no_update.emit()
                return
            setup_url = ""
            for a in data.get("assets", []):
                name = a.get("name", "").lower()
                if name.endswith(".exe"):
                    setup_url = a.get("browser_download_url", "")
                    if "setup" in name:
                        break
            self.update_available.emit(
                remote, data.get("body") or "", setup_url, data.get("html_url") or ""
            )
        except Exception as e:
            self.check_failed.emit(str(e))


# ── İndirme Worker ────────────────────────────────────────────────────────────
class DownloadWorker(QThread):
    progress = Signal(int)
    finished = Signal(str)
    failed   = Signal(str)

    def __init__(self, url: str, parent=None):
        super().__init__(parent)
        self._url = url

    def run(self):
        try:
            dest = os.path.join(tempfile.gettempdir(), "Coode_Update_Setup.exe")
            req = urllib.request.Request(self._url, headers={"User-Agent": "CoodeApp"})
            with urllib.request.urlopen(req, timeout=60) as resp:
                total = int(resp.headers.get("Content-Length", 0) or 0)
                done = 0
                with open(dest, "wb") as f:
                    while True:
                        buf = resp.read(256 * 1024)
                        if not buf:
                            break
                        f.write(buf)
                        done += len(buf)
                        if total:
                            self.progress.emit(int(done * 100 / total))
            self.finished.emit(dest)
        except Exception as e:
            self.failed.emit(str(e))


# ── Güncelleme Diyaloğu ───────────────────────────────────────────────────────
class UpdateDialog(QDialog):
    def __init__(self, version: str, notes: str, setup_url: str, page_url: str, parent=None):
        super().__init__(parent)
        self._setup_url = setup_url
        self._page_url  = page_url
        self._dl = None

        self.setWindowTitle("Guncelleme")
        self.setMinimumWidth(440)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        self.setStyleSheet(f"background:{th.get('surface')}; color:{th.get('text')};")

        lay = QVBoxLayout(self)
        lay.setSpacing(12)
        lay.setContentsMargins(26, 24, 26, 22)

        title = QLabel(f"Coode {version} cikti")
        title.setStyleSheet(f"color:{th.get('accent')}; font-size:17px; font-weight:800;")
        lay.addWidget(title)

        cur = QLabel(f"Su an: v{APP_VERSION}   ->   Yeni: v{version}")
        cur.setStyleSheet(f"color:{th.get('text_dim')}; font-size:11px;")
        lay.addWidget(cur)

        if notes.strip():
            n = QLabel(notes.strip()[:800])
            n.setWordWrap(True)
            n.setTextFormat(Qt.MarkdownText)
            n.setStyleSheet(f"color:{th.get('text_dim')}; font-size:12px;")
            lay.addWidget(n)

        info = QLabel("Ayarlarin ve sohbet gecmisin korunur.")
        info.setStyleSheet(f"color:{th.get('text_muted')}; font-size:11px;")
        lay.addWidget(info)

        self._bar = QProgressBar()
        self._bar.setRange(0, 100)
        self._bar.setFixedHeight(6)
        self._bar.setTextVisible(False)
        self._bar.setStyleSheet(
            f"QProgressBar{{background:{th.get('surface3')}; border:none; border-radius:3px;}}"
            f"QProgressBar::chunk{{background:{th.get('accent')}; border-radius:3px;}}"
        )
        self._bar.hide()
        lay.addWidget(self._bar)

        self._status = QLabel("")
        self._status.setWordWrap(True)
        self._status.setStyleSheet(f"color:{th.get('text_dim')}; font-size:11px;")
        self._status.hide()
        lay.addWidget(self._status)

        row = QHBoxLayout()
        self._later = QPushButton("Sonra")
        self._later.clicked.connect(self.reject)
        self._go = QPushButton("Simdi Guncelle")
        self._go.setStyleSheet(
            f"QPushButton{{background:{th.get('accent')}; color:{th.get('accent_text')}; "
            f"border:none; border-radius:10px; padding:9px 20px; font-weight:700;}}"
            f"QPushButton:hover{{background:{th.get('accent_dim')};}}"
        )
        self._go.clicked.connect(self._start)
        row.addWidget(self._later)
        row.addStretch()
        row.addWidget(self._go)
        lay.addLayout(row)

    def _start(self):
        # Kaynak koddan çalışıyorsa (exe değilse) sadece sayfayı aç
        if not getattr(sys, "frozen", False) or not self._setup_url:
            import webbrowser
            webbrowser.open(self._page_url or self._setup_url)
            self.accept()
            return
        self._go.setEnabled(False)
        self._later.setEnabled(False)
        self._go.setText("Indiriliyor...")
        self._bar.show()
        self._status.setText("Yeni surum indiriliyor...")
        self._status.show()
        self._dl = DownloadWorker(self._setup_url, self)
        self._dl.progress.connect(self._bar.setValue)
        self._dl.finished.connect(self._install)
        self._dl.failed.connect(self._fail)
        self._dl.start()

    def _install(self, path: str):
        self._status.setText("Kuruluyor... Coode birkac saniye icinde yeniden acilacak.")
        QApplication.processEvents()
        try:
            # /UPDATE=1 → kurulum bitince Coode otomatik açılır (installer.iss)
            subprocess.Popen(
                [path, "/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART",
                 "/CLOSEAPPLICATIONS", "/UPDATE=1"],
                close_fds=True,
            )
        except Exception as e:
            self._fail(str(e))
            return
        QTimer.singleShot(800, QApplication.instance().quit)

    def _fail(self, msg: str):
        self._go.setEnabled(True)
        self._later.setEnabled(True)
        self._go.setText("Tekrar Dene")
        self._bar.hide()
        self._status.setText(f"Guncelleme basarisiz: {msg[:200]}")
        self._status.show()


# ── Başlatıcı ─────────────────────────────────────────────────────────────────
def start_update_check(parent_widget):
    """Ana pencere açılınca çağrılır; 3 sn sonra arka planda kontrol eder."""
    worker = UpdateCheckWorker(parent_widget)
    if not GITHUB_REPO or "/" not in GITHUB_REPO:
        return worker

    def _on_update(ver, notes, setup_url, page_url):
        UpdateDialog(ver, notes, setup_url, page_url, parent_widget).exec()

    worker.update_available.connect(_on_update)
    QTimer.singleShot(3000, worker.start)
    return worker
