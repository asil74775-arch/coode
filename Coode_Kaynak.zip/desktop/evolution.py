# evolution.py — Öz-Evrim sistemi
# Coode, Python kodu önererek kendine yeni yetenek ekleyebilir.
# AST taraması + sandbox testi + kullanıcı onayı + yedek alma.

import ast
import os
import shutil
import time
from config import EVOLUTION_BACKUP_DIR, ALLOWED_UI_OPS
from memory import log_evolution


# ── AST Güvenlik Taraması ─────────────────────────────────────────────────────
_FORBIDDEN_NODES = (ast.Delete, ast.Global, ast.Nonlocal)
_FORBIDDEN_CALLS = {
    "exec", "eval", "compile", "__import__",
    "open", "os.system", "subprocess.run",
    "subprocess.Popen", "shutil.rmtree",
}


def ast_scan(code: str) -> tuple[bool, str]:
    """
    Kodu AST ile tarar.
    Döndürür: (güvenli_mi, açıklama)
    """
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return False, f"Söz dizimi hatası: {e}"

    for node in ast.walk(tree):
        if isinstance(node, _FORBIDDEN_NODES):
            return False, f"Yasaklı ifade: {type(node).__name__}"
        if isinstance(node, ast.Call):
            func_name = ""
            if isinstance(node.func, ast.Name):
                func_name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                parts = []
                n = node.func
                while isinstance(n, ast.Attribute):
                    parts.insert(0, n.attr)
                    n = n.value
                if isinstance(n, ast.Name):
                    parts.insert(0, n.id)
                func_name = ".".join(parts)
            if func_name in _FORBIDDEN_CALLS:
                return False, f"Yasaklı çağrı: {func_name}"

    return True, "Temiz"


# ── Yedek Alma ────────────────────────────────────────────────────────────────
def backup_file(path: str) -> str:
    if not os.path.isfile(path):
        return ""
    ts   = int(time.time())
    name = os.path.basename(path)
    dest = os.path.join(EVOLUTION_BACKUP_DIR, f"{name}.{ts}.bak")
    shutil.copy2(path, dest)
    return dest


# ── Yetenek Şablonları ────────────────────────────────────────────────────────
CAPABILITY_TEMPLATES = {
    "image_gen": '''\
# image_gen.py — Görüntü üretimi (Stable Diffusion)
def generate_image(prompt: str, out_path: str = "output.png"):
    from diffusers import DiffusionPipeline
    import torch
    pipe = DiffusionPipeline.from_pretrained(
        "stabilityai/stable-diffusion-xl-base-1.0",
        torch_dtype=torch.float16,
    ).to("cuda")
    img = pipe(prompt).images[0]
    img.save(out_path)
    return out_path
''',
    "video_gen": '''\
# video_gen.py — Video üretimi (placeholder)
def generate_video(prompt: str) -> str:
    return f"[Video üretimi: {prompt}] — Henüz uygulanmadı."
''',
}


# ── Kod Yeteneği Uygulama ─────────────────────────────────────────────────────
def apply_code_capability(filename: str, code: str) -> tuple[bool, str]:
    """
    modules/ dizinine yeni bir Python modülü yazar.
    Önce sandbox testi, sonra AST taraması.
    """
    from config import MODULES_DIR
    from sandbox import run_code

    # 1. AST tarama
    safe, reason = ast_scan(code)
    if not safe:
        return False, f"AST taraması reddetti: {reason}"

    # 2. Sandbox testi
    result = run_code(code)
    if not result.ok and "ModuleNotFoundError" not in result.error:
        return False, f"Sandbox hatası: {result.error}"

    # 3. Yaz
    path   = os.path.join(MODULES_DIR, filename)
    backup = backup_file(path)
    with open(path, "w", encoding="utf-8") as f:
        f.write(code)

    log_evolution("add_capability", filename, path, backup)
    return True, f"Yetenek eklendi: {filename}"


# ── UI Değişikliği Uygulama ───────────────────────────────────────────────────
def apply_ui_change(op: str, **kwargs) -> tuple[bool, str]:
    if op not in ALLOWED_UI_OPS:
        return False, f"İzin verilmeyen UI işlemi: {op}"
    log_evolution("ui_change", op)
    return True, f"UI işlemi tamamlandı: {op}"


# ── Geri Al ───────────────────────────────────────────────────────────────────
def undo_last() -> tuple[bool, str]:
    import sqlite3
    from config import DB_PATH
    with sqlite3.connect(DB_PATH) as c:
        row = c.execute(
            "SELECT file_path, backup_path FROM evolution_log "
            "WHERE backup_path != '' ORDER BY ts DESC LIMIT 1"
        ).fetchone()
    if not row:
        return False, "Geri alınacak işlem yok."
    file_path, backup_path = row
    if not os.path.isfile(backup_path):
        return False, "Yedek dosyası bulunamadı."
    shutil.copy2(backup_path, file_path)
    return True, f"Geri alındı: {file_path}"
