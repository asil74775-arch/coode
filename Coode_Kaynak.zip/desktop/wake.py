# wake.py — "Hey Coode" uyandırma kelimesi (Vosk)
# WakeWordDetector: mikrofonu dinler, eşleşince sinyal yayar.
# TranscribeWorker: faster-whisper ile tam transkripsiyon.

import os
import queue
from PySide6.QtCore import QThread, Signal
from config import WAKE_PHRASES, VOSK_MODEL_PATH


def _phrase_match(text: str) -> bool:
    lower = text.lower()
    return any(p in lower for p in WAKE_PHRASES)


class WakeWordDetector(QThread):
    activated    = Signal()
    partial_text = Signal(str)

    def __init__(self):
        super().__init__()
        self._running = True

    def run(self):
        try:
            import vosk
            import sounddevice as sd
            import json

            if not os.path.isdir(VOSK_MODEL_PATH):
                self.partial_text.emit("[Vosk modeli bulunamadı — ses devre dışı]")
                return

            model = vosk.Model(VOSK_MODEL_PATH)
            rec   = vosk.KaldiRecognizer(model, 16000)
            q: queue.Queue = queue.Queue()

            def callback(indata, frames, time_info, status):
                q.put(bytes(indata))

            with sd.RawInputStream(samplerate=16000, blocksize=8000,
                                   dtype="int16", channels=1,
                                   callback=callback):
                while self._running:
                    data = q.get()
                    if rec.AcceptWaveform(data):
                        result = json.loads(rec.Result()).get("text", "")
                        if _phrase_match(result):
                            self.activated.emit()
                    else:
                        partial = json.loads(rec.PartialResult()).get("partial", "")
                        if partial:
                            self.partial_text.emit(partial)
        except Exception as e:
            self.partial_text.emit(f"[Ses hatası: {e}]")

    def stop(self):
        self._running = False
        self.quit()
        self.wait()


class TranscribeWorker(QThread):
    done  = Signal(str)
    error = Signal(str)

    def __init__(self, audio_path: str):
        super().__init__()
        self._path = audio_path

    def run(self):
        try:
            from faster_whisper import WhisperModel
            model   = WhisperModel("small", device="cpu", compute_type="int8")
            segs, _ = model.transcribe(self._path, language="tr")
            text    = " ".join(s.text for s in segs).strip()
            self.done.emit(text)
        except Exception as e:
            self.error.emit(str(e))
