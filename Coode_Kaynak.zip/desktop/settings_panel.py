# settings_panel.py — Ayarlar paneli
# Tema toggle (siyah/beyaz), Ollama modeli, ses, hakkında.

from PySide6.QtCore    import Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QFrame, QComboBox,
    QScrollArea,
)
import theme as th
import memory as mem
from config import OLLAMA_HOST, OLLAMA_MODEL, HF_API_URL, HF_API_KEY, GROQ_API_KEY, GROQ_MODEL


class SettingsPanel(QWidget):
    theme_changed = Signal()   # Ana pencere QSS'i yeniden uygulasın

    def __init__(self, user_name: str, parent=None):
        super().__init__(parent)
        self._user = user_name
        self._build_ui()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("border:none;")
        inner = QWidget()
        lay   = QVBoxLayout(inner)
        lay.setContentsMargins(20, 20, 20, 20)
        lay.setSpacing(16)
        scroll.setWidget(inner)
        outer.addWidget(scroll)

        # ── Tema ──────────────────────────────────────────────────────────────
        lay.addWidget(self._section("Tema"))
        theme_card = self._card()
        tc_lay     = QHBoxLayout(theme_card)

        self._theme_btn = QPushButton()
        self._theme_btn.setFixedHeight(44)
        self._theme_btn.setObjectName("primary")
        self._theme_btn.clicked.connect(self._toggle_theme)
        self._update_theme_btn()
        tc_lay.addWidget(self._theme_btn)

        hint = QLabel("Tema değişince uygulama anında güncellenir.")
        hint.setStyleSheet(f"color:{th.get('muted')}; font-size:11px;")
        tc_lay.addWidget(hint)
        tc_lay.addStretch()
        lay.addWidget(theme_card)

        # ── Groq API ──────────────────────────────────────────────────────────
        lay.addWidget(self._section("Groq API (Llama 70B — Ucretsiz)"))
        groq_card = self._card()
        gc_lay    = QVBoxLayout(groq_card)

        groq_info = QLabel(
            "groq.com'dan ucretsiz API key al.\n"
            "Groq key varsa Coode otomatik olarak Groq'u kullanir.\n"
            "Agent modu (CodeAgent) sadece Groq ile calisir."
        )
        groq_info.setWordWrap(True)
        groq_info.setStyleSheet(f"color:{th.get('text_dim')}; font-size:11px;")
        gc_lay.addWidget(groq_info)

        row_gk = QHBoxLayout()
        lbl_gk = QLabel("API Key:")
        lbl_gk.setFixedWidth(80)
        self._groq_key_input = QLineEdit(mem.get_pref("groq_api_key") or GROQ_API_KEY)
        self._groq_key_input.setPlaceholderText("gsk_xxxx...")
        self._groq_key_input.setEchoMode(QLineEdit.Password)
        row_gk.addWidget(lbl_gk)
        row_gk.addWidget(self._groq_key_input)
        gc_lay.addLayout(row_gk)

        row_gm = QHBoxLayout()
        lbl_gm = QLabel("Model:")
        lbl_gm.setFixedWidth(80)
        self._groq_model_input = QLineEdit(mem.get_pref("groq_model") or GROQ_MODEL)
        self._groq_model_input.setPlaceholderText("llama-3.3-70b-versatile")
        row_gm.addWidget(lbl_gm)
        row_gm.addWidget(self._groq_model_input)
        gc_lay.addLayout(row_gm)

        groq_btn_row = QHBoxLayout()
        btn_save_groq = QPushButton("Kaydet")
        btn_save_groq.setObjectName("primary")
        btn_save_groq.clicked.connect(self._save_groq)
        btn_test_groq = QPushButton("Test Et")
        btn_test_groq.clicked.connect(self._test_groq)
        groq_btn_row.addWidget(btn_save_groq)
        groq_btn_row.addWidget(btn_test_groq)
        groq_btn_row.addStretch()
        gc_lay.addLayout(groq_btn_row)

        self._groq_status = QLabel("")
        self._groq_status.setStyleSheet(f"color:{th.get('text_muted')}; font-size:11px;")
        gc_lay.addWidget(self._groq_status)
        lay.addWidget(groq_card)

        # ── Ollama / Model ────────────────────────────────────────────────────
        lay.addWidget(self._section("Model"))
        model_card = self._card()
        mc_lay     = QVBoxLayout(model_card)

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Ollama sunucu:"))
        self._host_input = QLineEdit(mem.get_pref("ollama_host") or OLLAMA_HOST)
        row1.addWidget(self._host_input)
        mc_lay.addLayout(row1)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Model:"))
        self._model_input = QLineEdit(mem.get_pref("ollama_model") or OLLAMA_MODEL)
        row2.addWidget(self._model_input)
        mc_lay.addLayout(row2)

        btn_save_model = QPushButton("Kaydet")
        btn_save_model.setObjectName("primary")
        btn_save_model.clicked.connect(self._save_model)
        mc_lay.addWidget(btn_save_model)
        lay.addWidget(model_card)

        # ── Hugging Face API ──────────────────────────────────────────────────
        lay.addWidget(self._section("Hugging Face API (GPU'suz)"))
        hf_card = self._card()
        hf_lay  = QVBoxLayout(hf_card)

        hf_info = QLabel(
            "4060 GPU'suz sistemler icin HF Spaces uzerindeki Coode API'sine baglanabilirsin.\n"
            "HF_API_URL doluysa Ollama yerine HF kullanilir."
        )
        hf_info.setWordWrap(True)
        hf_info.setStyleSheet(f"color:{th.get('muted')}; font-size:11px;")
        hf_lay.addWidget(hf_info)

        row_hf1 = QHBoxLayout()
        lbl_url = QLabel("API URL:")
        lbl_url.setFixedWidth(80)
        self._hf_url_input = QLineEdit(mem.get_pref("hf_api_url") or HF_API_URL)
        self._hf_url_input.setPlaceholderText("https://kullanici-coode-api.hf.space")
        row_hf1.addWidget(lbl_url)
        row_hf1.addWidget(self._hf_url_input)
        hf_lay.addLayout(row_hf1)

        row_hf2 = QHBoxLayout()
        lbl_key = QLabel("HF Token:")
        lbl_key.setFixedWidth(80)
        self._hf_key_input = QLineEdit(mem.get_pref("hf_api_key") or HF_API_KEY)
        self._hf_key_input.setPlaceholderText("hf_xxxx... (opsiyonel)")
        self._hf_key_input.setEchoMode(QLineEdit.Password)
        row_hf2.addWidget(lbl_key)
        row_hf2.addWidget(self._hf_key_input)
        hf_lay.addLayout(row_hf2)

        hf_btn_row = QHBoxLayout()
        btn_save_hf = QPushButton("Kaydet")
        btn_save_hf.setObjectName("primary")
        btn_save_hf.clicked.connect(self._save_hf)
        btn_test_hf = QPushButton("Baglantıyı Test Et")
        btn_test_hf.clicked.connect(self._test_hf)
        hf_btn_row.addWidget(btn_save_hf)
        hf_btn_row.addWidget(btn_test_hf)
        hf_btn_row.addStretch()
        hf_lay.addLayout(hf_btn_row)

        self._hf_status = QLabel("")
        self._hf_status.setStyleSheet(f"color:{th.get('muted')}; font-size:11px;")
        hf_lay.addWidget(self._hf_status)
        lay.addWidget(hf_card)

        # ── Hesap ─────────────────────────────────────────────────────────────
        lay.addWidget(self._section("Hesap"))
        acc_card = self._card()
        ac_lay   = QVBoxLayout(acc_card)

        name_row = QHBoxLayout()
        name_row.addWidget(QLabel("Kullanıcı adı:"))
        name_lbl = QLabel(self._user)
        name_lbl.setStyleSheet(f"color:{th.get('accent')}; font-weight:bold;")
        name_row.addWidget(name_lbl)
        name_row.addStretch()
        ac_lay.addLayout(name_row)

        btn_reset = QPushButton("Yeniden Kur (isim / sunucu değiştir)")
        btn_reset.clicked.connect(self._reset)
        ac_lay.addWidget(btn_reset)
        lay.addWidget(acc_card)

        # ── Hakkında ──────────────────────────────────────────────────────────
        lay.addWidget(self._section("Hakkında"))
        about_card = self._card()
        ab_lay     = QVBoxLayout(about_card)
        from config import APP_VERSION, AUTHOR
        ab_lay.addWidget(QLabel(f"Coode v{APP_VERSION}"))
        ab_lay.addWidget(QLabel(f"Geliştirici: {AUTHOR}"))
        lbl = QLabel("Coode bir yapay zekadır. Hatalı olabilir. Kusuruna bakmayın.")
        lbl.setStyleSheet(f"color:{th.get('muted')}; font-size:11px;")
        ab_lay.addWidget(lbl)
        lay.addWidget(about_card)

        lay.addStretch()

    # ── Yardımcı ──────────────────────────────────────────────────────────────
    def _section(self, title: str) -> QLabel:
        lbl = QLabel(title)
        lbl.setStyleSheet(
            f"color:{th.get('text')}; font-size:14px; font-weight:bold; background:transparent;"
        )
        return lbl

    def _card(self) -> QFrame:
        f = QFrame()
        f.setStyleSheet(
            f"QFrame{{background:{th.get('surface')}; border:1px solid {th.get('border')}; "
            f"border-radius:{th.get('radius')}px; padding:4px;}}"
        )
        return f

    def _update_theme_btn(self):
        mode = th.get("mode", "dark")
        if mode == "dark":
            self._theme_btn.setText("Aydınlık Mod")
        else:
            self._theme_btn.setText("Karanlık Mod")

    def _toggle_theme(self):
        th.toggle_mode()
        self._update_theme_btn()
        self.theme_changed.emit()

    def _save_model(self):
        mem.set_pref("ollama_host",  self._host_input.text().strip())
        mem.set_pref("ollama_model", self._model_input.text().strip())

    def showEvent(self, event):
        """Ayarlar her açıldığında kayıtlı değerleri yeniden yükle
        (ilk açılışta girilen anahtar burada da görünsün)."""
        super().showEvent(event)
        from config import GROQ_MODEL as _GM
        key = mem.get_pref("groq_api_key") or GROQ_API_KEY or ""
        if not self._groq_key_input.hasFocus():
            self._groq_key_input.setText(key)
            self._groq_model_input.setText(mem.get_pref("groq_model") or _GM)
        if key:
            self._groq_status.setStyleSheet(f"color:{th.get('success')}; font-size:11px;")
            self._groq_status.setText(f"Kayitli anahtar: {key[:6]}...{key[-4:]}")

    def _save_groq(self):
        key   = self._groq_key_input.text().strip()
        model = self._groq_model_input.text().strip() or GROQ_MODEL
        if not key:
            self._groq_status.setStyleSheet(f"color:{th.get('error')}; font-size:11px;")
            self._groq_status.setText("Anahtar bos — mevcut anahtar korunuyor.")
            return
        mem.set_pref("groq_api_key", key)
        mem.set_pref("groq_model",   model)
        self._groq_status.setStyleSheet(f"color:{th.get('success')}; font-size:11px;")
        self._groq_status.setText(f"Kaydedildi: {key[:6]}...{key[-4:]}")

    def _test_groq(self):
        key   = self._groq_key_input.text().strip()
        model = self._groq_model_input.text().strip() or GROQ_MODEL
        if not key:
            self._groq_status.setText("API key bos!")
            return
        try:
            from groq import Groq
            client = Groq(api_key=key)
            resp   = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": "Merhaba, cevap ver: 1+1 kac?"}],
                max_tokens=300,
            )
            from widgets import clean_ai_text
            ans = clean_ai_text(resp.choices[0].message.content or "")
            self._groq_status.setStyleSheet(f"color:{th.get('success')}; font-size:11px;")
            self._groq_status.setText(f"Baglanti basarili! Cevap: {ans[:40]}")
        except Exception as e:
            self._groq_status.setStyleSheet(f"color:{th.get('error')}; font-size:11px;")
            self._groq_status.setText(f"Hata: {str(e)[:80]}")

    def _save_hf(self):
        mem.set_pref("hf_api_url", self._hf_url_input.text().strip())
        mem.set_pref("hf_api_key", self._hf_key_input.text().strip())
        self._hf_status.setText("Kaydedildi.")

    def _test_hf(self):
        import requests
        url = (self._hf_url_input.text().strip() or "").rstrip("/")
        key = self._hf_key_input.text().strip()
        if not url:
            self._hf_status.setText("URL bos!")
            return
        try:
            headers = {}
            if key:
                headers["Authorization"] = f"Bearer {key}"
            r = requests.get(f"{url}/health", headers=headers, timeout=8)
            if r.status_code == 200:
                self._hf_status.setStyleSheet(f"color:{th.get('success')}; font-size:11px;")
                self._hf_status.setText("Baglanti basarili!")
            else:
                self._hf_status.setStyleSheet(f"color:{th.get('error')}; font-size:11px;")
                self._hf_status.setText(f"Hata: HTTP {r.status_code}")
        except Exception as e:
            self._hf_status.setStyleSheet(f"color:{th.get('error')}; font-size:11px;")
            self._hf_status.setText(f"Baglanilamadi: {e}")

    def _reset(self):
        mem.set_pref("user_name", None)
        from PySide6.QtWidgets import QApplication
        from onboarding import OnboardingScreen
        # Ana pencereyi kapat, onboarding aç
        for w in QApplication.topLevelWidgets():
            w.close()
        ob = OnboardingScreen()
        ob.show()
