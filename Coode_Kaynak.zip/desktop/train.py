# train.py — Qwen2.5-7B-Instruct QLoRA fine-tune
# DeepSpeed ZeRO-2 ile optimizer state CPU RAM'e taşınır → 8GB VRAM'e sığar.
# Çalıştır: python train.py
# DeepSpeed ile: deepspeed train.py --deepspeed ds_config.json

import os, json, math, time
import torch
from datasets import Dataset
from transformers import (
    AutoTokenizer, AutoModelForCausalLM,
    TrainingArguments, Trainer, DataCollatorForSeq2Seq,
    BitsAndBytesConfig,
)
from peft import LoraConfig, get_peft_model, TaskType
from config import SYSTEM_PROMPT

# ── Ayarlar ───────────────────────────────────────────────────────────────────
MODEL_ID     = "Qwen/Qwen2.5-7B-Instruct"
DATASET_PATH = "dataset.json"
OUTPUT_DIR   = "models/coode-ft"
EPOCHS       = 3
LR           = 2e-4
MAX_LEN      = 512
LORA_R       = 16
LORA_ALPHA   = 32
LORA_DROPOUT = 0.05

# ── Tokenizer ─────────────────────────────────────────────────────────────────
print("Tokenizer yükleniyor…")
tok = AutoTokenizer.from_pretrained(MODEL_ID, trust_remote_code=True)
tok.pad_token = tok.eos_token

# ── Veri seti ─────────────────────────────────────────────────────────────────
with open(DATASET_PATH, encoding="utf-8") as f:
    raw = json.load(f)

def _format(item):
    msgs = [
        {"role": "system",    "content": SYSTEM_PROMPT},
        {"role": "user",      "content": item["input"]},
        {"role": "assistant", "content": item["output"]},
    ]
    text = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=False)
    return {"text": text}

records = [_format(r) for r in raw]
ds = Dataset.from_list(records)

def _tokenize(batch):
    enc = tok(
        batch["text"],
        truncation=True,
        max_length=MAX_LEN,
        padding="max_length",
    )
    enc["labels"] = enc["input_ids"].copy()
    return enc

ds = ds.map(_tokenize, batched=True, remove_columns=["text"])
ds = ds.train_test_split(test_size=0.05, seed=42)
print(f"Eğitim: {len(ds['train'])}  Doğrulama: {len(ds['test'])}")

# ── Model (4-bit NF4) ─────────────────────────────────────────────────────────
print("Model yükleniyor (4-bit NF4)…")
bnb_cfg = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True,
)
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    quantization_config=bnb_cfg,
    device_map="auto",
    trust_remote_code=True,
)
model.config.use_cache = False

# Manuel gradient checkpointing (prepare_model olmadan)
model.enable_input_require_grads()
model.gradient_checkpointing_enable()

# ── LoRA ──────────────────────────────────────────────────────────────────────
lora_cfg = LoraConfig(
    r=LORA_R,
    lora_alpha=LORA_ALPHA,
    lora_dropout=LORA_DROPOUT,
    bias="none",
    task_type=TaskType.CAUSAL_LM,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                    "gate_proj", "up_proj", "down_proj"],
)
model = get_peft_model(model, lora_cfg)
model.print_trainable_parameters()

# ── Eğitim Argümanları ────────────────────────────────────────────────────────
# deepspeed=ds_config.json varsa ZeRO-2 aktif olur (optimizer → CPU RAM)
ds_config = "ds_config.json" if os.path.isfile("ds_config.json") else None

args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    num_train_epochs=EPOCHS,
    per_device_train_batch_size=1,
    gradient_accumulation_steps=8,   # effective batch = 8
    learning_rate=LR,
    warmup_ratio=0.05,
    lr_scheduler_type="cosine",
    bf16=True,
    logging_steps=10,
    save_strategy="epoch",
    evaluation_strategy="epoch",
    load_best_model_at_end=True,
    report_to="none",
    dataloader_num_workers=0,
    deepspeed=ds_config,              # None ise normal eğitim
)

trainer = Trainer(
    model=model,
    args=args,
    train_dataset=ds["train"],
    eval_dataset=ds["test"],
    data_collator=DataCollatorForSeq2Seq(tok, pad_to_multiple_of=8),
)

print("Eğitim başlıyor…")
t0 = time.time()
trainer.train()
print(f"Eğitim bitti — {(time.time()-t0)/60:.1f} dakika")

model.save_pretrained(OUTPUT_DIR)
tok.save_pretrained(OUTPUT_DIR)
print(f"Model kaydedildi: {OUTPUT_DIR}")
