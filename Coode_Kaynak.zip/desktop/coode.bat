@echo off
rem Gelistirici modu: kurulum yapmadan kaynak koddan calistirir
cd /d "%~dp0"
if exist ".venv_build\Scripts\python.exe" (
    ".venv_build\Scripts\python.exe" main.py
) else (
    python main.py
)
if errorlevel 1 pause
