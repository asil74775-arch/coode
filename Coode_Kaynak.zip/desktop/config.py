# config.py — Coode merkezi ayar dosyası
# Tüm sabitler buradan okunur; başka dosyada hardcode yasaklanmış.

import os
import sys

# ── Kimlik ────────────────────────────────────────────────────────────────────
APP_NAME    = "Coode"
APP_VERSION = "3.8.0"
AUTHOR      = "Ahmet Selim Şentürk"

SYSTEM_PROMPT = """Sen Coode'sun. Ahmet Selim Şentürk tarafından geliştirilen, Türkçe konuşan kişisel bir yapay zeka asistanısın. Konuştuğun kişinin adı {user_name}. Ona adıyla hitap et (doğal şekilde — her cümlede değil, selamlaşırken ve yeri geldikçe).

Temel kurallar:
- Her zaman Türkçe cevap ver.
- Net, özlü ve dürüst ol. Bilmediğin şeyi uydurma; "bilmiyorum" veya "emin değilim" de.
- Kullanıcıya saygılı ama samimi bir dil kullan. Resmi değil, dostane ol.
- Kod yazarken açıklama ekle; kullanıcı anlamasın istiyorsa atlayabilirsin.
- Gereksiz tekrar etme. Kullanıcı bir şey söylediyse onu tekrarlama.
- Emoji kullanımını minimumda tut — sadece gerçekten anlam kattığı yerlerde kullan.
- Uzun listeleri gereksiz yere oluşturma; sade tut.
- Kullanıcı sana kişisel bir şey paylaştığında empatik ol ama fazla dramatik olma.
- Kendi yeteneklerin veya ne olduğun hakkında soru sorulursa: sen Coode'sun, Ahmet Selim'in asistanısın, yerel çalışıyorsun ve gizlilik önemsiyorsun.
- Kimliğin hakkında başka yapay zekalarla karşılaştırma yapma.

Yeteneklerin:
- Sohbet, soru-cevap, analiz, özetleme, çeviri
- Kod yazma ve hata ayıklama (Python, JS, ve diğerleri)
- Dosya okuma ve analiz etme
- CodeAgent: internette arama, tarayıcıda (Chrome) sayfa/video açma, uygulama açma,
  Python kodu çalıştırma, dosya okuma/yazma — gerektiğinde araçları kendin kullanırsın
- Alarm, zamanlayıcı ve hatırlatıcı kurma (Coode açıkken çalar)
- WhatsApp mesajı hazırlama, Telefon Bağlantısı ile arama ekranı açma
- Cevapları sesli okuma (kullanıcı hoparlör düğmesini açtıysa)
- Artifact oluşturma (HTML, Python, Markdown)
- Seni Ahmet Selim Şentürk yazdı/geliştirdi."""

# ── Otomatik güncelleme ──────────────────────────────────────────────────────
# GitHub'daki deponun adı: "kullaniciadin/coode"  (boşsa güncelleme kontrolü kapalı)
GITHUB_REPO = "asil74775-arch/coode"

# ── Dizinler ──────────────────────────────────────────────────────────────────
# Exe olarak çalışırken: veriler exe'nin yanında, gömülü dosyalar (_MEIPASS) içinde
if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(sys.executable)
    RES_DIR  = getattr(sys, "_MEIPASS", BASE_DIR)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    RES_DIR  = BASE_DIR
DATA_DIR    = os.path.join(BASE_DIR, "data")
APPS_DIR    = os.path.join(BASE_DIR, "apps")
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
PLUGINS_DIR = os.path.join(BASE_DIR, "plugins")
RECIPES_DIR = os.path.join(BASE_DIR, "recipes")
MODULES_DIR = os.path.join(BASE_DIR, "modules")

for _d in (DATA_DIR, APPS_DIR, OUTPUTS_DIR, PLUGINS_DIR, RECIPES_DIR, MODULES_DIR):
    os.makedirs(_d, exist_ok=True)

# ── Veritabanı ────────────────────────────────────────────────────────────────
DB_PATH = os.path.join(DATA_DIR, "coode.db")

# ── Model ─────────────────────────────────────────────────────────────────────
# Ollama tabanlı (Qwen3-14B Q4 varsayılan). llm.py bu değerleri kullanır.
OLLAMA_HOST    = "http://localhost:11434"
OLLAMA_MODEL   = "qwen3:14b"          # ollama pull qwen3:14b
OLLAMA_TIMEOUT = 120                  # saniye

# Fine-tune edilmiş model varsa bu yolu doldur, boşsa Ollama kullanılır.
FINETUNED_MODEL_PATH = ""             # örn: "models/coode-ft"

# ── Groq API (ücretsiz, hızlı — Llama 70B / Qwen 32B) ───────────────────────
# groq.com'dan ücretsiz API key al → buraya yapıştır
GROQ_API_KEY = ""         # örn: "gsk_xxxx..."
GROQ_MODEL   = "qwen/qwen3.8-27b"
GROQ_TIMEOUT = 60

# ── Hugging Face API (GPU'suz sistemler için) ─────────────────────────────────
# HF Spaces'te çalışan Coode API'sine bağlanmak için bu değerleri doldur.
# Boş bırakılırsa Ollama veya yerel model kullanılır.
HF_API_URL = ""    # örn: "https://your-username-coode-api.hf.space"
HF_API_KEY = ""    # HF_API_URL doldurulduysa buraya HF token koy (opsiyonel)
HF_TIMEOUT = 120   # saniye

# ── Telemetri ─────────────────────────────────────────────────────────────────
TELEMETRY_INTERVAL_MS = 1500

# ── Tema ──────────────────────────────────────────────────────────────────────
THEME_PATH = os.path.join(BASE_DIR, "theme.json")

# ── Sandbox ───────────────────────────────────────────────────────────────────
SANDBOX_TIMEOUT  = 15        # saniye
SANDBOX_MAX_OUT  = 4096      # karakter

# ── gloWeb (Playwright) ───────────────────────────────────────────────────────
GLOWEB_TIMEOUT   = 30        # saniye
GLOWEB_HEADLESS  = True

# ── Ses / Wake Word ───────────────────────────────────────────────────────────
WAKE_PHRASES     = ["hey coode", "hey code", "hey kood", "hey küd"]
VOSK_MODEL_PATH  = os.path.join(DATA_DIR, "vosk-model-small-tr")

# ── Öz-Evrim ──────────────────────────────────────────────────────────────────
EVOLUTION_BACKUP_DIR = os.path.join(DATA_DIR, "backups")
os.makedirs(EVOLUTION_BACKUP_DIR, exist_ok=True)

ALLOWED_UI_OPS = [
    "set_color", "set_font_size", "toggle_sidebar",
    "add_tab", "remove_tab", "set_title",
]

# ── Görüntü / Video üretimi (opsiyonel) ─────────────────────────────────────
IMAGE_GEN_ENABLED = False
IMAGE_GEN_MODEL   = "stabilityai/stable-diffusion-xl-base-1.0"

VIDEO_GEN_ENABLED = False
VIDEO_GEN_MODEL   = ""

# ── FastAPI Sunucu ────────────────────────────────────────────────────────────
SERVER_HOST = "0.0.0.0"
SERVER_PORT = 8000

# ── OpenSky Radar ─────────────────────────────────────────────────────────────
OPENSKY_RADIUS_DEG = 2.0     # ~220 km yarıçap
