# research.py — Derin Araştırma paneli
# Claude'daki "Deep Research" özelliğinin Coode versiyonu.
# DuckDuckGo scraping + içerik özetleme + rapor üretimi.

import re
import requests
from PySide6.QtCore    import QThread, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QTextEdit, QFrame,
    QProgressBar,
)
import theme as th


# ── Arama motoru (DuckDuckGo HTML) ───────────────────────────────────────────
def _ddg_search(query: str, max_results: int = 5) -> list[dict]:
    headers = {"User-Agent": "Mozilla/5.0"}
    url     = f"https://html.duckduckgo.com/html/?q={requests.utils.quote(query)}"
    try:
        r     = requests.get(url, headers=headers, timeout=10)
        links = re.findall(r'href="(https?://[^"]+)"', r.text)
        titles= re.findall(r'<a[^>]+class="result__a"[^>]*>(.*?)</a>', r.text)
        results = []
        seen    = set()
        for link, title in zip(links, titles):
            if link in seen or "duckduckgo" in link:
                continue
            seen.add(link)
            clean_title = re.sub(r'<[^>]+>', '', title).strip()
            results.append({"url": link, "title": clean_title})
            if len(results) >= max_results:
                break
        return results
    except Exception as e:
        return [{"url": "", "title": f"Arama hatası: {e}"}]


def _fetch_text(url: str, max_chars: int = 2000) -> str:
    try:
        r    = requests.get(url, timeout=8, headers={"User-Agent": "Mozilla/5.0"})
        text = re.sub(r'<[^>]+>', ' ', r.text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text[:max_chars]
    except Exception:
        return ""


# ── QThread Worker ────────────────────────────────────────────────────────────
class ResearchWorker(QThread):
    progress = Signal(str)
    done     = Signal(str)
    error    = Signal(str)

    def __init__(self, query: str, use_llm: bool = True):
        super().__init__()
        self._query   = query
        self._use_llm = use_llm

    def run(self):
        try:
            self.progress.emit(f"'{self._query}' aranıyor…")
            results = _ddg_search(self._query, max_results=5)

            snippets = []
            for i, r in enumerate(results):
                self.progress.emit(f"{i+1}/{len(results)}: {r['title'][:60]}…")
                if r["url"]:
                    text = _fetch_text(r["url"])
                    snippets.append(f"### {r['title']}\nKaynak: {r['url']}\n\n{text}\n")

            combined = "\n\n".join(snippets)

            if self._use_llm and combined:
                self.progress.emit("🧠 Coode özetliyor…")
                report = self._summarize(combined)
            else:
                report = combined

            self.done.emit(report)
        except Exception as e:
            self.error.emit(str(e))

    def _summarize(self, text: str) -> str:
        from llm import _ollama_stream
        messages = [
            {
                "role": "user",
                "content": (
                    f"Şu araştırma notlarını Türkçe, düzenli bir rapor olarak özetle:\n\n"
                    f"Konu: {self._query}\n\n{text[:6000]}"
                ),
            }
        ]
        return "".join(_ollama_stream(messages))


# ── Araştırma Paneli ──────────────────────────────────────────────────────────
class ResearchPanel(QWidget):
    artifact_ready = Signal(str, str, str)   # name, type, content

    def __init__(self, parent=None):
        super().__init__(parent)
        self._worker = None
        self._build_ui()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # Başlık
        header = QFrame()
        header.setFixedHeight(52)
        header.setStyleSheet(
            f"background:{th.get('surface')}; border-bottom:1px solid {th.get('border')};"
        )
        hlay = QHBoxLayout(header)
        hlay.setContentsMargins(16, 0, 16, 0)
        title = QLabel("Araştırma")
        title.setStyleSheet(f"color:{th.get('text')}; font-size:15px; font-weight:bold;")
        hlay.addWidget(title)
        lay.addWidget(header)

        # Arama kutusu
        search_row = QWidget()
        search_row.setStyleSheet(f"background:{th.get('surface2')}; border-bottom:1px solid {th.get('border')};")
        slay = QHBoxLayout(search_row)
        slay.setContentsMargins(12, 10, 12, 10)

        self._query_input = QLineEdit()
        self._query_input.setPlaceholderText("Ne araştırayım? (örn: kuantum bilgisayarlar)")
        self._query_input.returnPressed.connect(self._start)
        slay.addWidget(self._query_input)

        self._btn = QPushButton("Araştır")
        self._btn.setObjectName("primary")
        self._btn.clicked.connect(self._start)
        slay.addWidget(self._btn)
        lay.addWidget(search_row)

        # Progress
        self._progress = QLabel("")
        self._progress.setStyleSheet(
            f"color:{th.get('accent')}; font-size:11px; padding:6px 16px; background:transparent;"
        )
        lay.addWidget(self._progress)

        # Sonuç
        self._result = QTextEdit()
        self._result.setReadOnly(True)
        self._result.setStyleSheet(
            f"background:{th.get('surface')}; color:{th.get('text')}; "
            f"border:none; padding:16px; font-size:13px; line-height:1.6;"
        )
        lay.addWidget(self._result, stretch=1)

        # Alt butonlar
        bot = QWidget()
        bot.setStyleSheet(f"background:{th.get('surface2')}; border-top:1px solid {th.get('border')};")
        blay = QHBoxLayout(bot)
        blay.setContentsMargins(12, 8, 12, 8)
        btn_art = QPushButton("Artifact Olarak Aç")
        btn_art.clicked.connect(self._to_artifact)
        blay.addStretch()
        blay.addWidget(btn_art)
        lay.addWidget(bot)

    def _start(self):
        q = self._query_input.text().strip()
        if not q:
            return
        self._btn.setEnabled(False)
        self._result.setPlainText("")
        self._progress.setText("Başlatılıyor…")

        self._worker = ResearchWorker(q)
        self._worker.progress.connect(self._progress.setText)
        self._worker.done.connect(self._on_done)
        self._worker.error.connect(lambda e: self._result.setPlainText(f"Hata: {e}"))
        self._worker.start()

    def _on_done(self, report: str):
        self._progress.setText("Tamamlandı")
        self._result.setMarkdown(report) if hasattr(self._result, 'setMarkdown') else self._result.setPlainText(report)
        self._btn.setEnabled(True)

    def _to_artifact(self):
        content = self._result.toPlainText()
        if content:
            q = self._query_input.text().strip()[:30]
            self.artifact_ready.emit(f"araştırma_{q}", "markdown", content)
