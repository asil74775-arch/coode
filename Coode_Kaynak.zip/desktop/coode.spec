# coode.spec — PyInstaller tarifi (KUR.bat bunu kullanir)
# Elle: pyinstaller --noconfirm coode.spec  ->  dist\Coode\Coode.exe

a = Analysis(
    ["main.py"],
    pathex=["."],
    datas=[
        ("logo.png", "."),
        ("logo_dark.png", "."),
        ("logo_light.png", "."),
        ("coode.ico", "."),
        ("theme.json", "."),
    ],
    hiddenimports=["groq", "agent", "pyautogui", "psutil", "pynvml", "speech", "reminders", "PySide6.QtTextToSpeech"],
    excludes=[
        "torch", "transformers", "peft", "bitsandbytes", "datasets", "deepspeed",
        "accelerate", "tensorflow", "jax", "diffusers", "faster_whisper", "vosk",
        "sounddevice", "playwright", "fastapi", "uvicorn", "tkinter",
    ],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="Coode",
    icon="coode.ico",
    console=False,          # siyah CMD penceresi acilmasin
    upx=False,
)

coll = COLLECT(exe, a.binaries, a.datas, name="Coode", upx=False)
