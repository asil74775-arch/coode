# Coode 3.7.2 — Kurulum

## Tek adım
1. Zip'i bir klasöre çıkar (ör. Masaüstü\CoodeAi_final).
2. Eski CoodeAi_final klasörün varsa, içindeki `data` klasörünü yeni klasöre kopyala
   (Groq anahtarın ve sohbet geçmişin taşınsın).
3. **KUR.bat**'a çift tıkla.

KUR.bat şunları kendisi yapar:
- Python yoksa kurar (winget ile) — kurduktan sonra KUR.bat'ı bir kez daha çalıştır
- Gerekli paketleri ayrı bir ortama kurar (bilgisayarındaki Python'u kirletmez)
- `Coode.exe`'yi oluşturur
- `dist\Coode_Setup_3.7.2.exe` kurulum dosyasını oluşturur ve kurulum sihirbazını açar
- Masaüstü + Başlat menüsü kısayolu ekler; Coode "Uygulamalar"dan kaldırılabilir

İlk çalıştırma 5–10 dakika sürebilir (PySide6 büyük bir paket). Sonrakiler hızlıdır.

`Coode_Setup_3.7.2.exe` dosyasını başka bilgisayarlara kopyalayıp doğrudan kurabilirsin;
orada Python gerekmez.

## İlk açılış
Ayarlar → Groq API → API anahtarını yapıştır → Model: `qwen/qwen3.8-27b` → Kaydet → Test Et.

## Geliştirici modu
Kurmadan kaynak koddan çalıştırmak için `coode.bat`.

## Dosyalar
| Dosya | Görevi |
|---|---|
| main.py | Ana pencere, sohbet, sol panel |
| agent.py | CodeAgent: arama, Chrome'da açma, uygulama açma, kod, dosya |
| llm.py | Model bağlantısı (Groq → HF → Ollama) |
| config.py | Ayarlar, sistem promptu |
| theme.py / theme.json | Renkler ve stil |
| widgets.py | Sohbet balonları, ikonlar, telemetri |
| settings_panel.py | Ayarlar ekranı |
| coode.spec | Exe tarifi (PyInstaller) |
| installer.iss | Setup.exe tarifi (Inno Setup) |
| KUR.bat | Tek tık kurulum |
