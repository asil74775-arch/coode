# speech.py — Coode'un sesli cevap özelliği (Türkçe metin okuma)
#
# Önce Qt'nin kendi motorunu (QTextToSpeech → Windows'un yerleşik sesleri) dener.
# Türkçe ses yoksa/Qt modülü yoksa PowerShell + System.Speech ile okur.

import re
import subprocess
import sys

_engine = None


def _clean(text: str) -> str:
    text = re.sub(r"<think>.*?</think>", "", text or "", flags=re.S)
    text = re.sub(r"```.*?```", " Kodu ekranda gosterdim. ", text, flags=re.S)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"[*_`#>|]", "", text)
    text = re.sub(r"^\s*[-•]\s+", "", text, flags=re.M)
    text = re.sub(r"\n{2,}", ". ", text)
    return text.strip()


class _QtEngine:
    def __init__(self):
        from PySide6.QtTextToSpeech import QTextToSpeech
        from PySide6.QtCore import QLocale
        self.tts = QTextToSpeech()
        tr = QLocale(QLocale.Turkish, QLocale.Turkey)
        voices = [v for v in self.tts.availableVoices() if v.locale().language() == QLocale.Turkish]
        self.tts.setLocale(tr)
        if not voices:
            # mevcut motorlarda Türkçe ses var mı?
            for name in QTextToSpeech.availableEngines():
                t = QTextToSpeech(name)
                tv = [v for v in t.availableVoices() if v.locale().language() == QLocale.Turkish]
                if tv:
                    self.tts = t
                    voices = tv
                    break
        if not voices:
            raise RuntimeError("Turkce ses yok")
        self.tts.setVoice(voices[0])

    def say(self, text):
        self.tts.say(text)

    def stop(self):
        self.tts.stop()


class _PowerShellEngine:
    """Windows System.Speech — Türkçe ses yoksa varsayılan sesle okur."""
    def __init__(self):
        if sys.platform != "win32":
            raise RuntimeError("Windows degil")
        self.proc = None

    def say(self, text):
        self.stop()
        script = (
            "Add-Type -AssemblyName System.Speech;"
            "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            "$v=$s.GetInstalledVoices()|?{$_.VoiceInfo.Culture.Name -like 'tr*'}|select -First 1;"
            "if($v){$s.SelectVoice($v.VoiceInfo.Name)};"
            "$s.Speak([Console]::In.ReadToEnd())"
        )
        flags = 0x08000000  # CREATE_NO_WINDOW
        self.proc = subprocess.Popen(
            ["powershell", "-NoProfile", "-Command", script],
            stdin=subprocess.PIPE, creationflags=flags,
        )
        try:
            self.proc.stdin.write(text.encode("utf-8"))
            self.proc.stdin.close()
        except Exception:
            pass

    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.kill()
            except Exception:
                pass
        self.proc = None


def _get():
    global _engine
    if _engine is None:
        for cls in (_QtEngine, _PowerShellEngine):
            try:
                _engine = cls()
                break
            except Exception as e:
                print(f"[speech] {cls.__name__} kullanilamadi: {e}")
    return _engine


def speak(text: str):
    text = _clean(text)
    eng = _get()
    if eng and text:
        try:
            eng.say(text)
        except Exception as e:
            print(f"[speech] okuma hatasi: {e}")


def stop():
    if _engine:
        try:
            _engine.stop()
        except Exception:
            pass
