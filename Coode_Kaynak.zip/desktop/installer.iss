; installer.iss — Inno Setup betigi -> Coode_Setup.exe
; KUR.bat otomatik derler. Elle: ISCC.exe installer.iss

#define AppName "Coode"
#ifndef AppVersion
  #define AppVersion "3.8.0"
#endif
#define AppPublisher "Ahmet Selim Senturk"

[Setup]
AppId={{6C0DE372-C0DE-4A1B-9E37-C0DE00003720}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={localappdata}\Programs\Coode
DefaultGroupName=Coode
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=dist
OutputBaseFilename=Coode_Setup_{#AppVersion}
SetupIconFile=coode.ico
UninstallDisplayIcon={app}\Coode.exe
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes

[Languages]
Name: "turkish"; MessagesFile: "compiler:Languages\Turkish.isl"

[Tasks]
Name: "desktopicon"; Description: "Masaustune kisayol olustur"; GroupDescription: "Kisayollar:"

[Files]
Source: "dist\Coode\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Coode"; Filename: "{app}\Coode.exe"; IconFilename: "{app}\Coode.exe"
Name: "{autodesktop}\Coode"; Filename: "{app}\Coode.exe"; IconFilename: "{app}\Coode.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\Coode.exe"; Description: "Coode'u simdi baslat"; Flags: nowait postinstall skipifsilent
Filename: "{app}\Coode.exe"; Flags: nowait; Check: IsUpdate

[Code]
// Uygulama icinden sessiz guncellemede (/UPDATE=1) kurulum bitince Coode'u yeniden ac
function IsUpdate: Boolean;
begin
  Result := ExpandConstant('{param:UPDATE|0}') = '1';
end;
