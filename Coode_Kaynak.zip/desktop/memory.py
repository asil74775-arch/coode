# memory.py — SQLite kalıcı bellek
# Konuşmalar, tercihler, projeler, evrim logu burada saklanır.

import sqlite3
import json
import time
from config import DB_PATH


def _conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with _conn() as c:
        c.executescript("""
            CREATE TABLE IF NOT EXISTS conversations (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                session   TEXT NOT NULL,
                role      TEXT NOT NULL,
                content   TEXT NOT NULL,
                ts        REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS preferences (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS projects (
                name    TEXT PRIMARY KEY,
                data    TEXT NOT NULL,
                updated REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS evolution_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ts          REAL NOT NULL,
                action      TEXT NOT NULL,
                description TEXT,
                file_path   TEXT,
                backup_path TEXT
            );
        """)


def save_message(session: str, role: str, content: str):
    with _conn() as c:
        c.execute(
            "INSERT INTO conversations (session,role,content,ts) VALUES (?,?,?,?)",
            (session, role, content, time.time())
        )


def get_history(session: str, limit: int = 40) -> list[dict]:
    with _conn() as c:
        rows = c.execute(
            "SELECT role,content FROM conversations WHERE session=? ORDER BY ts DESC LIMIT ?",
            (session, limit)
        ).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


def clear_session(session: str):
    with _conn() as c:
        c.execute("DELETE FROM conversations WHERE session=?", (session,))


def list_sessions() -> list[dict]:
    """Her session'ın ilk mesajını ve mesaj sayısını döner."""
    with _conn() as c:
        rows = c.execute("""
            SELECT session,
                   COUNT(*) as cnt,
                   MIN(ts)  as first_ts,
                   (SELECT content FROM conversations c2
                    WHERE c2.session=c.session AND c2.role='user'
                    ORDER BY ts LIMIT 1) as preview
            FROM conversations c
            GROUP BY session
            ORDER BY first_ts DESC
            LIMIT 50
        """).fetchall()
    return [dict(r) for r in rows]


def set_pref(key: str, value):
    with _conn() as c:
        c.execute(
            "INSERT OR REPLACE INTO preferences (key,value) VALUES (?,?)",
            (key, json.dumps(value))
        )


def get_pref(key: str, default=None):
    with _conn() as c:
        row = c.execute("SELECT value FROM preferences WHERE key=?", (key,)).fetchone()
    if row is None:
        return default
    return json.loads(row["value"])


def save_project(name: str, data: dict):
    with _conn() as c:
        c.execute(
            "INSERT OR REPLACE INTO projects (name,data,updated) VALUES (?,?,?)",
            (name, json.dumps(data), time.time())
        )


def rename_session(session: str, new_name: str):
    """Bir session'a özel görünen ad atar (preferences tablosunda saklanır)."""
    set_pref(f"session_name_{session}", new_name)


def get_session_name(session: str) -> str:
    """Session'ın görünen adını döner; yoksa session id'yi döner."""
    return get_pref(f"session_name_{session}", default=session)


def delete_session(session: str):
    """Session'ın tüm mesajlarını ve adını siler."""
    with _conn() as c:
        c.execute("DELETE FROM conversations WHERE session=?", (session,))
    # Kayıtlı adı da sil
    with _conn() as c:
        c.execute("DELETE FROM preferences WHERE key=?", (f"session_name_{session}",))


def log_evolution(action: str, description: str = "", file_path: str = "", backup_path: str = ""):
    with _conn() as c:
        c.execute(
            "INSERT INTO evolution_log (ts,action,description,file_path,backup_path) VALUES (?,?,?,?,?)",
            (time.time(), action, description, file_path, backup_path)
        )
