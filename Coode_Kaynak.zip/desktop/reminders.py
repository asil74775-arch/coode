# reminders.py — PC'de alarm, zamanlayıcı ve hatırlatıcılar
#
# Kayıtlar veritabanında (preferences: "reminders") tutulur; Coode açıkken
# (pencere kapalı olsa bile sistem tepsisinde) her 10 saniyede kontrol edilir.
# Zamanı gelince: bildirim + ses + pencere.

import time
import uuid
from datetime import datetime, timedelta

from PySide6.QtCore import QObject, QTimer, Signal

import memory as mem

_KEY = "reminders"


def _load() -> list:
    return list(mem.get_pref(_KEY, []) or [])


def _save(items: list):
    mem.set_pref(_KEY, items)


def _add(due: float, label: str, kind: str) -> dict:
    item = {"id": uuid.uuid4().hex[:8], "due": float(due), "label": label or "Coode", "kind": kind}
    items = _load()
    items.append(item)
    _save(sorted(items, key=lambda x: x["due"]))
    return item


def fmt(ts: float) -> str:
    d = datetime.fromtimestamp(ts)
    today = datetime.now().date()
    if d.date() == today:
        day = "bugun"
    elif d.date() == today + timedelta(days=1):
        day = "yarin"
    else:
        day = d.strftime("%d.%m.%Y")
    return f"{day} {d.strftime('%H:%M')}"


def add_alarm(hour: int, minute: int, label: str = "") -> dict:
    now = datetime.now()
    t = now.replace(hour=int(hour) % 24, minute=int(minute) % 60, second=0, microsecond=0)
    if t <= now:
        t += timedelta(days=1)
    return _add(t.timestamp(), label or "Alarm", "alarm")


def add_timer(seconds: float, label: str = "") -> dict:
    return _add(time.time() + max(1, float(seconds)), label or "Sure doldu", "timer")


def add_reminder(title: str, when_iso: str) -> dict:
    t = datetime.fromisoformat(when_iso.strip().replace("Z", ""))
    if t.timestamp() <= time.time():
        raise ValueError("Bu zaman gecmiste kaldi.")
    return _add(t.timestamp(), title, "reminder")


def list_pending() -> list:
    return [x for x in _load() if x["due"] > time.time() - 60]


def cancel(rid: str = "", label: str = "") -> int:
    items = _load()
    keep = [x for x in items if not ((rid and x["id"] == rid) or (label and label.lower() in x["label"].lower()))]
    _save(keep)
    return len(items) - len(keep)


def pop_due() -> list:
    items = _load()
    now = time.time()
    due = [x for x in items if x["due"] <= now]
    if due:
        _save([x for x in items if x["due"] > now])
    return due


class ReminderService(QObject):
    """Ana pencerede çalışır; zamanı gelen kayıtları `fired` ile bildirir."""
    fired = Signal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._check)
        self._timer.start(10_000)
        QTimer.singleShot(2000, self._check)

    def _check(self):
        try:
            for item in pop_due():
                self.fired.emit(item)
        except Exception as e:
            print(f"[reminders] {e}")
