# server.py — FastAPI sunucu (telefon ↔ PC köprüsü)
# Ollama üzerinden model; WebSocket streaming; PC komutları.

from __future__ import annotations
import os
import json
import asyncio
import threading
import time
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import requests

# Coode modülleri
import sys
sys.path.insert(0, os.path.dirname(__file__))
from config import OLLAMA_HOST, OLLAMA_MODEL, OLLAMA_TIMEOUT, SERVER_HOST, SERVER_PORT
from memory import init_db, save_message, get_history, clear_session, list_sessions
from sandbox import run_code, run_app, list_apps
from radar  import get_location, fetch_flights

try:
    from telemetry import _gpu_stats
    import psutil
    _HAS_TEL = True
except Exception:
    _HAS_TEL = False


# ── Lifespan ──────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(title="Coode Server", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)


# ── Telemetri yardımcı ────────────────────────────────────────────────────────
def _telemetry_snapshot() -> dict:
    if not _HAS_TEL:
        return {}
    gpu, vram, vram_total = _gpu_stats()
    return {
        "cpu":        psutil.cpu_percent(),
        "ram":        psutil.virtual_memory().percent,
        "gpu":        gpu,
        "vram":       round(vram, 2),
        "vram_total": round(vram_total, 2),
    }


# ── Ollama stream ─────────────────────────────────────────────────────────────
def _ollama_stream(messages: list[dict]):
    from config import SYSTEM_PROMPT
    all_msgs = [{"role": "system", "content": SYSTEM_PROMPT}] + messages
    url      = f"{OLLAMA_HOST}/api/chat"
    payload  = {"model": OLLAMA_MODEL, "messages": all_msgs, "stream": True}
    with requests.post(url, json=payload, stream=True, timeout=OLLAMA_TIMEOUT) as r:
        r.raise_for_status()
        for line in r.iter_lines():
            if not line:
                continue
            data  = json.loads(line)
            token = data.get("message", {}).get("content", "")
            if token:
                yield token
            if data.get("done"):
                break


# ── Rotalar ───────────────────────────────────────────────────────────────────
@app.get("/ping")
def ping():
    return {"ok": True}


@app.get("/status")
def status():
    return {
        "model_loaded": True,
        "model_name":   OLLAMA_MODEL,
        "telemetry":    _telemetry_snapshot(),
    }


class ChatReq(BaseModel):
    session_id: str
    message:    str


@app.post("/chat")
def chat(req: ChatReq):
    history  = get_history(req.session_id)
    messages = history + [{"role": "user", "content": req.message}]
    save_message(req.session_id, "user", req.message)
    full = "".join(_ollama_stream(messages))
    save_message(req.session_id, "assistant", full)
    return {"response": full}


@app.websocket("/ws/chat")
async def ws_chat(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            raw  = await ws.receive_text()
            data = json.loads(raw)
            sid  = data.get("session_id", "default")
            msg  = data.get("message", "")

            history  = get_history(sid)
            messages = history + [{"role": "user", "content": msg}]
            save_message(sid, "user", msg)

            full = ""
            loop = asyncio.get_event_loop()

            def _stream():
                nonlocal full
                for tok in _ollama_stream(messages):
                    full += tok
                    asyncio.run_coroutine_threadsafe(
                        ws.send_text(json.dumps({"type": "token", "text": tok})),
                        loop,
                    )

            await loop.run_in_executor(None, _stream)
            save_message(sid, "assistant", full)
            await ws.send_text(json.dumps({"type": "done", "full": full}))

    except WebSocketDisconnect:
        pass


# ── Oturum geçmişi ─────────────────────────────────────────────────────────────
@app.get("/sessions")
def sessions():
    return list_sessions()


@app.get("/history/{session_id}")
def history(session_id: str):
    return get_history(session_id)


@app.delete("/history/{session_id}")
def delete_history(session_id: str):
    clear_session(session_id)
    return {"ok": True}


# ── Uçak radarı ────────────────────────────────────────────────────────────────
@app.get("/flights")
def flights():
    lat, lon = get_location()
    return {"lat": lat, "lon": lon, "flights": fetch_flights(lat, lon)}


# ── App Lab ────────────────────────────────────────────────────────────────────
@app.get("/applab")
def applab_list():
    return list_apps()


class RunAppReq(BaseModel):
    path: str


@app.post("/applab/run")
def applab_run(req: RunAppReq):
    r = run_app(req.path)
    return {"ok": r.ok, "output": r.output, "error": r.error}


# ── PC Komutları ───────────────────────────────────────────────────────────────
_ALLOWED_CMDS = {"screenshot", "open_file", "open_url", "shell"}
_ALLOWED_SHELL = {"ipconfig", "systeminfo", "tasklist", "ping"}


class CommandReq(BaseModel):
    command: str
    args:    dict = {}


@app.post("/command")
def command(req: CommandReq):
    if req.command not in _ALLOWED_CMDS:
        raise HTTPException(400, f"İzin verilmeyen komut: {req.command}")

    if req.command == "screenshot":
        try:
            import pyautogui, datetime
            from config import OUTPUTS_DIR
            path = os.path.join(OUTPUTS_DIR, f"ss_{int(time.time())}.png")
            pyautogui.screenshot(path)
            return {"ok": True, "path": path}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    if req.command == "open_file":
        path = req.args.get("path", "")
        try:
            os.startfile(path)
            return {"ok": True, "path": path}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    if req.command == "open_url":
        url = req.args.get("url", "")
        try:
            import webbrowser
            webbrowser.open(url)
            return {"ok": True, "url": url}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    if req.command == "shell":
        cmd = req.args.get("cmd", "").split()[0] if req.args.get("cmd") else ""
        if cmd not in _ALLOWED_SHELL:
            return {"ok": False, "error": f"Yasaklı shell komutu: {cmd}"}
        import subprocess
        r = subprocess.run(req.args["cmd"], capture_output=True, text=True, timeout=10)
        return {"ok": True, "output": r.stdout + r.stderr}

    return {"ok": False, "error": "Bilinmeyen komut"}


# ── Çalıştır ───────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=SERVER_HOST, port=SERVER_PORT)
