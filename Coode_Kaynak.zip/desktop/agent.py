# agent.py — CodeAgent motoru
# Coode'un Claude Code benzeri agentic modu.
# Groq açıkken her mesaj buradan geçer; araç gerekip gerekmediğine model kendisi karar verir.
#
# Araçlar:
#   web_search   — internette ara (DuckDuckGo → Bing yedekli)
#   open_url     — varsayılan tarayıcıda (Chrome vb.) adres / YouTube / Google araması aç
#   open_app     — bilgisayarda uygulama aç (not defteri, hesap makinesi, chrome ...)
#   run_python   — Python kodu çalıştır
#   read_file    — dosya oku
#   write_file   — dosya yaz (varsayılan: outputs klasörü)
#   list_dir     — klasör listele
#   shell_cmd    — güvenli terminal komutu

import json
import os
import re
import sys
import html
import subprocess
import traceback
import urllib.parse
import webbrowser

from PySide6.QtCore import QThread, Signal
from config import OUTPUTS_DIR, BASE_DIR


# ── Araç tanımları (OpenAI function calling formatı) ─────────────────────────
def _fn(name, desc, props, required):
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": desc,
            "parameters": {"type": "object", "properties": props, "required": required},
        },
    }


TOOLS = [
    _fn("web_search",
        "Internette arama yap. Guncel bilgi, haber, fiyat, belge icin kullan.",
        {"query": {"type": "string", "description": "Arama sorgusu"}}, ["query"]),
    _fn("open_url",
        "Kullanicinin bilgisayarinda varsayilan tarayicida (Chrome vb.) bir sayfa ac. "
        "Video istenirse site='youtube', genel arama icin site='google', "
        "dogrudan adres icin url ver.",
        {"url":   {"type": "string", "description": "Tam adres (opsiyonel)"},
         "site":  {"type": "string", "enum": ["youtube", "google", "url"],
                   "description": "youtube | google | url"},
         "query": {"type": "string", "description": "youtube/google icin arama metni"}},
        ["site"]),
    _fn("open_app",
        "Kullanicinin bilgisayarinda bir uygulama ac. Ornek: notepad, calc, chrome, explorer, spotify.",
        {"name": {"type": "string", "description": "Uygulama adi"}}, ["name"]),
    _fn("run_python",
        "Python kodu calistir ve print ciktisini al. Hesaplama ve veri isleme icin kullan.",
        {"code": {"type": "string", "description": "Calistirilacak Python kodu"}}, ["code"]),
    _fn("read_file",
        "Bir dosyanin icerigini oku.",
        {"path": {"type": "string", "description": "Dosya yolu"}}, ["path"]),
    _fn("write_file",
        "Dosya olustur veya uzerine yaz. Goreceli yol outputs klasorune yazilir.",
        {"path":    {"type": "string", "description": "Dosya yolu"},
         "content": {"type": "string", "description": "Icerik"}}, ["path", "content"]),
    _fn("list_dir",
        "Bir klasorun icerigini listele.",
        {"path": {"type": "string", "description": "Klasor yolu"}}, ["path"]),
    _fn("set_alarm",
        "Belirli bir saate alarm kurar (Coode acikken calar; gecmis saatse ertesi gun).",
        {"hour": {"type": "integer"}, "minute": {"type": "integer"},
         "label": {"type": "string", "description": "Alarm notu"}}, ["hour", "minute"]),
    _fn("set_timer",
        "Su andan itibaren geri sayim kurar ('20 dk sonra hatirlat').",
        {"minutes": {"type": "number"}, "seconds": {"type": "number"},
         "label": {"type": "string"}}, ["minutes"]),
    _fn("add_reminder",
        "Ileri bir tarih/saate hatirlatici ekler.",
        {"title": {"type": "string"},
         "datetime": {"type": "string", "description": "YYYY-MM-DDTHH:MM"}}, ["title", "datetime"]),
    _fn("list_reminders", "Kurulu alarm ve hatirlaticilari listeler.", {}, []),
    _fn("cancel_reminder", "Alarm/hatirlatici iptal eder (id veya etiketle).",
        {"id": {"type": "string"}, "label": {"type": "string"}}, []),
    _fn("save_contact", "Kullanicinin verdigi kisi adi ve numarasini kaydeder.",
        {"name": {"type": "string"}, "number": {"type": "string"}}, ["name", "number"]),
    _fn("whatsapp",
        "WhatsApp'ta mesaji yazili acar; GONDER'e kullanici basar. Kisi adi kayitli kisilerden bulunur.",
        {"name": {"type": "string"}, "number": {"type": "string"}, "text": {"type": "string"}}, ["text"]),
    _fn("call",
        "Telefon Baglantisi (Phone Link) ile arama ekranini acar; aramayi kullanici baslatir.",
        {"name": {"type": "string"}, "number": {"type": "string"}}, []),
    _fn("shell_cmd",
        "Guvenli terminal komutu calistir (dir, echo, ipconfig, systeminfo, tasklist, "
        "pip list, git status/log).",
        {"cmd": {"type": "string", "description": "Komut"}}, ["cmd"]),
]

AGENT_INSTRUCTIONS = """

## CodeAgent modu
Sen ayni zamanda CodeAgent'sin: kullanicinin Windows bilgisayarinda araclarla is yapabilirsin.
- Bir islem gerekiyorsa (arama, dosya, kod calistirma, tarayicida/uygulamada bir sey acma) ilgili araci CAGIR. "Yapamiyorum" deme.
- "Chrome'da ac", "videolari ac", "YouTube'da goster" gibi isteklerde open_url kullan.
- Guncel bilgi gerekiyorsa web_search kullan; sonuclari ozetle ve kaynak ver.
- Sadece sohbet ise arac cagirma, dogrudan cevap ver.
- Alarm/hatirlatici: belirli saat -> set_alarm, goreli sure -> set_timer, ileri tarih -> add_reminder.
  Tarih hesaplarken sistem mesajindaki "Su an" bilgisini kullan.
- WhatsApp/arama: once kayitli kisilerden ada bak; numara bilinmiyorsa kullaniciya sor ve save_contact ile kaydet.
  Mesaji kullanicinin agzindan yaz; gonderme kararini kullanici verir.
- Islem bitince ne yaptigini kisaca Turkce anlat.
- Araclar ciktilari: dosyalar varsayilan olarak su klasore yazilir: """ + OUTPUTS_DIR


# ── Araç çalıştırıcılar ───────────────────────────────────────────────────────
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")


def _strip(t: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", "", t or "")).strip()


def _search_ddg(query: str) -> list[tuple[str, str, str]]:
    import requests
    r = requests.post("https://html.duckduckgo.com/html/", data={"q": query},
                      headers={"User-Agent": _UA}, timeout=10)
    body = r.text
    out = []
    for m in re.finditer(
        r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>.*?class="result__snippet"[^>]*>(.*?)</', body, re.S
    ):
        href = m.group(1)
        if "uddg=" in href:
            href = urllib.parse.unquote(href.split("uddg=")[1].split("&")[0])
        out.append((_strip(m.group(2)), href, _strip(m.group(3))))
    return out


def _search_bing(query: str) -> list[tuple[str, str, str]]:
    import requests
    r = requests.get("https://www.bing.com/search", params={"q": query, "setlang": "tr"},
                     headers={"User-Agent": _UA}, timeout=10)
    out = []
    for block in re.findall(r'<li class="b_algo".*?</li>', r.text, re.S):
        a = re.search(r'<h2[^>]*><a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', block, re.S)
        p = re.search(r"<p[^>]*>(.*?)</p>", block, re.S)
        if a:
            out.append((_strip(a.group(2)), a.group(1), _strip(p.group(1)) if p else ""))
    return out


def _tool_web_search(query: str) -> str:
    results, errors = [], []
    for engine in (_search_ddg, _search_bing):
        try:
            results = engine(query)
            if results:
                break
        except Exception as e:
            errors.append(f"{engine.__name__}: {e}")
    if not results:
        return "Sonuc bulunamadi. " + ("; ".join(errors) if errors else "")
    return "\n\n".join(f"- {t}\n  {u}\n  {s}" for t, u, s in results[:6])


def _tool_open_url(site: str = "url", url: str = "", query: str = "") -> str:
    site = (site or "url").lower()
    q = urllib.parse.quote_plus(query or "")
    if site == "youtube":
        target = f"https://www.youtube.com/results?search_query={q}"
    elif site == "google":
        target = f"https://www.google.com/search?q={q}"
    else:
        target = url or (f"https://www.google.com/search?q={q}" if q else "")
        if target and not target.startswith(("http://", "https://")):
            target = "https://" + target
    if not target:
        return "Acilacak adres yok."
    # Chrome yüklüyse onunla, değilse varsayılan tarayıcıyla aç
    if sys.platform == "win32":
        for path in (
            os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
        ):
            if os.path.isfile(path):
                subprocess.Popen([path, target])
                return f"Chrome'da acildi: {target}"
    webbrowser.open(target)
    return f"Tarayicida acildi: {target}"


_APP_ALIASES = {
    "not defteri": "notepad", "notepad": "notepad",
    "hesap makinesi": "calc", "calc": "calc", "calculator": "calc",
    "paint": "mspaint", "dosya gezgini": "explorer", "explorer": "explorer",
    "chrome": "chrome", "google chrome": "chrome", "edge": "msedge",
    "cmd": "cmd", "terminal": "wt", "ayarlar": "ms-settings:",
    "spotify": "spotify", "discord": "discord", "steam": "steam",
    "word": "winword", "excel": "excel", "powerpoint": "powerpnt",
    "vs code": "code", "vscode": "code",
}


def _tool_open_app(name: str) -> str:
    key = (name or "").strip().lower()
    target = _APP_ALIASES.get(key, key)
    if not target:
        return "Uygulama adi bos."
    try:
        if sys.platform == "win32":
            os.startfile(target) if target.endswith(":") else subprocess.Popen(
                f'start "" {target}', shell=True)
        else:
            subprocess.Popen([target])
        return f"Acildi: {name}"
    except Exception as e:
        return f"Acilamadi ({name}): {e}"


def _tool_run_python(code: str) -> str:
    import io
    import contextlib
    buf = io.StringIO()
    env = {"__builtins__": __builtins__, "__name__": "__agent__", "OUTPUTS_DIR": OUTPUTS_DIR}
    try:
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            exec(compile(code, "<agent>", "exec"), env)  # noqa: S102
        out = buf.getvalue()
        return out[:4000] if out else "(cikti yok — sonucu gormek icin print kullan)"
    except Exception:
        return f"{buf.getvalue()[:1000]}\nHATA:\n{traceback.format_exc()[-2000:]}"


def _resolve(path: str, default_dir: str) -> str:
    path = os.path.expandvars(os.path.expanduser(path or "."))
    return path if os.path.isabs(path) else os.path.join(default_dir, path)


def _tool_read_file(path: str) -> str:
    try:
        with open(_resolve(path, BASE_DIR), encoding="utf-8", errors="replace") as f:
            return f.read(8000)
    except Exception as e:
        return f"Dosya okunamadi: {e}"


def _tool_write_file(path: str, content: str) -> str:
    try:
        full = _resolve(path, OUTPUTS_DIR)
        os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(content)
        return f"Yazildi: {full}"
    except Exception as e:
        return f"Yazilamadi: {e}"


def _tool_list_dir(path: str) -> str:
    try:
        full = _resolve(path, BASE_DIR)
        items = sorted(os.listdir(full))
        return "\n".join(
            (i + "/") if os.path.isdir(os.path.join(full, i)) else i for i in items[:150]
        ) or "(bos klasor)"
    except Exception as e:
        return f"Listelenemiyor: {e}"


_SAFE_SHELL_PREFIXES = (
    "dir", "echo", "ipconfig", "systeminfo", "tasklist", "hostname", "whoami",
    "ver", "where", "pip list", "pip show", "git status", "git log", "git branch",
    "ls", "cat", "type", "ping",
)


def _tool_shell_cmd(cmd: str) -> str:
    c = (cmd or "").strip()
    if not any(c.lower().startswith(p) for p in _SAFE_SHELL_PREFIXES) or any(
        x in c for x in ("&&", "||", ";", "|", ">", "<")
    ):
        return f"Guvenlik: bu komuta izin yok -> '{c}'"
    try:
        r = subprocess.run(c, shell=True, capture_output=True, timeout=20,
                           encoding="utf-8", errors="replace")
        return ((r.stdout or "") + (r.stderr or ""))[:3000] or "(cikti yok)"
    except Exception as e:
        return f"Komut hatasi: {e}"


# ── Alarm / hatırlatıcı / kişiler ────────────────────────────────────────────
def _tool_set_alarm(a):
    import reminders as rm
    it = rm.add_alarm(a.get("hour", 0), a.get("minute", 0), a.get("label", ""))
    return f"Alarm kuruldu: {rm.fmt(it['due'])} ({it['label']}) id={it['id']}"


def _tool_set_timer(a):
    import reminders as rm
    sec = float(a.get("minutes") or 0) * 60 + float(a.get("seconds") or 0)
    if sec <= 0:
        return "Sure gecersiz."
    it = rm.add_timer(sec, a.get("label", ""))
    return f"Zamanlayici kuruldu: {rm.fmt(it['due'])} ({it['label']}) id={it['id']}"


def _tool_add_reminder(a):
    import reminders as rm
    try:
        it = rm.add_reminder(a.get("title", "Hatirlatici"), a.get("datetime", ""))
    except Exception as e:
        return f"Hatirlatici eklenemedi: {e}"
    return f"Hatirlatici eklendi: {rm.fmt(it['due'])} ({it['label']}) id={it['id']}"


def _tool_list_reminders(a):
    import reminders as rm
    items = rm.list_pending()
    return "\n".join(f"- {rm.fmt(x['due'])}: {x['label']} (id={x['id']})" for x in items) or "Kurulu alarm yok."


def _tool_cancel_reminder(a):
    import reminders as rm
    n = rm.cancel(a.get("id", ""), a.get("label", ""))
    return f"{n} kayit iptal edildi."


def _contacts() -> dict:
    import memory as mem
    return dict(mem.get_pref("contacts", {}) or {})


def _tool_save_contact(a):
    import memory as mem
    c = _contacts()
    c[(a.get("name") or "").strip()] = (a.get("number") or "").strip()
    mem.set_pref("contacts", c)
    return f"Kaydedildi: {a.get('name')} {a.get('number')}"


def _resolve_contact(a):
    num = (a.get("number") or "").strip()
    if re.search(r"\d{3,}", num):
        return a.get("name") or num, num
    name = (a.get("name") or "").strip().lower()
    if not name:
        return None, None
    for k, v in _contacts().items():
        if k.lower() == name or name in k.lower() or k.lower() in name:
            return k, v
    return a.get("name"), None


def _intl(num: str) -> str:
    d = re.sub(r"\D", "", num)
    if d.startswith("00"):
        d = d[2:]
    elif d.startswith("0"):
        d = "90" + d[1:]
    elif len(d) == 10 and d.startswith("5"):
        d = "90" + d
    return d


def _open_uri(uri: str) -> bool:
    try:
        if sys.platform == "win32":
            os.startfile(uri)
        else:
            webbrowser.open(uri)
        return True
    except Exception:
        return False


def _tool_whatsapp(a):
    text = urllib.parse.quote(a.get("text", ""))
    name, num = _resolve_contact(a)
    if (a.get("name") or a.get("number")) and not num:
        return f"'{name}' icin kayitli numara yok. Kullanicidan numarayi iste ve save_contact ile kaydet."
    if num:
        n = _intl(num)
        if _open_uri(f"whatsapp://send?phone={n}&text={text}"):
            return f"WhatsApp'ta {name} sohbeti mesaj yazili acildi; kullanici gonderecek."
        webbrowser.open(f"https://web.whatsapp.com/send?phone={n}&text={text}")
        return f"WhatsApp Web'de {name} sohbeti acildi; kullanici gonderecek."
    if _open_uri(f"whatsapp://send?text={text}"):
        return "WhatsApp acildi; kisi secimi kullanicida."
    webbrowser.open(f"https://web.whatsapp.com/send?text={text}")
    return "WhatsApp Web acildi; kisi secimi kullanicida."


def _tool_call(a):
    name, num = _resolve_contact(a)
    if not num:
        return f"'{name or ''}' icin kayitli numara yok. Kullanicidan numarayi iste ve save_contact ile kaydet."
    if _open_uri(f"tel:+{_intl(num)}"):
        return f"{name} icin arama ekrani acildi (Telefon Baglantisi). Aramayi kullanici baslatacak."
    return "Arama acilamadi: bilgisayarda Telefon Baglantisi (Phone Link) kurulu ve telefona bagli olmali."


_TOOL_DISPATCH = {
    "set_alarm":       _tool_set_alarm,
    "set_timer":       _tool_set_timer,
    "add_reminder":    _tool_add_reminder,
    "list_reminders":  _tool_list_reminders,
    "cancel_reminder": _tool_cancel_reminder,
    "save_contact":    _tool_save_contact,
    "whatsapp":        _tool_whatsapp,
    "call":            _tool_call,
    "web_search": lambda a: _tool_web_search(a.get("query", "")),
    "open_url":   lambda a: _tool_open_url(a.get("site", "url"), a.get("url", ""), a.get("query", "")),
    "open_app":   lambda a: _tool_open_app(a.get("name", "")),
    "run_python": lambda a: _tool_run_python(a.get("code", "")),
    "read_file":  lambda a: _tool_read_file(a.get("path", "")),
    "write_file": lambda a: _tool_write_file(a.get("path", ""), a.get("content", "")),
    "list_dir":   lambda a: _tool_list_dir(a.get("path", ".")),
    "shell_cmd":  lambda a: _tool_shell_cmd(a.get("cmd", "")),
}


def run_tool(name: str, args: dict) -> str:
    fn = _TOOL_DISPATCH.get(name)
    if fn is None:
        return f"Bilinmeyen arac: {name}"
    try:
        return fn(args or {})
    except Exception as e:
        return f"Arac hatasi ({name}): {e}"


def should_use_agent(user_msg: str) -> bool:
    """Groq açıkken her mesaj agent'tan geçer; araç kullanıp kullanmamaya model karar verir."""
    return bool(user_msg and user_msg.strip())


# ── QThread: CodeAgent çalıştırıcı ───────────────────────────────────────────
class CodeAgentWorker(QThread):
    step     = Signal(str)   # "web_search(query='...')"
    token    = Signal(str)
    finished = Signal(str)
    error    = Signal(str)

    MAX_STEPS = 8

    def __init__(self, messages: list[dict], groq_key: str, model: str):
        super().__init__()
        self._messages = [dict(m) for m in messages]
        if self._messages and self._messages[0].get("role") == "system":
            self._messages[0]["content"] += AGENT_INSTRUCTIONS
        else:
            self._messages.insert(0, {"role": "system", "content": AGENT_INSTRUCTIONS})
        self._groq_key = groq_key
        self._model    = model

    def run(self):
        try:
            self.finished.emit(self._agent_loop())
        except Exception as e:
            self.error.emit(_friendly_error(e))

    def _create(self, client, msgs, with_tools=True):
        kwargs = dict(model=self._model, messages=msgs, max_tokens=2048, temperature=0.6)
        if with_tools:
            kwargs.update(tools=TOOLS, tool_choice="auto")
        # Qwen3 gibi akıl yürüten modellerde <think> çıktısını gizle
        try:
            return client.chat.completions.create(reasoning_format="hidden", **kwargs)
        except Exception as e:
            if "reasoning" in str(e).lower():
                return client.chat.completions.create(**kwargs)
            raise

    def _agent_loop(self) -> str:
        from groq import Groq
        client = Groq(api_key=self._groq_key, timeout=60)
        msgs = list(self._messages)

        for _ in range(self.MAX_STEPS):
            try:
                resp = self._create(client, msgs, with_tools=True)
            except Exception as e:
                # Model bozuk araç çağrısı üretirse (tool_use_failed) araçsız cevap al
                if "tool" in str(e).lower() or "function" in str(e).lower():
                    resp = self._create(client, msgs, with_tools=False)
                else:
                    raise

            msg = resp.choices[0].message
            calls = getattr(msg, "tool_calls", None)
            if not calls:
                return (msg.content or "").strip()

            msgs.append({
                "role": "assistant",
                "content": msg.content or "",
                "tool_calls": [
                    {"id": tc.id, "type": "function",
                     "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                    for tc in calls
                ],
            })
            for tc in calls:
                try:
                    args = json.loads(tc.function.arguments or "{}")
                except Exception:
                    args = {}
                short = ", ".join(f"{k}={str(v)[:40]!r}" for k, v in args.items() if k != "content")
                self.step.emit(f"{tc.function.name}({short})")
                msgs.append({"role": "tool", "tool_call_id": tc.id,
                             "content": run_tool(tc.function.name, args)})

        # Adım sınırı: elimizdekiyle toparla
        msgs.append({"role": "user", "content": "Simdiye kadar bulduklarinla kisaca sonucu yaz."})
        return (self._create(client, msgs, with_tools=False).choices[0].message.content or "").strip()


def _friendly_error(e: Exception) -> str:
    s = str(e)
    low = s.lower()
    if "401" in s or "invalid api key" in low:
        return "Groq API anahtari gecersiz. Ayarlar > Groq API bolumunden kontrol et."
    if "404" in s or "model_not_found" in low or "does not exist" in low:
        return "Model bulunamadi. Ayarlar > Groq API > Model kutusuna gecerli bir model yaz (or: qwen/qwen3.8-27b)."
    if "429" in s or "rate limit" in low:
        return "Groq gunluk/dakikalik limit doldu. Biraz bekleyip tekrar dene."
    if "connection" in low or "timed out" in low or "timeout" in low:
        return "Groq'a baglanilamadi. Internet baglantini kontrol et."
    return s[:300]
