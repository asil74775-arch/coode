# telemetry.py — CPU / RAM / GPU / VRAM ölçümü
# QThread worker; her 1.5 saniyede stats sinyali yayar.

import psutil
from PySide6.QtCore import QThread, Signal

try:
    import pynvml
    pynvml.nvmlInit()
    _NVML = True
except Exception:
    _NVML = False


def _gpu_stats() -> tuple[float, float, float]:
    """gpu_pct, vram_used_gb, vram_total_gb"""
    if not _NVML:
        return 0.0, 0.0, 0.0
    try:
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        util   = pynvml.nvmlDeviceGetUtilizationRates(handle)
        mem    = pynvml.nvmlDeviceGetMemoryInfo(handle)
        return (
            float(util.gpu),
            mem.used  / 1024**3,
            mem.total / 1024**3,
        )
    except Exception:
        return 0.0, 0.0, 0.0


class TelemetryWorker(QThread):
    stats = Signal(dict)

    def __init__(self, interval_ms: int = 1500):
        super().__init__()
        self._interval = interval_ms / 1000
        self._running  = True

    def run(self):
        import time
        while self._running:
            gpu, vram, vram_total = _gpu_stats()
            self.stats.emit({
                "cpu":        psutil.cpu_percent(),
                "ram":        psutil.virtual_memory().percent,
                "gpu":        gpu,
                "vram":       round(vram, 2),
                "vram_total": round(vram_total, 2),
            })
            time.sleep(self._interval)

    def stop(self):
        self._running = False
        self.quit()
        self.wait()
