@echo off
setlocal
title Coode Kurulum
cd /d "%~dp0"
set "APPVER=3.8.0"
set "INSTALL=%LOCALAPPDATA%\Programs\Coode"

echo.
echo  ==============================================
echo     COODE %APPVER%  -  Kurulum hazirlaniyor
echo  ==============================================
echo.

rem ---- 1. Python var mi? ---------------------------------------------------
set "PY="
python --version >nul 2>&1
if not errorlevel 1 set "PY=python"
if defined PY goto :pyok
py -3 --version >nul 2>&1
if not errorlevel 1 set "PY=py -3"
if not defined PY goto :nopython
:pyok
echo [1/5] Python bulundu.

rem ---- 2. Calisan Coode varsa kapat ----------------------------------------
taskkill /im Coode.exe /f >nul 2>&1

rem ---- 3. Derleme ortami ve paketler ---------------------------------------
if not exist ".venv_build\Scripts\python.exe" (
    echo [2/5] Derleme ortami olusturuluyor...
    %PY% -m venv .venv_build || goto :fail
)
set "VPY=.venv_build\Scripts\python.exe"
echo [2/5] Paketler yukleniyor - ilk seferde birkac dakika surebilir...
"%VPY%" -m pip install --upgrade pip --quiet --disable-pip-version-check
"%VPY%" -m pip install -r requirements.txt --quiet --disable-pip-version-check || goto :fail

rem ---- 4. Coode.exe olustur ------------------------------------------------
echo [3/5] Coode.exe olusturuluyor...
"%VPY%" -m PyInstaller --noconfirm --clean --log-level WARN coode.spec || goto :fail
if not exist "dist\Coode\Coode.exe" goto :fail

rem ---- Eski sohbetler ve Groq anahtari yeni kuruluma tasinsin --------------
if exist "data\coode.db" if not exist "%INSTALL%\data\coode.db" (
    mkdir "%INSTALL%\data" >nul 2>&1
    copy /y "data\coode.db" "%INSTALL%\data\coode.db" >nul
    echo       Ayarlarin ve sohbet gecmisin tasindi.
)

rem ---- 5. Setup.exe olustur - Inno Setup -----------------------------------
echo [4/5] Setup.exe hazirlaniyor...
call :findiscc
if not defined ISCC (
    where winget >nul 2>&1 && (
        echo       Inno Setup yukleniyor - setup dosyasi olusturmak icin gerekli...
        winget install -e --id JRSoftware.InnoSetup --scope user --silent --accept-package-agreements --accept-source-agreements >nul 2>&1
        call :findiscc
    )
)
if not defined ISCC goto :directinstall

"%ISCC%" /Q installer.iss || goto :directinstall
if not exist "dist\Coode_Setup_%APPVER%.exe" goto :directinstall

echo [5/5] Kurulum sihirbazi aciliyor...
echo.
echo  Setup dosyan hazir: %CD%\dist\Coode_Setup_%APPVER%.exe
echo  Bu dosyayi baska bilgisayarlara da kurabilirsin.
echo.
start "" /wait "dist\Coode_Setup_%APPVER%.exe"
goto :done

rem ---- Yedek: Inno yoksa dogrudan kur ---------------------------------------
:directinstall
echo [5/5] Dogrudan kuruluyor: %INSTALL%
xcopy "dist\Coode" "%INSTALL%\" /e /i /y /q >nul || goto :fail
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=New-Object -ComObject WScript.Shell;" ^
  "foreach($p in @([Environment]::GetFolderPath('Desktop'),(Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))){" ^
  "$l=$s.CreateShortcut((Join-Path $p 'Coode.lnk'));$l.TargetPath='%INSTALL%\Coode.exe';" ^
  "$l.WorkingDirectory='%INSTALL%';$l.IconLocation='%INSTALL%\Coode.exe,0';$l.Save()}"
start "" "%INSTALL%\Coode.exe"
goto :done

:findiscc
set "ISCC="
for %%P in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe") do (
    if exist %%P set "ISCC=%%~P"
)
exit /b 0

:nopython
echo  Python bulunamadi.
where winget >nul 2>&1 && (
    echo  Python 3.12 yukleniyor...
    winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
    echo.
    echo  Python kuruldu. Bu pencereyi kapatip KUR.bat'a TEKRAR cift tikla.
    pause
    exit /b 1
)
echo  python.org adresinden Python 3.12 indir, kurarken "Add Python to PATH" kutusunu isaretle.
pause
exit /b 1

:fail
echo.
echo  HATA: Kurulum tamamlanamadi. Yukaridaki son hata satirinin ekran goruntusunu gonder.
pause
exit /b 1

:done
echo.
echo  ==============================================
echo     Kurulum tamam. Coode'u masaustunden ac.
echo  ==============================================
echo.
pause
endlocal
