# widgets.py — Coode profesyonel UI bileşenleri v3.7.2

import re
from PySide6.QtCore    import Qt, Signal, QSize, QPropertyAnimation, QEasingCurve, QTimer
from PySide6.QtGui     import QColor, QPainter, QPainterPath, QLinearGradient
from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel, QFrame,
    QScrollArea, QSizePolicy, QPushButton, QDialog,
    QTextEdit, QProgressBar, QMenu, QApplication,
    QGraphicsOpacityEffect,
)
import theme as th


def clean_ai_text(text: str) -> str:
    """Qwen3 <think> bloklarını gizle (yarım kalmış olanlar dahil)."""
    if not text:
        return ""
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S)
    if "<think>" in text:
        text = text.split("<think>")[0]
    return text.strip()


# ── Telemetri Çubuğu ──────────────────────────────────────────────────────────
class TelemetryBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._bars: dict[str, tuple[QLabel, QProgressBar]] = {}
        from PySide6.QtWidgets import QGridLayout
        lay = QGridLayout(self)
        lay.setContentsMargins(0, 4, 0, 4)
        lay.setHorizontalSpacing(14)
        lay.setVerticalSpacing(8)
        for i, key in enumerate(("CPU", "RAM", "GPU", "VRAM")):
            col = QVBoxLayout()
            col.setSpacing(3)
            lbl = QLabel(key)
            lbl.setStyleSheet(
                f"color:{th.get('text_muted')}; font-size:9px; "
                f"font-weight:600; letter-spacing:1px; background:transparent;"
            )
            lbl.setAlignment(Qt.AlignLeft)
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setTextVisible(False)
            bar.setFixedHeight(3)
            bar.setStyleSheet(
                f"QProgressBar{{background:{th.get('border')};border:none;border-radius:2px;}}"
                f"QProgressBar::chunk{{background:{th.get('accent')};border-radius:2px;}}"
            )
            col.addWidget(lbl)
            col.addWidget(bar)
            lay.addLayout(col, i // 2, i % 2)
            self._bars[key] = (lbl, bar)

    def update_stats(self, stats: dict):
        mapping = {
            "CPU":  ("cpu",  100),
            "RAM":  ("ram",  100),
            "GPU":  ("gpu",  100),
            "VRAM": ("vram", stats.get("vram_total", 8) or 8),
        }
        for key, (stat_key, max_val) in mapping.items():
            lbl, bar = self._bars[key]
            val = stats.get(stat_key, 0) or 0
            pct = int(val / max_val * 100) if max_val else 0
            if key == "VRAM":
                lbl.setText(f"VRAM {val:.1f}G")
            else:
                lbl.setText(f"{key} {int(val)}%")
            bar.setValue(pct)
            if pct < 60:
                color = th.get("success")
            elif pct < 85:
                color = th.get("warning")
            else:
                color = th.get("error")
            bar.setStyleSheet(
                f"QProgressBar{{background:{th.get('border')};border:none;border-radius:2px;}}"
                f"QProgressBar::chunk{{background:{color};border-radius:2px;}}"
            )


# ── Sohbet Balonu ─────────────────────────────────────────────────────────────
class ChatBubble(QFrame):
    edit_requested = Signal(str)

    def __init__(self, role: str, text: str, parent=None):
        super().__init__(parent)
        self._role = role
        self._text = text
        is_user    = role == "user"
        self.setFrameShape(QFrame.NoFrame)

        # Hafif fade-in
        self._opacity = QGraphicsOpacityEffect(self)
        self._opacity.setOpacity(0)
        self.setGraphicsEffect(self._opacity)
        self._anim = QPropertyAnimation(self._opacity, b"opacity")
        self._anim.setDuration(180)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.setEasingCurve(QEasingCurve.OutQuad)
        QTimer.singleShot(10, self._anim.start)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(16, 4, 16, 4)
        outer.setSpacing(0)

        if is_user:
            outer.addStretch()

        bubble = QFrame()
        bubble.setObjectName("bubble_user" if is_user else "bubble_ai")

        if is_user:
            bubble.setStyleSheet(
                f"QFrame#bubble_user{{"
                f"background:{th.get('surface3')};"
                f"border-radius:18px 4px 18px 18px;"
                f"border:1px solid {th.get('border2')};"
                f"padding:12px 18px;}}"
            )
            bubble.setMaximumWidth(560)
            bubble.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Preferred)
        else:
            bubble.setStyleSheet(
                f"QFrame#bubble_ai{{"
                f"background:transparent;"
                f"border:none;"
                f"border-left:2px solid {th.get('accent')};"
                f"padding:10px 18px 10px 20px;}}"
            )
            bubble.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

        inner = QVBoxLayout(bubble)
        inner.setContentsMargins(0, 0, 0, 0)
        inner.setSpacing(6)

        # İsim etiketi
        name_lbl = QLabel("Sen" if is_user else "Coode")
        name_lbl.setStyleSheet(
            f"color:{th.get('accent') if is_user else th.get('text_muted')};"
            f"font-size:10px; font-weight:700; letter-spacing:1.5px; background:transparent;"
        )
        inner.addWidget(name_lbl)

        # Metin
        txt_lbl = QLabel()
        txt_lbl.setWordWrap(True)
        if not is_user:
            txt_lbl.setTextFormat(Qt.MarkdownText)
            txt_lbl.setOpenExternalLinks(True)
            text = clean_ai_text(text)
        else:
            txt_lbl.setTextFormat(Qt.PlainText)
        txt_lbl.setText(text)
        txt_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.LinksAccessibleByMouse)
        txt_lbl.setStyleSheet(
            f"color:{th.get('text')}; font-size:13px; line-height:1.7; background:transparent;"
        )
        inner.addWidget(txt_lbl)
        self._txt_lbl = txt_lbl

        # Aksiyon butonları
        btn_row = QHBoxLayout()
        btn_row.setContentsMargins(0, 2, 0, 0)
        btn_row.setSpacing(4)

        btn_copy = self._action_btn("Kopyala")
        btn_copy.clicked.connect(self._copy)
        btn_row.addWidget(btn_copy)

        if is_user:
            btn_edit = self._action_btn("Duzenle")
            btn_edit.clicked.connect(self._emit_edit)
            btn_row.addWidget(btn_edit)

        btn_row.addStretch()
        inner.addLayout(btn_row)

        outer.addWidget(bubble)

        if not is_user:
            spacer = QWidget()
            spacer.setFixedWidth(24)
            outer.addWidget(spacer)

    def _action_btn(self, label: str) -> QPushButton:
        btn = QPushButton(label)
        btn.setStyleSheet(
            f"background:transparent; color:{th.get('text_muted')}; border:none; "
            f"font-size:10px; font-weight:500; padding:1px 8px;"
            f"border-radius:4px;"
        )
        btn.setCursor(Qt.PointingHandCursor)
        return btn

    def _copy(self):
        QApplication.clipboard().setText(self._text)

    def _emit_edit(self):
        self.edit_requested.emit(self._text)

    def update_text(self, text: str):
        if self._role != "user":
            text = clean_ai_text(text)
        self._text = text
        self._txt_lbl.setText(text)


# ── Sohbet Görünümü ───────────────────────────────────────────────────────────
class ChatView(QScrollArea):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setStyleSheet("QScrollArea{background:transparent; border:none;}")

        self._container = QWidget()
        self._container.setStyleSheet("background:transparent;")
        self._layout = QVBoxLayout(self._container)
        self._layout.setAlignment(Qt.AlignTop)
        self._layout.setSpacing(4)
        self._layout.setContentsMargins(0, 16, 0, 16)
        self._layout.addStretch()
        self.setWidget(self._container)
        self._streaming = None

    def add_bubble(self, role: str, text: str) -> "ChatBubble":
        b = ChatBubble(role, text)
        self._layout.insertWidget(self._layout.count() - 1, b)
        self._scroll_bottom()
        return b

    def add_streaming_bubble(self):
        bubble = ChatBubble("assistant", "")
        self._streaming = bubble
        self._layout.insertWidget(self._layout.count() - 1, bubble)
        self._scroll_bottom()

    def update_streaming_bubble(self, text: str):
        if self._streaming:
            shown = clean_ai_text(text)
            self._streaming.update_text(shown if shown else "Dusunuyor...")
            self._scroll_bottom()

    def finalize_streaming_bubble(self, text: str):
        if self._streaming:
            self._streaming.update_text(text)
            self._streaming = None
            self._scroll_bottom()

    def clear(self):
        self._streaming = None
        while self._layout.count() > 1:
            item = self._layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _scroll_bottom(self):
        QTimer.singleShot(60, lambda: self.verticalScrollBar().setValue(
            self.verticalScrollBar().maximum()
        ))


# ── Onay Diyaloğu ─────────────────────────────────────────────────────────────
class ApprovalDialog(QDialog):
    def __init__(self, title: str, description: str, code: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumSize(640, 420)
        self.setStyleSheet(f"background:{th.get('background')}; color:{th.get('text')};")

        lay = QVBoxLayout(self)
        lay.setSpacing(14)
        lay.setContentsMargins(24, 24, 24, 24)

        lbl = QLabel(description)
        lbl.setWordWrap(True)
        lbl.setStyleSheet(f"color:{th.get('text_dim')}; font-size:13px;")
        lay.addWidget(lbl)

        code_box = QTextEdit()
        code_box.setPlainText(code)
        code_box.setReadOnly(True)
        code_box.setStyleSheet(
            f"background:{th.get('surface2')}; color:{th.get('info')};"
            f"border:1px solid {th.get('border2')}; border-radius:10px; "
            f"font-family:'Cascadia Code','Consolas',monospace; font-size:12px;"
            f"padding:12px;"
        )
        lay.addWidget(code_box)

        btns = QHBoxLayout()
        btn_no = QPushButton("Reddet")
        btn_ok = QPushButton("Onayla ve Uygula")
        btn_ok.setObjectName("primary")
        btn_ok.clicked.connect(self.accept)
        btn_no.clicked.connect(self.reject)
        btns.addStretch()
        btns.addWidget(btn_no)
        btns.addWidget(btn_ok)
        lay.addLayout(btns)


# ── App Lab Kartı ─────────────────────────────────────────────────────────────
class AppLabCard(QFrame):
    run_requested = Signal(str)

    def __init__(self, name: str, path: str, description: str, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.NoFrame)
        self.setStyleSheet(
            f"QFrame{{background:{th.get('surface2')}; "
            f"border:1px solid {th.get('border')}; "
            f"border-radius:14px; padding:4px;}}"
            f"QFrame:hover{{border-color:{th.get('border2')};"
            f"background:{th.get('surface3')};}}"
        )

        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 12, 12, 12)
        col = QVBoxLayout()
        col.setSpacing(2)
        lbl_name = QLabel(name)
        lbl_name.setStyleSheet(
            f"font-weight:700; color:{th.get('text')}; font-size:13px;"
        )
        lbl_desc = QLabel(description)
        lbl_desc.setStyleSheet(
            f"color:{th.get('text_dim')}; font-size:11px;"
        )
        col.addWidget(lbl_name)
        col.addWidget(lbl_desc)
        lay.addLayout(col)
        lay.addStretch()

        btn = QPushButton("Calistir")
        btn.setObjectName("primary")
        btn.setFixedSize(QSize(90, 34))
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(lambda: self.run_requested.emit(path))
        lay.addWidget(btn)


# ── İkonlar ───────────────────────────────────────────────────────────────────
def mic_icon(color: str, size: int = 64):
    """Vektörel mikrofon ikonu (emoji/font gerektirmez)."""
    from PySide6.QtGui import QPixmap, QIcon, QPen
    from PySide6.QtCore import QRectF
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    c = QColor(color)
    s = size / 64.0
    # kapsül gövde
    p.setPen(Qt.NoPen)
    p.setBrush(c)
    p.drawRoundedRect(QRectF(24 * s, 8 * s, 16 * s, 30 * s), 8 * s, 8 * s)
    # kavis + ayak
    pen = QPen(c, 4 * s)
    pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    p.setBrush(Qt.NoBrush)
    p.drawArc(QRectF(16 * s, 18 * s, 32 * s, 30 * s), 200 * 16, 140 * 16)
    p.drawLine(int(32 * s), int(48 * s), int(32 * s), int(56 * s))
    p.drawLine(int(24 * s), int(56 * s), int(40 * s), int(56 * s))
    p.end()
    return QIcon(pm)


def send_icon(logo_path: str, fallback_color: str, size: int = 64):
    """Coode logosu (C) — logo dosyası yoksa vektörel C çizer."""
    import os
    from PySide6.QtGui import QPixmap, QIcon, QPen
    from PySide6.QtCore import QRectF
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setRenderHint(QPainter.SmoothPixmapTransform)
    if logo_path and os.path.isfile(logo_path):
        src = QPixmap(logo_path).scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        # yuvarlak maske
        path = QPainterPath()
        path.addEllipse(QRectF(0, 0, size, size))
        p.setClipPath(path)
        p.drawPixmap((size - src.width()) // 2, (size - src.height()) // 2, src)
    else:
        pen = QPen(QColor(fallback_color), size * 0.14)
        pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        m = size * 0.22
        p.drawArc(QRectF(m, m, size - 2 * m, size - 2 * m), 45 * 16, 270 * 16)
    p.end()
    return QIcon(pm)


def speaker_icon(color: str, on: bool = True, size: int = 64):
    """Vektörel hoparlör ikonu (açıkken ses dalgalarıyla)."""
    from PySide6.QtGui import QPixmap, QIcon, QPen, QPolygonF
    from PySide6.QtCore import QRectF, QPointF
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    c = QColor(color)
    s = size / 64.0
    p.setPen(Qt.NoPen)
    p.setBrush(c)
    p.drawPolygon(QPolygonF([QPointF(10 * s, 24 * s), QPointF(22 * s, 24 * s), QPointF(36 * s, 12 * s),
                             QPointF(36 * s, 52 * s), QPointF(22 * s, 40 * s), QPointF(10 * s, 40 * s)]))
    pen = QPen(c, 4 * s)
    pen.setCapStyle(Qt.RoundCap)
    p.setPen(pen)
    p.setBrush(Qt.NoBrush)
    if on:
        p.drawArc(QRectF(30 * s, 22 * s, 16 * s, 20 * s), -60 * 16, 120 * 16)
        p.drawArc(QRectF(30 * s, 14 * s, 26 * s, 36 * s), -60 * 16, 120 * 16)
    else:
        p.drawLine(int(44 * s), int(26 * s), int(56 * s), int(38 * s))
        p.drawLine(int(56 * s), int(26 * s), int(44 * s), int(38 * s))
    p.end()
    return QIcon(pm)
