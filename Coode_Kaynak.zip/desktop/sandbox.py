# sandbox.py — Güvenli kod çalıştırma
# python -I ile izole subprocess; timeout + max output sınırı var.

import subprocess
import sys
import os
import tempfile
from dataclasses import dataclass
from config import SANDBOX_TIMEOUT, SANDBOX_MAX_OUT, APPS_DIR


def _python_exe() -> str:
    """Kod çalıştırmak için Python yolu. Exe olarak kuruluysa sistem Python'unu kullanır."""
    if not getattr(sys, "frozen", False):
        return sys.executable
    import shutil
    for name in ("python", "py", "python3"):
        p = shutil.which(name)
        if p and "WindowsApps" not in p:
            return p
    raise FileNotFoundError("Kod calistirmak icin bilgisayarda Python kurulu olmali (python.org).")


@dataclass
class SandboxResult:
    ok:     bool
    output: str
    error:  str = ""


def run_code(code: str) -> SandboxResult:
    """Verilen Python kodunu geçici dosyaya yazıp izole çalıştırır."""
    with tempfile.TemporaryDirectory() as tmp:
        script = os.path.join(tmp, "script.py")
        with open(script, "w", encoding="utf-8") as f:
            f.write(code)
        try:
            proc = subprocess.run(
                [_python_exe(), "-I", script],
                capture_output=True,
                text=True,
                timeout=SANDBOX_TIMEOUT,
                cwd=tmp,
            )
            out = (proc.stdout + proc.stderr)[:SANDBOX_MAX_OUT]
            return SandboxResult(ok=proc.returncode == 0, output=out)
        except subprocess.TimeoutExpired:
            return SandboxResult(ok=False, output="", error="Zaman aşımı.")
        except Exception as e:
            return SandboxResult(ok=False, output="", error=str(e))


def run_app(filename: str) -> SandboxResult:
    """apps/ klasöründeki bir Python uygulamasını çalıştırır."""
    path = os.path.join(APPS_DIR, filename)
    if not os.path.isfile(path):
        return SandboxResult(ok=False, output="", error=f"Dosya bulunamadı: {filename}")
    try:
        proc = subprocess.run(
            [_python_exe(), "-I", path],
            capture_output=True,
            text=True,
            timeout=SANDBOX_TIMEOUT,
            cwd=APPS_DIR,
        )
        out = (proc.stdout + proc.stderr)[:SANDBOX_MAX_OUT]
        return SandboxResult(ok=proc.returncode == 0, output=out)
    except subprocess.TimeoutExpired:
        return SandboxResult(ok=False, output="", error="Zaman aşımı.")
    except Exception as e:
        return SandboxResult(ok=False, output="", error=str(e))


def list_apps() -> list[dict]:
    """apps/ klasöründeki .py dosyalarını listeler."""
    apps = []
    for name in sorted(os.listdir(APPS_DIR)):
        if not name.endswith(".py"):
            continue
        path    = os.path.join(APPS_DIR, name)
        desc    = ""
        with open(path, encoding="utf-8", errors="ignore") as f:
            first = f.readline().strip()
            if first.startswith("#"):
                desc = first.lstrip("#").strip()
        apps.append({"name": name, "path": name, "description": desc})
    return apps
