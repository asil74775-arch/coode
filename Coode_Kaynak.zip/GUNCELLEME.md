# Coode guncelleme sistemi

Bu zip GitHub'daki `Coode_Kaynak.zip` dosyasidir. Yeni bir zip yuklendiginde
GitHub Actions ("Coode Derle") sunlari kendiliginden yapar:

1. android/ -> Coode-<surum>.apk (telefon)
2. desktop/ -> Coode_Setup_<surum>.exe (PC)
3. Ikisini birlikte `v<surum>` adli Release olarak yayinlar.

PC'deki Coode her acilista bu Release'e bakar; yeni surum varsa
"Simdi Guncelle" der, indirir, kurar ve yeniden acilir.

Yeni surum: VERSION, desktop/config.py (APP_VERSION), android/app/build.gradle
(versionCode/versionName) ve android/app/src/main/java/.../MainActivity.java
(BuildConfigHolder.VERSION) ayni surume getirilir.
